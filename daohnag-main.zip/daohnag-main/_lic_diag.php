<?php
/**
 * NavVerse 授权诊断工具（临时文件，诊断完请务必从服务器删除！）
 * 用法：浏览器打开  https://你的站点/_lic_diag.php?k=znavdiag
 * 兼容 PHP 7.0+
 */
header('Content-Type: text/plain; charset=utf-8');
if (($_GET['k'] ?? '') !== 'znavdiag') {
    echo "用法：_lic_diag.php?k=znavdiag\n（诊断完请务必从服务器删除本文件）";
    exit;
}

require_once __DIR__ . '/lib/license.php';

function L($s = '') { echo $s . "\n"; }
function H($s) { echo "\n===== " . $s . " =====\n"; }

L('=== NavVerse 授权诊断 ' . date('Y-m-d H:i:s') . '（服务器本机时间，UTC ' . gmdate('H:i') . '）===');
H('基本信息');
L('当前域名      : ' . znav_lic_domain());
L('HTTP_HOST    : ' . ($_SERVER['HTTP_HOST'] ?? '-'));
L('PHP 版本     : ' . PHP_VERSION);
L('curl 扩展    : ' . (function_exists('curl_init') ? '有' : '没有（联网靠 fsockopen，容易失败）'));
L('openssl 扩展 : ' . (extension_loaded('openssl') ? '有' : '没有（无法 https）'));
L('allow_url_fopen: ' . (ini_get('allow_url_fopen') ? '开' : '关'));
L('授权服务器   : ' . implode(' , ', znav_lic_servers()));
L('回检间隔     : ' . ZNAV_LIC_RECHECK_TTL . ' 秒 / 宽限 ' . ZNAV_LIC_GRACE_DAYS . ' 天');
L('未授权锁后台 : ' . (ZNAV_LIC_ENFORCE ? '是' : '否（未授权也不锁）'));

H('1. 本地许可证 license.dat');
$file = znav_lic_file();
L('文件路径      : ' . $file);
L('文件是否存在  : ' . (file_exists($file) ? '是' : '否'));
if (file_exists($file)) {
    $rd  = znav_lic_read();
    $lic = $rd['lic'];
    $ck  = znav_lic_check_local();
    L('本地验签      : ' . ($ck[0] ? '通过' : '失败') . ' → ' . $ck[1]);
    if (is_array($lic)) {
        L('授权码        : ' . (isset($lic['key']) ? znav_lic_mask($lic['key']) : '-'));
        L('绑定域名      : ' . ($lic['domain'] ?? '-'));
        L('到期日        : ' . (empty($lic['expire']) ? '永久' : $lic['expire']));
        L('签发日        : ' . ($lic['issued'] ?? '-'));
        L('模式          : ' . (empty($lic['off'])
              ? '联网授权码（受服务器吊销/解绑控制）'
              : '★离线激活码 NVO-（服务器吊销/解绑对它完全无效！只能改域名或轮换密钥）'));
    }
    L('上次成功回检  : ' . ($rd['checked'] ? date('Y-m-d H:i:s', $rd['checked']) : '从未成功')
      . ($rd['checked'] ? '（距今 ' . round((time() - $rd['checked']) / 60) . ' 分钟）' : ''));
    $next = $rd['checked'] + ZNAV_LIC_RECHECK_TTL - time();
    L('下次自动回检  : ' . ($next > 0 ? ceil($next / 60) . ' 分钟后' : '已到期，“打开后台”即触发'));
    $left = ZNAV_LIC_GRACE_DAYS * 86400 - (time() - ($rd['checked'] ?: time()));
    L('断网宽限剩余  : ' . max(0, floor($left / 86400)) . ' 天（不断回检成功就一直是“已授权”）');
}

H('2. 本地豁免开关（这两个命中任何一个，本站永远显示“已授权”）');
$dir = dirname(znav_lic_file());
L('数据目录      : ' . $dir);
L('.lic_local_free 文件 : ' . (file_exists($dir . '/.lic_local_free') ? '★存在！（删掉它才会真失效）' : '不存在（正常）'));
L('常量 ZNAV_LIC_LOCAL_FREE : ' . (ZNAV_LIC_LOCAL_FREE ? '★true（改成 false）' : 'false（正常）'));
L('是否本地/内网环境 : ' . (znav_lic_is_local() ? '是' : '否'));

H('3. 执行一次【强制回检】（忽略 12 小时间隔）');
$rc = znav_lic_recheck(true);
L('结果代码      : ' . ($rc[2] ?? '-'));
L('是否通过      : ' . ($rc[0] ? '通过（仍认为有效）' : '不通过'));
L('原文返回      : ' . ($rc[1] ?? '-'));
if (!$rc[0]) {
    L('→ 若代码是 revoked：表示服务器已判定失效，本地 license.dat 已被删除，刷新界面应显示未授权。');
    L('→ 若代码是 offline：表示根本没能连通授权服务器（不是被拒绝），所以仍在宽限期内保持已授权。');
}

H('4. 裸请求授权服务器（看真实网络状况）');
$lic = znav_lic_read();
$key = ($lic['lic']['key'] ?? '');
$post = http_build_query(array(
    'a' => 'recheck', 'key' => $key, 'domain' => znav_lic_domain(),
    'fp' => znav_lic_fp(), 'nonce' => ($lic['lic']['nonce'] ?? ''),
));
$url = ZNAV_LIC_SERVER;
L('请求地址      : ' . $url);
L('提交内容      : ' . $post);
if (function_exists('curl_init')) {
    $ch = curl_init($url);
    curl_setopt_array($ch, array(
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $post,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => ZNAV_LIC_TIMEOUT,
        CURLOPT_CONNECTTIMEOUT => 8,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
        CURLOPT_HTTPHEADER => array('Content-Type: application/x-www-form-urlencoded'),
    ));
    $t0 = microtime(true);
    $body = curl_exec($ch);
    $ms = round((microtime(true) - $t0) * 1000);
    $err = curl_errno($ch) . ' / ' . curl_error($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    L('curl 错误号   : ' . $err);
    L('HTTP 状态码   : ' . $code);
    L('耗时          : ' . $ms . ' ms');
    L('服务器返回    : ' . (is_string($body) ? substr($body, 0, 400) : '(空)'));
    if ($code === 0) {
        if (strpos($err, 'certificate') !== false || strpos($err, 'SSL') !== false) {
            L('★ SSL 证书校验失败：这台服务器的 CA 根证书太旧，需更新 cacert.pem 或让 PHP 使用新版 ca-bundle。');
        } else {
            L('★ 完全连不上：可能是主机禁止出站、DNS 解析失败或被防火墙拦截。');
        }
    }
} else {
    L('本机没有 curl，无法做详细探测（建议在主机面板开启 php-curl 扩展，否则联网验证不稳定）。');
}

H('诊断结论：按以上结果判断');
L('· 若 [4] HTTP 状态码 = 200 且返回 revoked:true → 服务器已把你作废，本地 license.dat 已删，刷新界面即失效。');
L('· 若 [4] HTTP 状态码 = 0 → 这台主机根本连不上授权服务器，必须在主机上解决网络/证书问题，否则吊销永远不生效（宽限期内一直“已授权”）。');
L('· 若 [2] 出现 ★ → 豁免开着，任何吊销都无效，必须先删 .lic_local_free 或改常量。');
L('· 想立刻让本站失效，最快办法：用主机文件管理删掉数据目录里的 license.dat。');
L('');
L('提示：诊断完请删除本文件 _lic_diag.php！');
