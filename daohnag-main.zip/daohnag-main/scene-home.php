<?php
/**
 * 创作者工具集 - 前台首页（万级数据版）
 * 结构：4 阶段 → 每组一卡（24 组）→ 分组页分页 40 条 → 站点详情页
 * 首页永远只渲染 24 个分组卡，与总条目数无关；1 万条和 1 千条首屏一样快。
 */
require_once __DIR__ . '/lib/db.php';
// 禁止浏览器/WebView 缓存页面 HTML（手机 WebView 曾因缓存旧 HTML+旧 CSS 出现样式错乱）
header("Cache-Control: no-cache, no-store, must-revalidate");
header("Pragma: no-cache");
header("Expires: 0");

$siteName = znav_setting('siteName', '创作者工具集');
$announcement = znav_setting('announcement', '只收录国内真能用、中文真能用的创作工具');
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
  <title><?php echo znav_e($siteName); ?> · 创作者工具决策指南</title>
  <meta name="description" content="按想、做、发、赚四个阶段整理的创作者工具图谱。每个工具都标注国内能否直连、中文质量、免费额度、真实缺点。">
  <meta property="og:title" content="<?php echo znav_e($siteName); ?>">
  <meta property="og:description" content="只收录国内真能用、中文真能用的创作工具，附实测缺点。">
  <meta property="og:type" content="website">
  <link rel="stylesheet" href="/assets/style.css">
  <link rel="stylesheet" href="/assets/scene.css">
</head>
<body class="scene-body">
  <div class="bg-blob blob1"></div>
  <div class="bg-blob blob2"></div>
  <div class="bg-blob blob3"></div>

  <header class="s-header">
    <div class="s-header-inner">
      <a class="s-logo" href="/scene-home.php">
        <span class="s-logo-mark">笔</span>
        <span class="s-logo-txt"><?php echo znav_e($siteName); ?></span>
      </a>

      <nav class="s-nav" id="stageNav">
        <button class="s-nav-item active" data-stage="all">全部</button>
        <button class="s-nav-item" data-stage="think">想</button>
        <button class="s-nav-item" data-stage="make">做</button>
        <button class="s-nav-item" data-stage="ship">发</button>
        <button class="s-nav-item" data-stage="earn">赚</button>
      </nav>

      <div class="s-header-actions">
        <button id="themeToggle" class="s-icon-btn" title="切换主题" aria-label="切换主题">◐</button>
        <a class="s-icon-btn" href="/all.php" title="全量索引" aria-label="全量索引">☰</a>
      </div>
    </div>
  </header>

  <main class="s-wrap">

    <section class="s-hero s-hero-compact">
      <div class="s-hero-badge">国内可用性 · 实测更新</div>
      <h1 class="s-hero-title s-hero-title-sm">
        别让工具选你。<span class="s-hero-grad-inline">你来选工具。</span>
      </h1>

      <div class="s-search">
        <span class="s-search-ico">⌕</span>
        <input id="searchInput" type="text" autocomplete="off"
               placeholder="搜工具名、场景或需求，比如「小红书 批量出图」">
        <kbd class="s-kbd">/</kbd>
      </div>
      <div class="s-search-result" id="searchResult" hidden></div>
      <div class="s-suggests" id="suggests"></div>

      <div class="s-stats" id="heroStats"></div>
    </section>

    <section class="s-stagebar" id="stageBar"></section>

    <div class="s-groups" id="groupList"></div>

    <div class="s-allbar">
      <a href="/all.php" class="s-allbar-link">
        <span>浏览全部收录 →</span>
        <span class="s-allbar-sub" id="allCount"></span>
      </a>
    </div>

    <section class="s-principle">
      <h2>收录标准</h2>
      <div class="s-principle-grid">
        <div class="s-principle-item">
          <span class="s-principle-num">01</span>
          <h3>国内能直连</h3>
          <p>需要特殊网络环境的工具会被明确标注，不让你注册完才发现打不开。</p>
        </div>
        <div class="s-principle-item">
          <span class="s-principle-num">02</span>
          <h3>中文真能用</h3>
          <p>宣传页写的和中文实际效果是两件事。这里记的是实测结果。</p>
        </div>
        <div class="s-principle-item">
          <span class="s-principle-num">03</span>
          <h3>缺点必须写</h3>
          <p>只讲优点的推荐等于没有推荐。每个工具都有「不适合谁」。</p>
        </div>
      </div>
    </section>

  </main>

  <footer class="s-footer">
    <div class="s-footer-inner">
      <span>© <?php echo date('Y'); ?> <?php echo znav_e($siteName); ?></span>
      <span class="s-footer-dot">·</span>
      <a href="/all.php">全量索引</a>
      <span class="s-footer-dot">·</span>
      <a href="/submit.php">提交收录</a>
      <span class="s-footer-dot">·</span>
      <a href="/admin/">后台</a>
    </div>
  </footer>

  <script>window.DEMO_MODE = true; window.MOCK_10K = true;</script>
  <script src="/assets/scene-mock.js"></script>
  <script src="/assets/scene.js"></script>
</body>
</html>
