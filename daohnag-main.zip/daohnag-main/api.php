<?php
/**
 * 趣导 NavVerse PHP 版 - 全部接口
 * 公开: summary / sites / fetch_title
 * 管理: login / logout / stats / settings_save / cat_* / site_* / ad_* / import
 * 管理接口依赖 PHP Session（admin/index.php 登录后自动携带）
 */
require_once __DIR__ . '/lib/db.php';
require_once __DIR__ . '/lib/sub.php';
require_once __DIR__ . '/lib/seo.php';
require_once __DIR__ . '/lib/license.php';

// 当前源码版本号：开发者每次发布新版本时手动 +1（语义化版本，如 1.0.1）。
// 用于「源码更新提醒」与远端 manifest 里的 version 做对比。
if (!defined('ZNAV_VERSION')) define('ZNAV_VERSION', '1.0.1');

// 免费主机/部分环境默认开着 display_errors：任何 PHP Warning/Notice 都会混进 JSON
// 导致前端 JSON 解析失败（表现为笼统的「请求失败」）。这里统一关闭并在输出 JSON 前清空缓冲。
@ini_set('display_errors', '0');
@ini_set('html_errors', '0');
@error_reporting(E_ALL);
while (ob_get_level() > 0) { @ob_end_clean(); }
ob_start();

session_start();
$action = isset($_GET['action']) ? $_GET['action'] : (isset($_POST['action']) ? $_POST['action'] : '');
$input = array();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $raw = file_get_contents('php://input');
    $input = json_decode($raw, true);
    if (!is_array($input)) {
        $input = $_POST;
    }
}

// 尚未完成安装向导：除登录校验外一律拒绝，避免未初始化就被写入数据
$znavInstalled = znav_is_installed();
if (!$znavInstalled && $action !== 'auth_check') {
    znav_json(array('error' => '站点尚未安装，请先访问 /install.php 完成安装向导', 'needInstall' => true), 403);
}

/**
 * 首页右栏模块：后台可自由增删 / 改名 / 排序 / 隐藏
 * 类型：page=页面模块（展示该页面下的文章）、arts=最新文章、posts=社区帖子、ads=广告位、hub=聚合页入口
 * 未配置时按「页面管理有什么就放什么」自动生成默认值
 * hidden=1 的模块保留在配置里（后台还能一键恢复），但不下发给前台
 */
function znav_side_modules($db, $withHidden = false)
{
    // 实时页面表（enabled=1）：用于页面模块标题跟随 + 增减自动同步
    $live = array();
    try {
        foreach ($db->query('SELECT id,title FROM pages WHERE enabled=1 ORDER BY sort,id') as $p) {
            $live[intval($p['id'])] = (string)$p['title'];
        }
    } catch (Exception $e) {}
    // 被后台手动删除过的页面模块：不再自动补回来（空数组也保持「右栏无模块」）
    $removed = array();
    foreach (explode(',', (string)znav_setting('sideRemovedPages', '')) as $x) {
        $x = intval(trim($x)); if ($x > 0) $removed[] = $x;
    }
    $raw = znav_setting('sideModules', '');
    if ($raw !== '') {
        $j = json_decode($raw, true);
        if (is_array($j)) {
            // 配置存在但被删空 = 右栏不放任何模块（不再自动生成默认）
            if (!count($j)) return array();
            $out = array();
            $lastPageIdx = -1;
            $haveRefs = array();
            $hiddenPageRefs = array();
            $seen = array();
            foreach ($j as $m) {
                if (!is_array($m)) continue;
                $t = isset($m['type']) ? (string)$m['type'] : '';
                if (!in_array($t, array('page', 'arts', 'posts', 'ads', 'hub'), true)) continue;
                $hidden = !empty($m['hidden']);
                $one = array('type' => $t, 'title' => mb_substr(trim((string)(isset($m['title']) ? $m['title'] : '')), 0, 20));
                if ($t === 'page') {
                    $one['ref'] = intval(isset($m['ref']) ? $m['ref'] : 0);
                    if (!$one['ref']) continue;
                    if (!isset($live[$one['ref']])) continue;          // 页面已删除 / 停用 → 前端模块同步移除
                    $one['title'] = mb_substr($live[$one['ref']], 0, 20); // 标题实时跟随页面管理
                    $haveRefs[] = $one['ref'];
                    if ($hidden) {
                        $hiddenPageRefs[] = $one['ref'];               // 隐藏：不再自动补
                        if (!$withHidden) continue;                    // 前台不下发
                        $one['hidden'] = 1;
                    }
                    $lastPageIdx = count($out);
                } elseif ($hidden) {
                    if (!$withHidden) continue;                        // 隐藏：整个模块不下发
                    $one['hidden'] = 1;
                }
                // 去重：同类型同引用（或同类型非页面模块）只保留一个
                $key = $t === 'page' ? 'page-' . $one['ref'] : $t;
                if (isset($seen[$key])) continue;
                $seen[$key] = 1;
                $out[] = $one;
            }
            // 页面管理新增页面 → 自动补一个模块（插到最后一个页面模块之后；已被手动隐藏的不补）
            $add = array();
            foreach ($live as $id => $t) {
                if (in_array($id, $haveRefs, true) || in_array($id, $hiddenPageRefs, true) || in_array($id, $removed, true)) continue;
                $add[] = array('type' => 'page', 'title' => mb_substr($t, 0, 20), 'ref' => $id);
            }
            if (count($add)) array_splice($out, $lastPageIdx + 1, 0, $add);
            return $out;
        }
    }
    // 默认：广告位 + 最新文章 + 页面管理的每个页面一个模块 + 社区帖子 + 聚合入口
    $def = array(
        array('type' => 'ads', 'title' => '广告位'),
        array('type' => 'arts', 'title' => '最新文章'),
    );
    foreach ($live as $id => $t) $def[] = array('type' => 'page', 'title' => mb_substr($t, 0, 20), 'ref' => $id);
    $def[] = array('type' => 'posts', 'title' => '社区帖子');
    $def[] = array('type' => 'hub', 'title' => '资源整合');
    return $def;
}

/**
 * 授权门闸白名单：未激活授权时，后台只允许「系统设置」相关的这些接口，
 * 其余管理接口一律拒绝（防止有人绕过前端直接调 API 使用全部功能）。
 * 前台公开接口不经过 require_admin，因此未授权时前台照常浏览，不受影响。
 */
function znav_lic_allow_when_locked($action)
{
    static $allow = array(
        // 登录 / 会话
        'auth_check', 'login', 'logout',
        // 授权管理
        'license_state', 'license_activate', 'license_recheck', 'license_remove',
        // 系统设置页所需的读写与上传
        'summary', 'settings_save', 'backup', 'restore', 'export_bookmarks',
        'logo_get', 'logo_hd', 'logo_files', 'logo_opt', 'logo_upload', 'logo_crop', 'logo_proxy', 'icon_upload',
        'music_upload', 'media_upload', 'video_upload', 'ad_upload',
        'fetch_title', 'proxy_test',
    );
    return in_array($action, $allow, true);
}

function znav_require_admin()
{
    // 商业授权校验：未激活时锁住除「系统设置 / 授权管理」以外的全部后台接口
    global $action;
    if (function_exists('znav_lic_locked') && znav_lic_locked() && !znav_lic_allow_when_locked($action)) {
        $st = function_exists('znav_lic_state') ? znav_lic_state(false) : array('reason' => '未激活');
        znav_json(array(
            'error'       => '🔒 未激活授权：' . (isset($st['reason']) ? $st['reason'] : '未激活') . '，请到「系统设置 → 授权管理」输入授权码激活',
            'licLocked'   => true,
            'licReason'   => isset($st['reason']) ? $st['reason'] : '',
            'licDomain'   => isset($st['domain']) ? $st['domain'] : '',
        ), 402);
    }
    // Session 优先，其次 X-Token 请求头（浏览器代理可能剥 Cookie，token 兜底）
    $bySession = !empty($_SESSION['znav_admin']);
    $token = isset($_SERVER['HTTP_X_TOKEN']) ? $_SERVER['HTTP_X_TOKEN'] : '';
    $byToken = $token !== '' && hash_equals(znav_admin_token(), $token);
    if ($bySession || $byToken) {
        // CSRF 防护：写操作（POST）必须携带派生自管理密码的 X-Token 自定义头，
        // 攻击者站点无法跨域伪造自定义头；仅凭 Session Cookie 不允许写。
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!$byToken) znav_json(array('error' => '请重新登录后再操作'), 401);
        }
        return;
    }
    znav_json(array('error' => '未登录或登录已过期'), 401);
}

/**
 * —— 功能隐藏密码：全程哈希（bcrypt）存储 ——
 * 源码与数据库中均不保存明文；库中若仍是旧版明文，首次校验通过后自动升级为哈希。
 * ZNAV_FEAT_PWD_DEFAULT_HASH 为出厂默认密码的哈希值（明文不写在代码里），请进后台改成自己的密码。
 */
define('ZNAV_FEAT_PWD_DEFAULT_HASH', '$2y$10$wJevSU/F9LyEpCXoln.tVeySubSUuU9PhMf3C51N/mY2tcHWcxqUO');

/** 当前生效的功能密码哈希（库里没存过就用出厂默认哈希） */
function znav_feat_hash()
{
    $v = trim((string)znav_setting('featLockPwd', ''));
    return $v !== '' ? $v : ZNAV_FEAT_PWD_DEFAULT_HASH;
}

/** 判断是否为 bcrypt 哈希，用来识别旧版本遗留的明文值 */
function znav_is_hash($v)
{
    return is_string($v) && preg_match('~^\$(?:2[aby]?|argon2i|argon2id)\$~', $v) === 1;
}

/** 校验功能密码：拿明文去比对哈希；命中旧明文则顺手升级落库 */
function znav_feat_verify($pwd)
{
    if ($pwd === '') return false;
    $saved = znav_feat_hash();
    if (znav_is_hash($saved)) return password_verify($pwd, $saved);
    // 兼容旧数据：库里存的还是明文，校验通过后立即改写为哈希
    if (hash_equals($saved, $pwd)) {
        znav_setting_save('featLockPwd', password_hash($pwd, PASSWORD_BCRYPT));
        return true;
    }
    return false;
}

/** 功能隐藏解锁签名：授权身份 / 功能密码 / 开关 任一变化都会改变签名，
 *  前端据此让「长期解锁」在 重新激活 / 解绑 后自动失效（重新上锁，需再输功能密码）。
 *  注意：必须用授权「身份字段」（znav_lic_payload，不含 checked 时间戳），
 *  不能 md5_file 授权文件 —— 回检会刷新 checked 重写文件，会导致解锁凭据无故失效、
 *  后台菜单在解锁后又被藏起来。到期/未授权的锁定由 license_state 的 locked 负责。 */
function znav_feat_sig()
{
    $licPart = 'none';   // 未激活 / 已解绑（授权文件不存在或为空）
    if (function_exists('znav_lic_read')) {
        $rd = znav_lic_read();
        if (!empty($rd['lic']) && is_array($rd['lic'])) {
            $licPart = md5(function_exists('znav_lic_payload') ? znav_lic_payload($rd['lic']) : json_encode($rd['lic']));
        }
    }
    return md5(znav_setting('featLockOn', '1') . '|' . znav_feat_hash() . '|' . $licPart);
}

/** 由 UA 粗判进入端口：手机 / 平板 / 电脑 / 机器人（搜索引擎爬虫等自动程序的访问，非真人） */
function znav_detect_device($ua)
{
    $ua = strtolower((string)$ua);
    if ($ua === '') return '未知';
    if (strpos($ua, 'ipad') !== false || strpos($ua, 'tablet') !== false) return '平板';
    if (preg_match('/mobile|android|iphone|ipod|phone|harmonyos|windows phone|blackberry|opera mini|iemobile/i', $ua)) return '手机';
    if (preg_match('/bot|spider|crawler|curl|wget|python-requests|headless/i', $ua)) return '机器人';
    return '电脑';
}

/** 访客记录里的端口显示名（兼容旧数据里的「爬虫」叫法） */
function znav_device_label($d)
{
    $d = trim((string)$d);
    if ($d === '爬虫' || strcasecmp($d, 'bot') === 0) return '机器人';
    return $d !== '' ? $d : '未知';
}

/** 把右栏模块键（ads/arts/pages）规整成逗号分隔字符串，过滤非法值 */
function znav_side_keys_csv($v)
{
    $allow = array('ads', 'arts', 'pages');
    if (is_array($v)) $parts = $v;
    else $parts = explode(',', (string)$v);
    $out = array();
    foreach ($parts as $p) {
        $p = strtolower(trim((string)$p));
        if (in_array($p, $allow, true) && !in_array($p, $out, true)) $out[] = $p;
    }
    return implode(',', $out);
}

/** 主分类 id -> 其自身+子分类 id 集合 */
function znav_cat_ids($catId)
{
    $ids = array(intval($catId));
    $st = znav_db()->prepare('SELECT id FROM categories WHERE parent_id=?');
    $st->execute(array(intval($catId)));
    foreach ($st->fetchAll() as $r) {
        $ids[] = intval($r['id']);
    }
    return $ids;
}

/** 按名称查找/创建分类，返回 id */
function znav_ensure_cat($name, $icon, $parentId)
{
    $db = znav_db();
    if ($parentId === null) {
        $st = $db->prepare('SELECT id FROM categories WHERE name=? AND parent_id IS NULL');
        $st->execute(array($name));
    } else {
        $st = $db->prepare('SELECT id FROM categories WHERE name=? AND parent_id=?');
        $st->execute(array($name, $parentId));
    }
    $row = $st->fetch();
    if ($row) return intval($row['id']);
    $max = $db->query('SELECT COALESCE(MAX(sort),0) m FROM categories')->fetch()['m'];
    $db->prepare('INSERT INTO categories(name,icon,parent_id,sort) VALUES(?,?,?,?)')
       ->execute(array(mb_substr($name, 0, 30), $icon ?: '📁', $parentId, intval($max) + 1));
    return intval($db->lastInsertId());
}

/** 顶部导航树：父页面带子页面（下拉），按 sort 排序 */
/* 说明：znav_nav_tree() 已移至 lib/db.php，前台与接口共用，避免重复定义。 */

/** 地域解析：公网 IP 调免费接口查归属地，结果缓存 ip_region 表；失败返回空 */
function znav_ip_region($ip)
{
    if ($ip === '' || $ip === '0.0.0.0') return '';
    // 内网 / 回环：标注为「局域网」并入库缓存，方便后台地域统计也能看到本机访问
    if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
        try {
            znav_db()->prepare('INSERT OR REPLACE INTO ip_region(ip,region,updated_at) VALUES(?,?,?)')
               ->execute(array($ip, '局域网', date('Y-m-d H:i:s')));
        } catch (Exception $e) { /* ignore */ }
        return '局域网';
    }
    $db = znav_db();
    $st = $db->prepare('SELECT region FROM ip_region WHERE ip=?');
    $st->execute(array($ip));
    $row = $st->fetch();
    if ($row) return $row['region'];
    $region = '';
    try {
        $ctx = stream_context_create(array('http' => array('timeout' => 1.5)));
        $raw = @file_get_contents('http://ip-api.com/json/' . urlencode($ip) . '?lang=zh-CN&fields=regionName,city', false, $ctx);
        if ($raw) {
            $j = json_decode($raw, true);
            if (is_array($j) && !empty($j['regionName'])) {
                $region = trim($j['regionName'] . (isset($j['city']) && $j['city'] && $j['city'] !== $j['regionName'] ? ' ' . $j['city'] : ''));
            }
        }
    } catch (Exception $e) { /* 离线时静默 */ }
    try {
        $db->prepare('INSERT OR REPLACE INTO ip_region(ip,region,updated_at) VALUES(?,?,?)')
           ->execute(array($ip, $region, date('Y-m-d H:i:s')));
    } catch (Exception $e) { /* ignore */ }
    return $region;
}

// ---------- 文件管理（后台中文文件管理器） ----------
// 根目录 = 站点上级目录（含站点代码、uploads、数据库目录）；如需更大范围改这一行
// 文件管理器根目录 = 站点根目录（上传的图片/视频都在 站点根/uploads/ 下）。
// 注意不要指到站点根的上一级：远程主机上通常无权限访问，会导致「读取不到服务器文件」。
if (!defined('ZNAV_FM_ROOT')) define('ZNAV_FM_ROOT', rtrim(str_replace('\\', '/', __DIR__), '/'));

/** 解析相对路径并确保在根目录内；$mustExist 是否要求已存在 */
function fm_path($rel, $mustExist = true)
{
    $rel = str_replace('\\', '/', trim((string)$rel));
    $rel = preg_replace('#^/+#', '', $rel);
    $root = str_replace('\\', '/', ZNAV_FM_ROOT);
    if ($rel === '' || $rel === '.') $full = $root;
    else $full = $root . '/' . $rel;
    // 阻止越界
    if (strpos($rel, '..') !== false) return null;
    if ($mustExist) {
        $rp = realpath($full);
        if ($rp === false) return null;
        $rp = str_replace('\\', '/', $rp);
        if ($rp !== $root && strpos($rp, $root . '/') !== 0) return null;
        return $rp;
    }
    // 创建型操作：逐段规范化（路径可能尚不存在）
    $segs = array_filter(explode('/', $rel), function ($s) { return $s !== '' && $s !== '.'; });
    foreach ($segs as $s) if ($s === '..') return null;
    return $root . ($segs ? '/' . implode('/', $segs) : '');
}

function fm_rel($full)
{
    $root = str_replace('\\', '/', ZNAV_FM_ROOT);
    $f = str_replace('\\', '/', $full);
    return $f === $root ? '' : ltrim(substr($f, strlen($root)), '/');
}

/** 递归删除目录 / 文件 */
function fm_rrmdir($dir)
{
    if (is_file($dir) || is_link($dir)) return @unlink($dir);
    if (!is_dir($dir)) return false;
    $items = scandir($dir);
    foreach ($items as $it) {
        if ($it === '.' || $it === '..') continue;
        fm_rrmdir($dir . '/' . $it);
    }
    return @rmdir($dir);
}

/** 递归复制目录 / 文件 */
function fm_rcopy($src, $dst)
{
    if (is_file($src)) return @copy($src, $dst);
    if (!@mkdir($dst, 0775, true) && !is_dir($dst)) return false;
    foreach (scandir($src) as $it) {
        if ($it === '.' || $it === '..') continue;
        if (!fm_rcopy($src . '/' . $it, $dst . '/' . $it)) return false;
    }
    return true;
}

function fm_dir_size($dir)
{
    $s = 0;
    foreach (scandir($dir) as $it) {
        if ($it === '.' || $it === '..') continue;
        $p = $dir . '/' . $it;
        $s += is_dir($p) ? fm_dir_size($p) : filesize($p);
    }
    return $s;
}

/**
 * 快速判断一个 zip 是不是「可导入的包」（只读目录结构，开销极小，绝不解压）
 * ① 含 manifest.json → 标准媒体包
 * ② 整站源码包 → 明确拒绝
 * ③ 全是图片/视频但没有清单 → 图片文件夹包，可按原文件名还原
 */
function znav_mi_probe($path)
{
    $r = array('name' => basename($path), 'path' => fm_rel(str_replace('\\', '/', $path)),
               'size' => @filesize($path), 'mtime' => @filemtime($path), 'valid' => false, 'kind' => '');
    if (!is_file($path)) return $r;
    $z = new ZipArchive();
    if (@$z->open($path) !== true) { $r['kind'] = '打不开（非标准 zip）'; return $r; }
    $names = znav_mi_zip_names($z);
    $z->close();
    foreach ($names as $nm) {
        if (strtolower(basename($nm)) === 'manifest.json') { $r['valid'] = true; $r['kind'] = '媒体包（含清单）'; return $r; }
    }
    $flat = strtolower(implode(' ', $names));
    if (preg_match('/(^|\/)(index|api|config|install)\.php/', $flat) || strpos($flat, 'assets/admin.js') !== false || strpos($flat, 'lib/db.php') !== false) {
        $r['kind'] = '整站源码/完整包（不可作为媒体包导入）'; return $r;
    }
    $nMedia = 0;
    foreach ($names as $nm) { if (znav_mi_is_media($nm)) $nMedia++; }
    if ($nMedia > 0) {
        $r['valid'] = true; $r['kind'] = '图片/视频文件夹包（' . $nMedia . ' 个文件，按原名还原）'; return $r;
    }
    if ($names && preg_match('/\.(png|jpe?g|gif|webp|svg|ico)$/i', $flat)) $r['kind'] = '普通压缩包（无清单）';
    else $r['kind'] = '未知类型（' . count($names) . ' 个文件）';
    return $r;
}

/** 统计：数据库里引用了 uploads/ 下文件的条数、其中已真实存在的条数、以及存在但本身是小图（<128px）的条数 */
function znav_mi_count_matched()
{
    $refs = 0; $hit = 0; $small = 0;
    try {
        $db = znav_db();
        foreach ($db->query('SELECT logo, icon FROM sites')->fetchAll() as $r) {
            foreach (array('logo', 'icon') as $k) {
                $v = trim((string)$r[$k]);
                if ($v === '' || stripos($v, 'uploads/') !== 0) continue;
                $refs++;
                $p = __DIR__ . '/' . $v;
                if (!is_file($p)) continue;
                $hit++;
                $d = @getimagesize($p);   // 文件在、但当初备份时存的就是小 favicon（16~48px）→ 显示必然模糊
                if ($d && max($d[0], $d[1]) < 128) $small++;
            }
        }
        try {
            foreach ($db->query("SELECT content FROM hub_blocks WHERE type='video'")->fetchAll() as $r) {
                $c = json_decode((string)$r['content'], true);
                if (!is_array($c)) continue;
                foreach (array('url', 'cover') as $k) {
                    $v = trim((string)(isset($c[$k]) ? $c[$k] : ''));
                    if ($v === '' || stripos($v, 'uploads/') !== 0) continue;
                    $refs++;
                    $p = __DIR__ . '/' . $v;
                    if (!is_file($p)) continue;
                    $hit++;
                    $d = @getimagesize($p);
                    if ($d && max($d[0], $d[1]) < 128) $small++;
                }
            }
        } catch (Exception $e) { /* 旧库无该表 */ }
    } catch (Exception $e) { /* 忽略 */ }
    return array('refs' => $refs, 'hit' => $hit, 'small' => $small);
}

try {
/** 导入媒体包核心（供 web 上传与服务器本地文件两条路共用）：还原媒体文件与网址/视频 */
/**
 * 媒体包导入引擎（分批版）：大包（上千张图）不再一次跑完导致超时中断，
 * 改为「start 建任务 → step 每次处理 N 条 → 前端轮询显示进度」。
 * 任务状态存 uploads/.import_<id>.json，处理到哪算哪，永不丢进度。
 */
function znav_mi_job_file($id)
{
    return __DIR__ . '/uploads/.import_' . preg_replace('/[^a-z0-9]/i', '', (string)$id) . '.json';
}

/** 清理 2 小时前的残留任务文件 */
function znav_mi_job_gc()
{
    $d = __DIR__ . '/uploads';
    if (!is_dir($d)) return;
    $fh = @opendir($d);
    if (!$fh) return;
    while (($f = readdir($fh)) !== false) {
        if (strpos($f, '.import_mi') !== 0) continue;
        $p = $d . '/' . $f;
        if (is_file($p) && @filemtime($p) < time() - 7200) @unlink($p);
    }
    closedir($fh);
}

/** 允许的媒体扩展名（图片 + 视频 + 图标） */
function znav_mi_media_exts()
{
    return array('png', 'jpg', 'jpeg', 'gif', 'webp', 'svg', 'ico', 'bmp', 'avif',
                 'mp4', 'webm', 'mov', 'm4v', 'avi', 'mkv', 'ogv', 'mp3', 'm4a', 'wav', 'ogg');
}

/** 是否媒体文件（按扩展名） */
function znav_mi_is_media($nm)
{
    return in_array(strtolower(pathinfo($nm, PATHINFO_EXTENSION)), znav_mi_media_exts(), true);
}

/**
 * 「图片文件夹包」的目标还原路径：
 * 包内 xxx/uploads/logos/a.png、logos/a.png、备份目录/uploads/logos/a.png、a.png
 * 统统归一到站点 uploads/logos/a.png；已经是 uploads/ 下的路径则原样保留。
 * 返回相对路径，非法（越界）返回 null。
 */
function znav_mi_restore_target($nm)
{
    $rel = str_replace('\\', '/', trim((string)$nm, '/'));
    if ($rel === '' || strpos($rel, '..') !== false) return null;
    $parts = explode('/', $rel);
    // 顶层不是 uploads/ 说明外面套了一层文件夹（如 logos/、nav备份/）→ 去掉它
    if (count($parts) > 1 && strtolower($parts[0]) !== 'uploads') array_shift($parts);
    $rel = implode('/', $parts);
    if (strtolower(substr($rel, 0, 8)) !== 'uploads/') $rel = 'uploads/logos/' . $rel;
    if (strpos($rel, '..') !== false || substr($rel, 0, 8) !== 'uploads/') return null;
    return $rel;
}

/** 宽松 JSON 解析：容忍 UTF-8 BOM、首尾空白、编辑器追加的尾部垃圾 */
function znav_mi_json($s)
{
    if ($s === false || $s === null || $s === '') return null;
    $s = (string)$s;
    if (substr($s, 0, 3) === "\xEF\xBB\xBF") $s = substr($s, 3);
    $s = trim($s);
    if ($s === '') return null;
    $v = json_decode($s, true);
    if (is_array($v)) return $v;
    $a = strpos($s, '{'); $b = strrpos($s, '}');
    if ($a !== false && $b !== false && $b > $a) {
        $v = json_decode(substr($s, $a, $b - $a + 1), true);
        if (is_array($v)) return $v;
    }
    return null;
}

/** 列出 zip 内所有条目名（统一斜杠） */
function znav_mi_zip_names(ZipArchive $zip)
{
    $names = array();
    $n = $zip->numFiles;
    for ($i = 0; $i < $n; $i++) {
        $st = @$zip->statIndex($i);
        if (!is_array($st) || empty($st['name'])) continue;
        $names[] = str_replace('\\', '/', (string)$st['name']);
    }
    return $names;
}

/**
 * 在 zip 里定位 manifest：
 * ① 根目录 manifest.json（标准导出）
 * ② 任意层级 manifest.json（解压后又套了一层文件夹时最常见 → 自动适配）
 * ③ 根目录任意 *.json，只要内容含 sites / videos 就认
 * 返回 array(manifest => 数组|null, entry => 命中路径, prefix => 媒体路径前缀, names => 全部条目)
 */
function znav_mi_locate_manifest(ZipArchive $zip)
{
    $names = znav_mi_zip_names($zip);
    $out = array('manifest' => null, 'entry' => '', 'prefix' => '', 'names' => $names);

    $hits = array();
    foreach ($names as $nm) {
        if (strtolower(basename($nm)) === 'manifest.json') $hits[] = $nm;
    }
    usort($hits, function ($a, $b) { return substr_count($a, '/') - substr_count($b, '/'); });
    foreach ($hits as $nm) {
        $m = znav_mi_json($zip->getFromName($nm));
        if (is_array($m)) {
            $out['manifest'] = $m; $out['entry'] = $nm;
            $d = dirname($nm);
            $out['prefix'] = ($d === '.' || $d === '/' ) ? '' : rtrim($d, '/') . '/';
            return $out;
        }
    }
    // 根目录其它 json（有些打包工具会改名 / 手工保存过）
    foreach ($names as $nm) {
        if (strpos($nm, '/') !== false || strtolower(substr($nm, -5)) !== '.json') continue;
        // 跳过系统任务文件（.import_*.json 是导入进度存档，含空的 sites/videos 键，
        // 打包 uploads 目录时容易被误带进 zip —— 绝不能当成清单，否则报「没有可导入内容」）
        if (strpos(basename($nm), '.') === 0 || strpos(basename($nm), '.import_') === 0) continue;
        $m = znav_mi_json($zip->getFromName($nm));
        if (is_array($m) && (isset($m['sites']) || isset($m['videos']))) {
            $out['manifest'] = $m; $out['entry'] = $nm; $out['prefix'] = '';
            return $out;
        }
    }
    return $out;
}

/** 找不到 manifest 时，告诉用户「这个包里到底是什么」，而不是干巴巴一句错误 */
function znav_mi_manifest_err($names)
{
    $total = count($names);
    if (!$total) return '压缩包是空的（0 个文件），可能上传/解压未完成，请重新导出一次';
    $sample = array_slice($names, 0, 6);
    $flat = strtolower(implode(' ', $names));
    $imgs = 0; $json = 0;
    foreach ($names as $nm) {
        $e = strtolower(pathinfo($nm, PATHINFO_EXTENSION));
        if (in_array($e, array('png', 'jpg', 'jpeg', 'gif', 'webp', 'svg', 'ico'), true)) $imgs++;
        if ($e === 'json') $json++;
    }
    $msg = 'manifest.json 缺失，这不像本系统导出的媒体包。包里共 ' . $total . ' 个文件：' . implode('、', $sample) . ($total > 6 ? ' …' : '');
    if (strpos($flat, 'index.php') !== false || strpos($flat, 'assets/') !== false || strpos($flat, 'lib/') !== false) {
        $msg .= '。看内容是整站源码/备份包，请到「系统备份」用「还原」处理，而不是这里';
    } elseif ($imgs > 0 && $json === 0) {
        $msg .= '。看内容只是一堆图片，缺少清单文件无法对应网址。正确做法：在另一台站点的「后台 → 媒体/备份 → 勾选导出」生成包，再拿过来导入';
    } else {
        $msg .= '。请确认解压/转存时没有改动内部结构（manifest.json 应在包内最外层）';
    }
    return $msg;
}

/** 第一步：建任务（读出 manifest，把待处理清单落盘） */
function znav_media_import_start($zipPath, $overwrite)
{
    znav_mi_job_gc();
    $zip = new ZipArchive();
    $rc = @$zip->open($zipPath);
    if ($rc !== true) return array('error' => 'zip 打开失败（代码 ' . $rc . '），文件可能损坏或不是标准 zip：' . basename($zipPath));
    $loc  = znav_mi_locate_manifest($zip);
    // 包里的媒体文件清单（含大小），供「无 manifest 的图片文件夹包」兜底还原使用
    $mediaFiles = array();
    foreach ($loc['names'] as $nm) {
        $st = @$zip->statName($nm);
        if (!is_array($st) || intval($st['size']) <= 0) continue;         // 目录/空文件跳过
        if (!znav_mi_is_media($nm)) continue;
        $mediaFiles[] = $nm;
    }
    $zip->close();

    // ① 没有 manifest，但全是图片/视频 → 判定为「图片文件夹包」，按原文件名还原到 uploads/
    //    （典型场景：备份或从别处拷出来的 uploads/logos 目录，DB 里已经引用了这些文件名）
    if (!is_array($loc['manifest'])) {
        if (!count($mediaFiles)) return array('error' => znav_mi_manifest_err($loc['names']));
        sort($mediaFiles);
        $id  = 'mi' . date('YmdHis') . substr(md5(uniqid('', true)), 0, 6);
        $job = array(
            'zip' => fm_rel(str_replace('\\', '/', $zipPath)), 'overwrite' => (bool)$overwrite,
            'prefix' => '', 'entry' => '', 'mode' => 'files',
            'files' => $mediaFiles, 'fi' => 0,
            'sites' => array(), 'videos' => array(), 'si' => 0, 'vi' => 0,
            'restored' => 0, 'replaced' => 0, 'skipped' => 0, 'updated' => 0, 'kept' => 0, 'added' => 0,
            'videosAdded' => 0, 'errors' => array(),
        );
        if (@file_put_contents(znav_mi_job_file($id), json_encode($job, JSON_UNESCAPED_UNICODE)) === false) {
            return array('error' => '无法写入任务文件（uploads 目录不可写）');
        }
        return array('ok' => true, 'job' => $id, 'sitesTotal' => 0, 'videosTotal' => 0,
                     'mode' => 'files', 'total' => count($mediaFiles));
    }
    $manifest = $loc['manifest'];
    $sites  = (isset($manifest['sites'])  && is_array($manifest['sites']))  ? array_values($manifest['sites'])  : array();
    $videos = (isset($manifest['videos']) && is_array($manifest['videos'])) ? array_values($manifest['videos']) : array();
    if (!count($sites) && !count($videos)) {
        // 有 manifest 但没有内容：可能是空导出，或字段在别的名字下（尽力兜一层）
        foreach (array('data', 'items', 'list', 'sites_list') as $k) {
            if (isset($manifest[$k]) && is_array($manifest[$k]) && count($manifest[$k])) {
                $sites = array_values($manifest[$k]); break;
            }
        }
    }
    if (!count($sites) && !count($videos)) {
        return array('error' => '这个包里有 manifest.json（' . ($loc['entry'] ?: '根目录') . '），但里面没有可导入的 sites/videos 内容，可能是空导出或被手工清空了');
    }
    $id  = 'mi' . date('YmdHis') . substr(md5(uniqid('', true)), 0, 6);
    $job = array(
        'zip' => fm_rel(str_replace('\\', '/', $zipPath)), 'overwrite' => (bool)$overwrite,
        'prefix' => (string)$loc['prefix'], 'entry' => (string)$loc['entry'],
        'sites' => $sites, 'videos' => $videos, 'si' => 0, 'vi' => 0,
        'updated' => 0, 'kept' => 0, 'added' => 0, 'videosAdded' => 0, 'errors' => array(),
    );
    if (@file_put_contents(znav_mi_job_file($id), json_encode($job, JSON_UNESCAPED_UNICODE)) === false) {
        return array('error' => '无法写入任务文件（uploads 目录不可写）');
    }
    return array('ok' => true, 'job' => $id, 'sitesTotal' => count($sites), 'videosTotal' => count($videos),
                 'total' => count($sites) + count($videos));
}

/**
 * 第二步：处理一批（每批 $batch 条，一批一次 HTTP 请求，绝不超时）
 * 返回进度 + 计数；全部处理完后 done=true 并给出最终汇总。
 */
function znav_media_import_step($jobId, $batch = 40)
{
    $f = znav_mi_job_file($jobId);
    if (!is_file($f)) return array('error' => '导入任务不存在或已完成（刷新页面重新开始即可）');
    $job = json_decode((string)file_get_contents($f), true);
    if (!is_array($job) || empty($job['zip'])) { @unlink($f); return array('error' => '任务数据损坏，请重新开始导入'); }
    @set_time_limit(300);

    $zp = fm_path($job['zip'], true);
    if ($zp === null || !is_file($zp)) { @unlink($f); return array('error' => 'zip 文件已不在服务器：' . $job['zip']); }
    $zip = new ZipArchive();
    $rc = @$zip->open($zp);
    if ($rc !== true) { @unlink($f); return array('error' => 'zip 打开失败（代码 ' . $rc . '），文件可能损坏：' . $job['zip']); }

    // 建立「文件名 → zip 内实际路径」索引：即使包里多套了一层目录也能正确取到图
    $baseMap = array();
    foreach (znav_mi_zip_names($zip) as $nm) {
        $k = strtolower(basename($nm));
        if (!isset($baseMap[$k])) $baseMap[$k] = $nm;
    }
    $prefix = isset($job['prefix']) ? (string)$job['prefix'] : '';

    // zip 内文件读取（懒加载 + 三级兜底：原路径 → 前缀拼 → 文件名匹配）
    $readMedia = function ($zp2) use ($zip, $baseMap, $prefix) {
        if ($zp2 === '' || $zp2 === null) return '';
        $p = ltrim((string)$zp2, '/');
        if ($p === '') return '';
        $b = @$zip->getFromName($p);
        if ($b !== false && $b !== '') return $b;
        if ($prefix !== '') {
            $b = @$zip->getFromName($prefix . $p);
            if ($b !== false && $b !== '') return $b;
        }
        $k = strtolower(basename($p));
        if (isset($baseMap[$k])) {
            $b = @$zip->getFromName($baseMap[$k]);
            if ($b !== false) return $b;
        }
        return '';
    };
    // 媒体落盘：内容寻址命名（同内容同名 → 重复导入自动覆盖，绝不产生重复文件、无需任何提示）
    $storeMedia = function ($bytes, $zp2) {
        if ($bytes === '') return '';
        $ext = strtolower(pathinfo($zp2, PATHINFO_EXTENSION));
        if (in_array($ext, array('mp4', 'webm', 'mov', 'm4v', 'avi', 'mkv', 'ogv'), true)) {
            return znav_video_store_dedup($bytes, $ext);
        }
        return znav_logo_store_dedup($bytes, 1024);
    };

    $db = znav_db();
    // 分类缓存：名字 => id（不存在则建）
    $catCache = array();
    foreach ($db->query('SELECT id,name FROM categories')->fetchAll() as $c) $catCache[trim($c['name'])] = intval($c['id']);
    $ensureCat = function ($name) use (&$catCache, $db) {
        $name = trim((string)$name);
        if ($name === '' || $name === '未分类') return 0;
        if (isset($catCache[$name])) return $catCache[$name];
        $db->prepare('INSERT INTO categories(name,icon,parent_id,sort) VALUES(?,?,NULL,99)')->execute(array(mb_substr($name, 0, 30), '📁'));
        $id = intval($db->lastInsertId());
        $catCache[$name] = $id;
        return $id;
    };
    $haveUrls = array();
    foreach ($db->query('SELECT id,url FROM sites')->fetchAll() as $r) $haveUrls[rtrim((string)$r['url'], '/')] = intval($r['id']);
    $insSite = $db->prepare('INSERT INTO sites(category_id,name,url,descr,icon,logo,add_date,sort) VALUES(?,?,?,?,?,?,?,?)');

    $batch = max(5, min(200, intval($batch)));
    $processed = 0;
    $nSites = count($job['sites']);
    while ($processed < $batch) {
        if ($job['si'] < $nSites) {
            $s = $job['sites'][$job['si']++];
            $url = trim((string)(isset($s['url']) ? $s['url'] : ''));
            if ($url !== '') {
                try {
                    $newLogo = isset($s['logo']) ? $storeMedia($readMedia($s['logo']), $s['logo']) : '';
                    $newIcon = isset($s['icon']) ? $storeMedia($readMedia($s['icon']), $s['icon']) : '';
                    // 清单里有、但包里实际没有该文件 → 计入 missing，绝不因此把已有图清空
                    if ((isset($s['logo']) && $readMedia($s['logo']) === '') || (isset($s['icon']) && $readMedia($s['icon']) === '')) {
                        $job['missing'] = intval(isset($job['missing']) ? $job['missing'] : 0) + 1;
                    }
                    $key = rtrim($url, '/');
                    if (isset($haveUrls[$key])) {
                        $sid = $haveUrls[$key];
                        $cur = $db->prepare('SELECT logo,icon FROM sites WHERE id=?');
                        $cur->execute(array($sid));
                        $row = $cur->fetch();
                        if ($row) {
                            // 保留策略：overwrite=覆盖已有；否则只补空缺；包里缺图时一定不覆盖
                            $effLogo = ($newLogo !== '' && ($job['overwrite'] || trim((string)$row['logo']) === '')) ? $newLogo : (string)$row['logo'];
                            $effIcon = ($newIcon !== '' && ($job['overwrite'] || trim((string)$row['icon']) === '')) ? $newIcon : (string)$row['icon'];
                            $db->prepare('UPDATE sites SET logo=?, icon=? WHERE id=?')->execute(array($effLogo, $effIcon, $sid));
                            if ($job['overwrite']) $job['updated']++; else $job['kept']++;
                        }
                    } else {
                        $cid = $ensureCat(isset($s['cat']) ? $s['cat'] : '');
                        $insSite->execute(array($cid, mb_substr(trim((string)$s['name']), 0, 60), mb_substr($url, 0, 500),
                            mb_substr(trim((string)(isset($s['descr']) ? $s['descr'] : '')), 0, 200), $newIcon, $newLogo, date('Y-m-d H:i:s'), 99));
                        $haveUrls[$key] = intval($db->lastInsertId());
                        $job['added']++;
                    }
                } catch (Exception $e) {
                    $job['errors'][] = '「' . (isset($s['name']) ? $s['name'] : $url) . '」导入失败：' . $e->getMessage();
                }
            }
            $processed++;
        } elseif ($job['vi'] < count($job['videos'])) {
            // 视频块：按 标题+已有本地文件 判重；找不到就新建
            $v = $job['videos'][$job['vi']++];
            try {
                $newUrl   = isset($v['url'])   ? $storeMedia($readMedia($v['url']),   $v['url'])   : '';
                $newCover = isset($v['cover']) ? $storeMedia($readMedia($v['cover']), $v['cover']) : '';
                if ($newUrl !== '' || $newCover !== '') {
                    $title = mb_substr(trim((string)(isset($v['title']) ? $v['title'] : '')), 0, 60);
                    $db->prepare('INSERT INTO hub_blocks(type,title,content,sort,enabled,created_at) VALUES(?,?,?,?,1,?)')
                       ->execute(array('video', $title !== '' ? $title : '导入的视频',
                            json_encode(array('url' => $newUrl, 'cover' => $newCover, 'desc' => (string)(isset($v['desc']) ? $v['desc'] : '')), JSON_UNESCAPED_UNICODE),
                            99, date('Y-m-d H:i:s')));
                    $job['videosAdded']++;
                }
            } catch (Exception $e) {
                $job['errors'][] = '视频「' . (isset($v['title']) ? $v['title'] : '') . '」导入失败：' . $e->getMessage();
            }
            $processed++;
        } else {
            break;
        }
    }
    // B) 「图片文件夹包」模式：没有 manifest，按原文件名把 media 还原回 uploads/
    if (!empty($job['files']) && is_array($job['files'])) {
        $nFiles = count($job['files']);
        while ($processed < $batch && $job['fi'] < $nFiles) {
            $nm = $job['files'][$job['fi']++];
            try {
                $bytes = $readMedia($nm);
                if ($bytes === '') { $job['skipped']++; $processed++; continue; }
                $rel = znav_mi_restore_target($nm);
                if ($rel === null) { $job['skipped']++; $processed++; continue; }
                $dst = __DIR__ . '/' . $rel;
                if (is_file($dst)) {
                    if (md5_file($dst) === md5($bytes)) { $job['skipped']++; $processed++; continue; }
                    $job['replaced']++;
                } else {
                    if (!is_dir(dirname($dst)) && !@mkdir(dirname($dst), 0775, true) && !is_dir(dirname($dst))) {
                        $job['errors'][] = '无法创建目录：' . dirname($rel);
                        $processed++; continue;
                    }
                    $job['restored']++;
                }
                if (@file_put_contents($dst, $bytes) === false) {
                    $job['errors'][] = '写入失败（目录不可写）：' . $rel;
                }
            } catch (Exception $e) {
                $job['errors'][] = basename($nm) . '：' . $e->getMessage();
            }
            $processed++;
        }
        $zip->close();
        $done = $job['fi'] >= $nFiles;
        $out = array(
            'ok' => true, 'done' => $done, 'done_n' => $job['fi'], 'total' => $nFiles, 'mode' => 'files',
            'restored' => $job['restored'], 'replaced' => $job['replaced'], 'skipped' => $job['skipped'],
            'errors' => array_slice($job['errors'], 0, 10),
        );
        if ($done) {
            $m = znav_mi_count_matched();   // 还原后有多少正好被现有数据引用
            $out['matched'] = $m['hit']; $out['refs'] = $m['refs']; $out['small'] = $m['small'];
            @touch(dirname(__DIR__) . '/uploads/logos');   // 刷新目录版本号 → 前端 ?v= 变化，同名替换的高清图立即生效（不再吃 30 天浏览器缓存）
            @unlink($f);
        } else {
            @file_put_contents($f, json_encode($job, JSON_UNESCAPED_UNICODE));
        }
        return $out;
    }

    $zip->close();   // 媒体包分支：本批处理完才关 zip（files 分支在自己内部关闭）

    $total = $nSites + count($job['videos']);
    $doneN = $job['si'] + $job['vi'];
    $done  = $doneN >= $total;
    $out = array(
        'ok' => true, 'done' => $done, 'done_n' => $doneN, 'total' => $total, 'mode' => 'manifest',
        'updated' => $job['updated'], 'kept' => $job['kept'], 'added' => $job['added'],
        'videosAdded' => $job['videosAdded'], 'errors' => array_slice($job['errors'], 0, 10),
        'missing' => intval(isset($job['missing']) ? $job['missing'] : 0),
    );
    if ($done && intval(isset($job['missing']) ? $job['missing'] : 0) > 0) {
        $out['errors'][] = '有 ' . $job['missing'] . " 条记录的图片在包里实际找不到，已跳过（原有图标保持不动，不会被清掉）";
    }
    if ($done) {
        @touch(dirname(__DIR__) . '/uploads/logos');   // 刷新目录版本号（同 files 模式）
        @unlink($f);   // 任务完成，清理任务文件
    } else {
        @file_put_contents($f, json_encode($job, JSON_UNESCAPED_UNICODE));
    }
    return $out;
}

/** 一次性导入（兼容旧调用 / 小包）：内部走同一套分批引擎，跑完为止 */
function znav_media_import_zip($tmp, $overwrite)
{
    $st = znav_media_import_start($tmp, $overwrite);
    if (empty($st['ok'])) return $st;
    $out = array();
    for ($i = 0; $i < 4000; $i++) {
        $out = znav_media_import_step($st['job'], 60);
        if (empty($out['ok']) || !empty($out['done'])) break;
    }
    return $out;
}

/** 上传失败的细分化提示（按 PHP 错误码 / post_max_size 截断给出可执行建议） */
function znav_upload_error_msg()
{
    if (!empty($_FILES['file'])) {
        switch (intval($_FILES['file']['error'])) {
            case UPLOAD_ERR_INI_SIZE:
            case UPLOAD_ERR_FORM_SIZE:
                return '单片文件超出服务器限制（upload_max_filesize=' . ini_get('upload_max_filesize') . '）。系统已尝试自动放宽（.user.ini），请稍等 1 分钟重试；仍不行请把本实施例发生的具体报错发给作者。';
            case UPLOAD_ERR_PARTIAL: return '单片上传中断（网络波动），已自动重试；多次失败请检查网络';
            case UPLOAD_ERR_NO_TMP_DIR: return '服务器缺少 PHP 临时目录，请联系主机商';
            case UPLOAD_ERR_CANT_WRITE: return '服务器临时目录不可写，请联系主机商';
            case UPLOAD_ERR_EXTENSION: return '上传被 PHP 扩展中断';
        }
    }
    if (empty($_FILES) && intval(isset($_SERVER['CONTENT_LENGTH']) ? $_SERVER['CONTENT_LENGTH'] : 0) > 0) {
        return '上传数据被服务器整体丢弃：本次 POST ' . round(intval($_SERVER['CONTENT_LENGTH']) / 1048576, 1) . 'MB 超过 post_max_size=' . ini_get('post_max_size') . '。请在主机面板调大 post_max_size / upload_max_filesize，或改用「📂 从服务器导入」';
    }
    return '没有收到有效的 zip 文件（未检测到上传内容）';
}

// ---------------------------------------------------------------------------
// 上传限制：自动放宽（不依赖主机商）
// 做法：分片上传（前端把大文件切成小片）为主，同时自动写 .user.ini 提高上限为辅。
// .user.ini 只在 CGI/FastCGI(PHP-FPM) 下生效，其它环境被完全忽略（不会报错、不会 500），
// 因此比写 .htaccess 的 php_value 安全（后者在 PHP-FPM 上会导致整站 500）。
// ---------------------------------------------------------------------------
/** '512M' / '2G' / '-1' → 字节数 */
function znav_ini_bytes($v)
{
    $v = trim((string)$v);
    if ($v === '' ) return 0;
    if ($v === '-1') return PHP_INT_MAX;
    $n = (float)$v;
    $u = strtolower(substr($v, -1));
    if ($u === 'g') $n *= 1073741824;
    elseif ($u === 'm') $n *= 1048576;
    elseif ($u === 'k') $n *= 1024;
    return (int)$n;
}

/**
 * 尝试自动放宽 PHP 上传限制（写站点根目录 .user.ini）。
 * 只在当前上限明显偏小时写入一次；失败静默忽略（分片上传不依赖它）。
 */
function znav_upload_limit_boost()
{
    static $done = false;
    if ($done) return;
    $done = true;
    $want = 512 * 1048576;
    $cur = min(znav_ini_bytes(ini_get('upload_max_filesize')), znav_ini_bytes(ini_get('post_max_size')));
    if ($cur >= $want) return;                       // 已经够大，不动
    $file = __DIR__ . '/.user.ini';
    $lines = array(
        'upload_max_filesize = 512M',
        'post_max_size = 512M',
        'memory_limit = 512M',
        'max_execution_time = 600',
        'max_input_time = 600',
    );
    $old = @is_file($file) ? @file_get_contents($file) : '';
    if ($old === false) $old = '';
    // 已放宽过就跳过（避免反复写）
    if (strpos($old, 'upload_max_filesize = 512M') !== false) return;
    $new = rtrim($old, "\r\n");
    if ($new !== '') $new .= "\r\n\r\n; NavVerse：放宽上传限制（自动生成，可删除）\r\n";
    $new .= implode("\r\n", $lines) . "\r\n";
    @file_put_contents($file, $new);
}

// 涉及上传/解压的动作先尝试自动放宽限制
if (in_array($action, array('media_import', 'media_import_local', 'fm_upload', 'fm_upload_chunk', 'fm_unzip'), true)) {
    znav_upload_limit_boost();
}

/** 清理分片上传产生的临时文件 / 空目录 */
function znav_clean_tmp_dir($tmpDir, $uploadId = '')
{
    if ($uploadId !== '') @unlink(rtrim($tmpDir, '/') . '/' . $uploadId . '.part');
    if ($uploadId !== '') @unlink(rtrim($tmpDir, '/') . '/' . $uploadId . '.json');
    $left = @scandir($tmpDir);
    if (is_array($left) && count($left) <= 2) @rmdir($tmpDir);
}

/** 供前端计算分片大小：返回服务器可接受的单次请求上限（字节） */
function znav_upload_window()
{
    $a = znav_ini_bytes(ini_get('upload_max_filesize'));
    $b = znav_ini_bytes(ini_get('post_max_size'));
    $m = min($a ? $a : PHP_INT_MAX, $b ? $b : PHP_INT_MAX);
    if ($m <= 0 || $m >= PHP_INT_MAX) return 8 * 1048576;   // 无限制 → 给 8MB
    return max(65536, (int)floor($m * 0.6));                // 留 40% 余量
}

switch ($action) {

// ================= 公开接口 =================
case 'summary': {
    $db = znav_db();
    $mains = $db->query("
        SELECT c.id, c.name, c.icon,
          (SELECT COUNT(*) FROM sites s WHERE s.category_id=c.id
             OR s.category_id IN (SELECT id FROM categories c2 WHERE c2.parent_id=c.id)) AS count
        FROM categories c WHERE c.parent_id IS NULL ORDER BY c.sort, c.id")->fetchAll();
    foreach ($mains as &$m) {
        $st = $db->prepare("
            SELECT c.id, c.name, c.icon, COUNT(s.id) AS count
            FROM categories c LEFT JOIN sites s ON s.category_id=c.id
            WHERE c.parent_id=? GROUP BY c.id ORDER BY c.sort, c.id");
        $st->execute(array($m['id']));
        $m['children'] = $st->fetchAll();
        $m['id'] = intval($m['id']); $m['count'] = intval($m['count']);
        foreach ($m['children'] as &$ch) { $ch['id'] = intval($ch['id']); $ch['count'] = intval($ch['count']); }
    }
    $ads = $db->query('SELECT id,title,descr,image,link,position,img_w,img_h,style,img_fit,radius,bgcolor,target FROM ads WHERE enabled=1 ORDER BY position,sort,id')->fetchAll();
    foreach ($ads as &$a) {
        $a['id'] = intval($a['id']); $a['img_w'] = intval($a['img_w']); $a['img_h'] = intval($a['img_h']);
        $a['radius'] = intval($a['radius']);
        if ($a['style'] === null || $a['style'] === '') $a['style'] = 'image';
    }
    $arts = $db->query('SELECT id,title,summary,content,image,link,page_slug AS pageSlug FROM articles WHERE enabled=1 ORDER BY sort,id LIMIT 24')->fetchAll();
    foreach ($arts as &$a) { $a['id'] = intval($a['id']); }
    $pageCards = $db->query("SELECT id,title,slug,images,substr(content,1,400) AS content FROM pages WHERE enabled=1 ORDER BY sort,id")->fetchAll();
    foreach ($pageCards as &$pc) { $pc['id'] = intval($pc['id']); }
    $hbRaw = znav_setting('homeBlocks', '');
    $homeBlocks = array();
    if ($hbRaw !== '') {
        $hbJson = json_decode($hbRaw, true);
        if (is_array($hbJson)) $homeBlocks = $hbJson;
    }
    $ct = znav_contact();   // 底部联系我（QQ / 微信）
    znav_json(array(
        'ok' => true,
        'seo' => array(
            'siteUrl' => znav_setting('siteUrl', ''),
            'siteUrlNow' => znav_seo_site_url(),
            'siteSeoDesc' => znav_setting('siteSeoDesc', ''),
            'siteSeoKeywords' => znav_setting('siteSeoKeywords', ''),
            'seoBaiduVerify' => znav_setting('seoBaiduVerify', ''),
            'seoGoogleVerify' => znav_setting('seoGoogleVerify', ''),
            'seoBingVerify' => znav_setting('seoBingVerify', ''),
            'seoSogouVerify' => znav_setting('seoSogouVerify', ''),
            'seoS360Verify' => znav_setting('seoS360Verify', ''),
            'seoBaiduSite' => znav_setting('seoBaiduSite', ''),
            'seoBaiduToken' => znav_setting('seoBaiduToken', ''),
            'seoIndexNowKey' => znav_setting('seoIndexNowKey', ''),
            'seoRobotsExtra' => znav_setting('seoRobotsExtra', ''),
        'hubSeoDesc' => znav_setting('hubSeoDesc', ''),
        'urlCount' => count(znav_seo_urls()),
        // 网络出口（本地 VPN/代理）
        'netProxyOn' => znav_setting('netProxyOn', '0') === '1',
        'netProxy' => znav_setting('netProxy', ''),
        'netProxyWorking' => znav_net_proxy() !== '',
        ),
        'siteName' => znav_setting('siteName'),
        'siteNameVisible' => znav_setting('siteNameVisible', '1') !== '0',
        'siteLogo' => znav_setting('siteLogo', ''),
        'lgv' => znav_logos_ver(),
        // 底部联系我：QQ / 微信（头像 + 悬停气泡）
        'ctOn' => $ct['on'], 'ctQQ' => $ct['qq'], 'ctWxId' => $ct['wxId'], 'ctQQAvatar' => $ct['qqAvatar'],
        'ctWxAvatar' => $ct['wxAvatar'], 'ctWxImg' => $ct['wxImg'], 'ctWxTip' => $ct['wxTip'],
        'defaultLogo' => znav_setting('defaultLogo', ''),
        'siteFavicon' => znav_setting('siteFavicon', ''),
        'logoSize' => intval(znav_setting('logoSize', '34')),
        'logoW' => intval(znav_setting('logoW', '0')),
        'logoH' => intval(znav_setting('logoH', '0')),
        'logoFit' => znav_setting('logoFit', 'fill'),
        'announcement' => znav_setting('announcement'),
        'bgPreset' => znav_setting('bgPreset', 'aurora'),
        'bgImage' => znav_setting('bgImage', ''),
        'totalSites' => intval($db->query('SELECT COUNT(*) c FROM sites')->fetch()['c']),
        'categories' => $mains,
        'ads' => $ads,
        'articles' => $arts,
        'homeContentShow' => znav_setting('homeContentShow', '1') === '1',
        'homeContentThumb' => znav_setting('homeContentThumb', '1') === '1',
        'homeItemLimit' => max(1, intval(znav_setting('homeItemLimit', '8'))),
        'thumbW' => max(40, intval(znav_setting('thumbW', '132'))),
        'thumbH' => max(30, intval(znav_setting('thumbH', '92'))),
        'cardLogoW' => max(24, min(96, intval(znav_setting('cardLogoW', '42')))),
        'cardLogoH' => max(24, min(96, intval(znav_setting('cardLogoH', '42')))),
        'cardMinW' => max(150, min(400, intval(znav_setting('cardMinW', '220')))),
        'cardMinH' => max(0, min(160, intval(znav_setting('cardMinH', '0')))),
        // 功能隐藏：开关 + 是否已在后台自定义过密码（密码哈希绝不下发前端）
        'featLockOn' => znav_setting('featLockOn', '1') === '1',
        'featLockSet' => trim((string)znav_setting('featLockPwd', '')) !== '',
        'licSig' => znav_feat_sig(),   // 解锁凭据签名：授权重新激活后变化 → 后台自动重新上锁
        // 源码更新：检查地址（留空 = 由授权服务器域名推导）
        'updateCheckUrl' => znav_setting('updateCheckUrl', ''),
        'pageWidth' => znav_setting('pageWidth', 'wide'),
        'homeMode' => znav_setting('homeMode', 'logo'),   // 前台默认显示模式：logo=图文（默认）/ text=全文字
        'heroImage' => znav_setting('heroImage', ''),
        'heroImgW' => intval(znav_setting('heroImgW', '0')),
        'heroImgH' => intval(znav_setting('heroImgH', '0')),
        'heroTextShow' => znav_setting('heroTextShow', '1') !== '0',
        'homeBlocks' => $homeBlocks,
        'pageCards' => $pageCards,
        'sideModules' => znav_side_modules($db),
        'sideRemovedPages' => znav_setting('sideRemovedPages', ''),
        // 后台专用：含已隐藏模块（让后台能显示 🚫 并一键恢复）
        'sideModulesFull' => znav_side_modules($db, true),
        'sideArtsShow' => znav_setting('sideArtsShow', '1') !== '0',
        'sideOrder' => znav_setting('sideOrder', ''),
        'sidebarPos' => znav_setting('sidebarPos', 'left'),
        'homeSecOrder' => znav_setting('homeSecOrder', ''),
        'homeLayout' => znav_setting('homeLayout', ''),
        'adCols' => znav_setting('adCols', '1'),
        'heroTagIds' => znav_setting('heroTagIds', ''),
        'visitsEnabled' => znav_setting('visitsEnabled', '1') !== '0',
        // 右栏模块：关闭 / 缩小状态（键：ads / arts / pages）
        'sideClosed' => znav_setting('sideClosed', ''),
        'sideCollapsed' => znav_setting('sideCollapsed', ''),
        // 右栏每个模块的图片/缩略图尺寸（0 = 用内置默认）
        'sideAdsImgW' => max(0, min(600, intval(znav_setting('sideAdsImgW', '0')))),
        'sideAdsImgH' => max(0, min(600, intval(znav_setting('sideAdsImgH', '0')))),
        'sideArtsImgW' => max(0, min(600, intval(znav_setting('sideArtsImgW', '0')))),
        'sideArtsImgH' => max(0, min(600, intval(znav_setting('sideArtsImgH', '0')))),
        'sidePagesImgW' => max(0, min(600, intval(znav_setting('sidePagesImgW', '0')))),
        'sidePagesImgH' => max(0, min(600, intval(znav_setting('sidePagesImgH', '0')))),
        // 右栏「更多内容」已下线：仅保留历史设置键，不再下发给前台
        // 后台左侧菜单名称（可整体改名，空 = 用内置默认）
        'adminMenuNames' => json_decode(znav_setting('adminMenuNames', '{}'), true) ?: array(),
        // 首页布局方案（命名保存 / 选择还原）
        'layoutPresets' => json_decode(znav_setting('layoutPresets', '[]'), true) ?: array(),
        // 首页右栏模块列表（后台可增删 / 改名 / 排序）
        'sideModules' => znav_side_modules($db),
        // 被手动删除的页面模块 id（不再自动补回）
        'sideRemovedPages' => znav_setting('sideRemovedPages', ''),
        // 右栏展示模式：auto=图文自适应 / image=纯图片 / photo=图文 / text=纯文字
        'sideDisplay' => znav_setting('sideDisplay', 'auto'),
        // 站点名称自定义样式（大小 / 颜色 / 字体）
        'siteNameStyle' => json_decode(znav_setting('siteNameStyle', ''), true) ?: array(),
        // 自定义背景图列表（最多 5 张，可删除）
        'bgImages' => json_decode(znav_setting('bgImages', '[]'), true) ?: array(),
        // 顶部导航树（父页面 -> 子页面）
        'navTree' => znav_nav_tree(),
        // 常用网址：后台自定义挑选（为空则按点击量自动取）
        'hotSiteIds' => znav_setting('hotSiteIds', ''),
        // 下载页标题 / 描述（后台可自定义）
        'downloadsTitle' => znav_setting('downloadsTitle', '软件下载'),
        'downloadsDesc' => znav_setting('downloadsDesc', ''),
        // 聚合页（Link3 风格）设置
        'hubEnabled' => znav_setting('hubEnabled', '1') !== '0',
        'hubName' => znav_setting('hubName', '聚合页'),
        'hubTitle' => znav_setting('hubTitle', '聚合主页'),
        'hubIntro' => znav_setting('hubIntro', ''),
        'hubBtnText' => znav_setting('hubBtnText', '聚合页'),
        'hubBtnPos' => znav_setting('hubBtnPos', 'nav'),
        // 鼠标样式（0=默认 1~5=内置样式；仅访客在前台自选时生效）
        'cursorStyle' => max(0, min(5, intval(znav_setting('cursorStyle', '0')))),
        // 自定义版心宽度（px，供「自定义」档使用）
        'customPageW' => max(0, min(4000, intval(znav_setting('customPageW', '0')))),
        // 右上角齿轮面板：每一项是否显示（后台可单独开关）；chat = 右下角在线交流悬浮按钮
        'dock' => array(
            'pageWidth' => znav_setting('dockPageWidth', '1') !== '0',
            'cursor'    => znav_setting('dockCursor', '1') !== '0',
            'bg'        => znav_setting('dockBg', '1') !== '0',
            'skin'      => znav_setting('dockSkin', '1') !== '0',
            'theme'     => znav_setting('dockTheme', '1') !== '0',
            'admin'     => znav_setting('dockAdmin', '1') !== '0',
            'lang'      => znav_setting('dockLang', '1') !== '0',
            'user'      => znav_setting('dockUser', '1') !== '0',
            'chat'      => znav_setting('dockChat', '1') !== '0',
            'music'     => znav_setting('dockMusic', '1') !== '0',
        ),
        // 背景音乐列表（后台「系统设置 → 背景音乐」维护，前台侧栏 🎵 播放器使用）
        'musicList' => (function () {
            $ml = json_decode((string)znav_setting('musicList', '[]'), true);
            if (!is_array($ml)) $ml = array();
            $out = array();
            foreach ($ml as $m) {
                if (!is_array($m)) continue;
                $n = trim((string)(isset($m['name']) ? $m['name'] : ''));
                $u = trim((string)(isset($m['url']) ? $m['url'] : ''));
                if ($u === '') continue;
                $out[] = array('name' => $n !== '' ? mb_substr($n, 0, 60) : '未命名', 'url' => mb_substr($u, 0, 500));
            }
            return $out;
        })(),
    ));
}

case 'sites': {
    $db = znav_db();
    $page = max(1, intval(isset($_GET['page']) ? $_GET['page'] : 1));
    // pageSize：数字 ≤2000，或 all=全部
    $psRaw = isset($_GET['pageSize']) ? trim((string)$_GET['pageSize']) : znav_setting('pageSize', '48');
    $pageSize = ($psRaw === 'all' || $psRaw === '0') ? 2000 : min(2000, max(6, intval($psRaw)));
    $where = array(); $params = array();
    // 按指定 id 列表取（常用网址自定义）
    $idOrder = array();
    if (!empty($_GET['ids'])) {
        foreach (explode(',', (string)$_GET['ids']) as $t) { $t = intval(trim($t)); if ($t > 0) $idOrder[] = $t; }
        $idOrder = array_slice(array_unique($idOrder), 0, 200);
        if ($idOrder) $where[] = 's.id IN (' . implode(',', $idOrder) . ')';
    }
    if (!empty($_GET['subId'])) {
        $where[] = 's.category_id = ?'; $params[] = intval($_GET['subId']);
    } elseif (!empty($_GET['categoryId'])) {
        $ids = znav_cat_ids($_GET['categoryId']);
        $where[] = 's.category_id IN (' . implode(',', $ids) . ')';
    }
    if (!empty($_GET['q'])) {
        $kw = '%' . trim(mb_substr((string)$_GET['q'], 0, 50)) . '%';
        $where[] = '(s.name LIKE ? OR s.url LIKE ? OR s.descr LIKE ?)';
        array_push($params, $kw, $kw, $kw);
    }
    $W = $where ? 'WHERE ' . implode(' AND ', $where) : '';
    $st = $db->prepare("SELECT COUNT(*) c FROM sites s $W");
    $st->execute($params);
    $total = intval($st->fetch()['c']);
    // 排序：new=最新添加 hot=点击最多 name=名称（置顶始终靠前）
    $sort = isset($_GET['sort']) ? $_GET['sort'] : 'default';
    $orderMap = array(
        'default' => 's.pinned DESC, s.category_id, s.sort, s.id',
        'new'     => 's.pinned DESC, s.id DESC',
        'hot'     => 's.pinned DESC, s.clicks DESC, s.id ASC',
        // COLLATE NOCASE 是 SQLite 专属语法，MySQL/MariaDB 下会直接 1064；
        // MySQL 的 utf8mb4 排序规则本身不区分大小写，无需 COLLATE
        'name'    => 's.pinned DESC, s.name' . (defined('ZNAV_DB_DRIVER') && ZNAV_DB_DRIVER === 'mysql' ? ' ASC' : ' COLLATE NOCASE ASC'),
        'ids'     => 's.pinned DESC, s.id ASC',
    );
    $order = isset($orderMap[$sort]) ? $orderMap[$sort] : ($idOrder ? $orderMap['ids'] : $orderMap['default']);
    $st = $db->prepare("SELECT s.id, s.category_id AS categoryId, c2.name AS categoryName, c2.icon AS categoryIcon,
        s.name, s.url, s.descr, s.icon, s.logo, CAST(s.user_id AS INTEGER) AS userId,
        CAST(s.clicks AS INTEGER) AS clicks, CAST(s.pinned AS INTEGER) AS pinned
        FROM sites s LEFT JOIN categories c2 ON c2.id=s.category_id
        $W ORDER BY $order LIMIT $pageSize OFFSET " . (($page - 1) * $pageSize));
    $st->execute($params);
    $items = $st->fetchAll();
    if ($idOrder) { // 按传入顺序返回
        $map = array();
        foreach ($items as $it) { $map[intval($it['id'])] = $it; }
        $ordered = array();
        foreach ($idOrder as $iid) { if (isset($map[$iid])) $ordered[] = $map[$iid]; }
        $items = $ordered;
    }
    znav_json(array('ok' => true, 'total' => $total, 'page' => $page,
        'hasMore' => $page * $pageSize < $total, 'items' => $items));
}

/** 点击统计（公开，无鉴权；vid 存在时同时累加访客记录） */
case 'click': {
    $id = intval(isset($input['id']) ? $input['id'] : (isset($_GET['id']) ? $_GET['id'] : 0));
    $vid = trim(isset($input['vid']) ? $input['vid'] : '');
    if ($id > 0) {
        $db = znav_db();
        $db->prepare('UPDATE sites SET clicks = clicks + 1 WHERE id=?')->execute(array($id));
        if ($vid !== '') {
            $db->prepare("UPDATE visits SET clicks = clicks + 1 WHERE id = (SELECT id FROM visits WHERE vid=? ORDER BY id DESC LIMIT 1)")
               ->execute(array(mb_substr($vid, 0, 40)));
        }
    }
    znav_json(array('ok' => true));
}

/** 访客记录：进入页面时登记（后台可开关收集） */
case 'visit': {
    if (znav_setting('visitsEnabled', '1') === '0') znav_json(array('ok' => true, 'off' => true));
    $vid = mb_substr(trim(isset($input['vid']) ? $input['vid'] : ''), 0, 40);
    $page = mb_substr(trim(isset($input['page']) ? $input['page'] : '/'), 0, 200);
    if ($vid !== '') {
        $ua = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';
        $ip = znav_client_ip();
        znav_db()->prepare('INSERT INTO visits(vid,ip,ua,page,referer,visited_at,stay,clicks,device) VALUES(?,?,?,?,?,?,0,0,?)')
           ->execute(array($vid, $ip,
               mb_substr($ua, 0, 200),
               $page,
               mb_substr(isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : '', 0, 200),
               date('Y-m-d H:i:s'),
               znav_detect_device($ua)));
        // 顺手解析并缓存归属地（公网 IP 才会真正发起查询；失败静默，不拖慢登记）
        try { znav_ip_region($ip); } catch (Exception $e) { /* ignore */ }
    }
    znav_json(array('ok' => true));
}

/** 访客记录：离开时补记停留时长 */
case 'visit_leave': {
    $vid = mb_substr(trim(isset($input['vid']) ? $input['vid'] : ''), 0, 40);
    $stay = min(86400, max(0, intval(isset($input['stay']) ? $input['stay'] : 0)));
    if ($vid !== '') {
        znav_db()->prepare('UPDATE visits SET stay=? WHERE id=(SELECT id FROM visits WHERE vid=? ORDER BY id DESC LIMIT 1)')
           ->execute(array($stay, $vid));
    }
    znav_json(array('ok' => true));
}

case 'fetch_title': {
    $url = trim(isset($_GET['url']) ? $_GET['url'] : '');
    if ($url === '') znav_json(array('error' => '缺少 url'), 400);
    $title = znav_fetch_title($url);
    znav_json(array('ok' => true, 'title' => $title,
        'fallback' => $title === '' ? preg_replace('#^https?://(www\.)?#i', '', $url) : ''));
}

// ================= 管理接口 =================
case 'login': {
    $pwd = isset($input['password']) ? (string)$input['password'] : '';
    $userIn = isset($input['username']) ? trim((string)$input['username']) : '';
    $savedUser = znav_setting('adminUser', 'admin');
    // 兼容旧后台（不传账号）：只有明确填写了账号才校验，避免升级后老页面登不进
    if ($userIn !== '' && strtolower($userIn) !== strtolower((string)$savedUser)) {
        znav_json(array('error' => '账号或密码错误'), 401);
    }
    $saved = znav_setting('adminPassword');
    $ok = false;
    if (strpos($saved, '$2y$') === 0 || strpos($saved, '$2a$') === 0 || strpos($saved, '$2b$') === 0) {
        $ok = password_verify($pwd, $saved);
    } else {
        $ok = $pwd !== '' && $pwd === $saved;
        if ($ok) { // 明文密码升级为哈希存储
            znav_setting_save('adminPassword', password_hash($pwd, PASSWORD_DEFAULT));
        }
    }
    if ($ok) {
        $_SESSION['znav_admin'] = 1;
        znav_json(array('ok' => true, 'token' => znav_admin_token()));
    }
    znav_json(array('error' => '密码错误'), 401);
}

case 'auth_check':
    znav_require_admin();
    znav_json(array('ok' => true));

case 'logout':
    session_destroy();
    znav_json(array('ok' => true));

// ================= 会员系统 =================
/** 会员公开信息（未登录返回 guest） */
case 'me': {
    $u = znav_current_user();
    if (!$u) znav_json(array('ok' => true, 'guest' => true, 'isAdmin' => znav_is_admin_req()));
    znav_json(array('ok' => true, 'id' => intval($u['id']), 'username' => $u['username'],
        'role' => $u['role'], 'canPost' => intval($u['can_post']), 'canLink' => intval($u['can_link']),
        'expiresAt' => $u['expires_at'], 'isAdmin' => znav_is_admin_req()));
}

/** 注册：type = member（会员，可发帖+添加网址）| temp（临时账号，7 天有效，仅发帖） */
case 'register': {
    znav_require_user_header();
    $username = trim(isset($input['username']) ? (string)$input['username'] : '');
    $password = (string)(isset($input['password']) ? $input['password'] : '');
    $type = (isset($input['type']) && $input['type'] === 'temp') ? 'temp' : 'member';
    if (!preg_match('/^[\x{4e00}-\x{9fa5}a-zA-Z0-9_]{2,20}$/u', $username)) {
        znav_json(array('error' => '用户名需 2-20 位，可用中文、字母、数字、下划线'), 400);
    }
    if (strlen($password) < 6 || strlen($password) > 64) znav_json(array('error' => '密码至少 6 位'), 400);
    $db = znav_db();
    $st = $db->prepare('SELECT id FROM users WHERE username=?');
    $st->execute(array($username));
    if ($st->fetch()) znav_json(array('error' => '用户名已被占用'), 400);
    $expires = $type === 'temp' ? date('Y-m-d H:i:s', time() + 7 * 86400) : '';
    $db->prepare('INSERT INTO users(username,pass,role,can_post,can_link,expires_at,created_at) VALUES(?,?,?,?,?,?,?)')
       ->execute(array($username, password_hash($password, PASSWORD_DEFAULT), $type,
           1, $type === 'member' ? 1 : 0, $expires, date('Y-m-d H:i:s')));
    $_SESSION['znav_uid'] = intval($db->lastInsertId());
    znav_json(array('ok' => true, 'id' => intval($_SESSION['znav_uid']), 'username' => $username,
        'role' => $type, 'canPost' => 1, 'canLink' => $type === 'member' ? 1 : 0, 'isAdmin' => false));
}

/** 会员登录 */
case 'user_login': {
    znav_require_user_header();
    $username = trim(isset($input['username']) ? (string)$input['username'] : '');
    $password = (string)(isset($input['password']) ? $input['password'] : '');
    $st = znav_db()->prepare('SELECT * FROM users WHERE username=?');
    $st->execute(array($username));
    $u = $st->fetch();
    if (!$u || !password_verify($password, $u['pass'])) znav_json(array('error' => '用户名或密码错误'), 401);
    if ($u['expires_at'] !== '' && $u['expires_at'] < date('Y-m-d H:i:s')) {
        znav_json(array('error' => '该临时账号已过期'), 403);
    }
    $_SESSION['znav_uid'] = intval($u['id']);
    znav_db()->prepare('UPDATE users SET last_login=? WHERE id=?')
             ->execute(array(date('Y-m-d H:i:s'), $u['id']));
    znav_json(array('ok' => true, 'id' => intval($u['id']), 'username' => $u['username'],
        'role' => $u['role'], 'canPost' => intval($u['can_post']), 'canLink' => intval($u['can_link']),
        'isAdmin' => znav_is_admin_req()));
}

case 'user_logout': {
    unset($_SESSION['znav_uid']);
    znav_json(array('ok' => true));
}

/** 帖子列表（公开，最新在前） */
case 'posts_list': {
    $limit = min(100, max(1, intval(isset($_GET['limit']) ? $_GET['limit'] : 30)));
    $rows = znav_db()->query("SELECT p.id, p.user_id AS userId, p.title, p.content, p.created_at AS createdAt,
        u.username, u.role FROM posts p LEFT JOIN users u ON u.id=p.user_id
        ORDER BY p.id DESC LIMIT $limit")->fetchAll();
    znav_json(array('ok' => true, 'items' => $rows, 'isAdmin' => znav_is_admin_req()));
}

/** 发布帖子（需登录 + can_post 权限） */
case 'post_add': {
    znav_require_user_header();
    $user = znav_require_login();
    if ($user && !intval($user['can_post'])) znav_json(array('error' => '当前账号没有发帖权限，请联系管理员开通'), 403);
    $title = trim(mb_substr((string)(isset($input['title']) ? $input['title'] : ''), 0, 60));
    $content = trim(mb_substr((string)(isset($input['content']) ? $input['content'] : ''), 0, 2000));
    if ($title === '') znav_json(array('error' => '请填写标题'), 400);
    $uid = $user ? intval($user['id']) : 0;
    $author = $user ? $user['username'] : '管理员';
    $db = znav_db();
    // 帖子同时镜像到「文章管理」（后台可直接用编辑框编辑/发布到文章页）
    $db->prepare('INSERT INTO articles(title,summary,content,enabled,user_id,author,created_at) VALUES(?,?,?,?,?,?,?)')
       ->execute(array($title, mb_substr($content, 0, 120), $content, 1, $uid, $author, date('Y-m-d H:i:s')));
    $artId = intval($db->lastInsertId());
    $db->prepare('INSERT INTO posts(user_id,title,content,created_at,article_id) VALUES(?,?,?,?,?)')
       ->execute(array($uid, $title, $content, date('Y-m-d H:i:s'), $artId));
    znav_json(array('ok' => true, 'id' => intval($db->lastInsertId()), 'articleId' => $artId,
        'username' => $author, 'role' => $user ? $user['role'] : 'admin'));
}

/** 删除帖子：管理员可删任何，会员只能删自己的（同时删除镜像的文章） */
case 'post_delete': {
    znav_require_user_header();
    if (znav_is_admin_req()) {
        $row = znav_db()->prepare('SELECT article_id FROM posts WHERE id=?');
        $row->execute(array(intval($input['id'])));
        $r = $row->fetch();
        znav_db()->prepare('DELETE FROM posts WHERE id=?')->execute(array(intval($input['id'])));
        if ($r && intval($r['article_id'])) znav_db()->prepare('DELETE FROM articles WHERE id=? AND user_id>0')->execute(array(intval($r['article_id'])));
        znav_json(array('ok' => true));
    }
    $user = znav_current_user();
    if (!$user) znav_json(array('error' => '请先登录'), 401);
    $st = znav_db()->prepare('SELECT user_id, article_id FROM posts WHERE id=?');
    $st->execute(array(intval($input['id'])));
    $row = $st->fetch();
    if ($row && intval($row['user_id']) === intval($user['id'])) {
        $db = znav_db();
        $db->prepare('DELETE FROM posts WHERE id=?')->execute(array(intval($input['id'])));
        if (intval($row['article_id'])) $db->prepare('DELETE FROM articles WHERE id=? AND user_id=?')
            ->execute(array(intval($row['article_id']), intval($user['id'])));
        znav_json(array('ok' => true));
    }
    znav_json(array('error' => '只能删除自己的帖子'), 403);
}

// ---------- 会员管理（后台管理员） ----------
case 'users_list': {
    znav_require_admin();
    $rows = znav_db()->query('SELECT id, username, role, can_post, can_link, expires_at, created_at, last_login
        FROM users ORDER BY id DESC')->fetchAll();
    foreach ($rows as &$r) {
        $r['id'] = intval($r['id']); $r['can_post'] = intval($r['can_post']); $r['can_link'] = intval($r['can_link']);
        $r['expired'] = $r['expires_at'] !== '' && $r['expires_at'] < date('Y-m-d H:i:s') ? 1 : 0;
    }
    unset($r);
    znav_json(array('ok' => true, 'items' => $rows));
}

/** 保存会员设置：角色 / 权限 / 有效期 / 重置密码 */
case 'user_save': {
    znav_require_admin();
    $id = intval(isset($input['id']) ? $input['id'] : 0);
    $st = znav_db()->prepare('SELECT * FROM users WHERE id=?'); $st->execute(array($id));
    $u = $st->fetch();
    if (!$u) znav_json(array('error' => '会员不存在'), 404);
    $role = isset($input['role']) && in_array($input['role'], array('member', 'temp'), true) ? $input['role'] : $u['role'];
    $canPost = isset($input['can_post']) ? intval(!!$input['can_post']) : intval($u['can_post']);
    $canLink = isset($input['can_link']) ? intval(!!$input['can_link']) : intval($u['can_link']);
    $expires = isset($input['expires_at']) ? trim((string)$input['expires_at']) : $u['expires_at'];
    if ($expires !== '' && !preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}(:\d{2})?$/', $expires)) {
        $expires = $u['expires_at'];
    }
    znav_db()->prepare('UPDATE users SET role=?, can_post=?, can_link=?, expires_at=? WHERE id=?')
             ->execute(array($role, $canPost, $canLink, $expires, $id));
    if (!empty($input['password'])) {
        $pwd = (string)$input['password'];
        if (strlen($pwd) < 6) znav_json(array('error' => '新密码至少 6 位'), 400);
        znav_db()->prepare('UPDATE users SET pass=? WHERE id=?')
                 ->execute(array(password_hash($pwd, PASSWORD_DEFAULT), $id));
    }
    znav_json(array('ok' => true));
}

case 'user_delete': {
    znav_require_admin();
    $id = intval(isset($input['id']) ? $input['id'] : 0);
    $db = znav_db();
    $db->prepare('DELETE FROM users WHERE id=?')->execute(array($id));
    $db->prepare('DELETE FROM posts WHERE user_id=?')->execute(array($id));
    $db->prepare('UPDATE sites SET user_id=0 WHERE user_id=?')->execute(array($id));
    znav_json(array('ok' => true));
}

case 'stats': {
    znav_require_admin();
    $db = znav_db();
    // 顺手做存量 data URI 图标迁移（每次最多 150 条，后台打开即自愈，不拖慢响应）
    try { list($iconMigrateLeft, ) = znav_logo_migrate_datauri(150); } catch (Exception $e) { $iconMigrateLeft = 0; }
    $top = $db->query("SELECT c.name, c.icon, (SELECT COUNT(*) FROM sites s WHERE s.category_id=c.id
        OR s.category_id IN (SELECT id FROM categories c2 WHERE c2.parent_id=c.id)) AS count
        FROM categories c WHERE c.parent_id IS NULL ORDER BY count DESC LIMIT 8")->fetchAll();
    // 全部主分类明细（看板表格用）
    $catStats = $db->query("SELECT c.id, c.name, c.icon,
        (SELECT COUNT(*) FROM sites s WHERE s.category_id=c.id
          OR s.category_id IN (SELECT id FROM categories c2 WHERE c2.parent_id=c.id)) AS count,
        (SELECT COALESCE(SUM(s2.clicks),0) FROM sites s2 WHERE s2.category_id=c.id
          OR s2.category_id IN (SELECT id FROM categories c3 WHERE c3.parent_id=c.id)) AS clicks
        FROM categories c WHERE c.parent_id IS NULL ORDER BY count DESC")->fetchAll();
    foreach ($catStats as &$cs) { $cs['id'] = intval($cs['id']); $cs['count'] = intval($cs['count']); $cs['clicks'] = intval($cs['clicks']); }
    unset($cs);
    // 访客记录按端口统计（兼容旧「爬虫」叫法）
    $visitDevices = array();
    try {
        $vd = $db->query("SELECT device, COUNT(*) c FROM visits GROUP BY device ORDER BY c DESC")->fetchAll();
        foreach ($vd as $v) {
            $label = znav_device_label($v['device']);
            $found = false;
            foreach ($visitDevices as &$vdItem) {
                if ($vdItem['device'] === $label) { $vdItem['c'] += intval($v['c']); $found = true; break; }
            }
            if (!$found) $visitDevices[] = array('device' => ($label !== '' ? $label : '未知'), 'c' => intval($v['c']));
        }
        usort($visitDevices, function ($a, $b) { return $b['c'] - $a['c']; });
    } catch (Exception $e) { /* visits 表可能不存在 device 列 */ }
    // 近 14 天访问趋势（PV / UV）
    $visitTrend = array();
    try {
        $start = date('Y-m-d', strtotime('-13 days'));
        $rows = $db->query("SELECT substr(visited_at,1,10) d, COUNT(*) pv, COUNT(DISTINCT ip) uv
            FROM visits WHERE visited_at >= '$start' GROUP BY substr(visited_at,1,10)")->fetchAll();
        $map = array();
        foreach ($rows as $r) { $map[$r['d']] = array('pv' => intval($r['pv']), 'uv' => intval($r['uv'])); }
        for ($i = 13; $i >= 0; $i--) {
            $d = date('Y-m-d', strtotime("-$i days"));
            $visitTrend[] = array('date' => substr($d, 5), 'pv' => isset($map[$d]) ? $map[$d]['pv'] : 0, 'uv' => isset($map[$d]) ? $map[$d]['uv'] : 0);
        }
    } catch (Exception $e) { /* ignore */ }
    // 访客地域分布 TOP 10
    $regionStats = array();
    try {
        $rs = $db->query("SELECT r.region, COUNT(v.id) c FROM visits v JOIN ip_region r ON r.ip=v.ip
            WHERE r.region != '' GROUP BY r.region ORDER BY c DESC LIMIT 10")->fetchAll();
        foreach ($rs as $r) { $regionStats[] = array('region' => $r['region'], 'c' => intval($r['c'])); }
    } catch (Exception $e) { /* ignore */ }
    znav_json(array('ok' => true,
        'totalSites' => intval($db->query('SELECT COUNT(*) c FROM sites')->fetch()['c']),
        'totalCats' => intval($db->query('SELECT COUNT(*) c FROM categories')->fetch()['c']),
        'totalAds' => intval($db->query('SELECT COUNT(*) c FROM ads')->fetch()['c']),
        'enabledAds' => intval($db->query('SELECT COUNT(*) c FROM ads WHERE enabled=1')->fetch()['c']),
        'totalClicks' => intval($db->query('SELECT COALESCE(SUM(clicks),0) c FROM sites')->fetch()['c']),
        'noLogo' => intval($db->query("SELECT COUNT(*) c FROM sites WHERE (logo IS NULL OR logo='') AND icon=''")->fetch()['c']),
        'iconMigrateLeft' => isset($iconMigrateLeft) ? $iconMigrateLeft : 0,
        'topCats' => $top,
        'catStats' => $catStats,
        'visitDevices' => $visitDevices,
        'visitTrend' => $visitTrend,
        'regionStats' => $regionStats));
}

case 'settings_save': {
    znav_require_admin();
    if (!empty($input['site_name'])) znav_setting_save('siteName', mb_substr((string)$input['site_name'], 0, 30));
    if (!empty($input['admin_user'])) znav_setting_save('adminUser', trim(mb_substr((string)$input['admin_user'], 0, 32)));
    if (isset($input['admin_email'])) znav_setting_save('adminEmail', trim(mb_substr((string)$input['admin_email'], 0, 80)));
    if (isset($input['announcement'])) znav_setting_save('announcement', mb_substr((string)$input['announcement'], 0, 100));
    // 源码更新：自定义检查地址（留空则用默认推导值）
    if (isset($input['update_check_url'])) znav_setting_save('updateCheckUrl', trim(mb_substr((string)$input['update_check_url'], 0, 300)));
    // 网站图标（地址栏 favicon）：留空 = 内置默认；支持 http(s) 外链 / uploads 上传图 / assets 固定图
    if (isset($input['site_favicon'])) {
        $sf = trim((string)$input['site_favicon']);
        if ($sf === '' || preg_match('#^https?://#i', $sf)
            || preg_match('#^/?uploads/[A-Za-z0-9_.\-]+$#i', $sf)
            || preg_match('#^/?assets/[A-Za-z0-9_.\-/]+$#i', $sf)) {
            znav_setting_save('siteFavicon', $sf);
        }
    }
    if (isset($input['site_name_visible'])) znav_setting_save('siteNameVisible', !empty($input['site_name_visible']) ? '1' : '0');
    // 首页最新内容区：显示开关 + 缩略图开关
    if (isset($input['home_content_show'])) znav_setting_save('homeContentShow', !empty($input['home_content_show']) ? '1' : '0');
    if (isset($input['home_content_thumb'])) znav_setting_save('homeContentThumb', !empty($input['home_content_thumb']) ? '1' : '0');
    // 首页内容卡片数量上限（不含导航网址）
    if (isset($input['home_item_limit'])) {
        $lim = intval($input['home_item_limit']);
        if ($lim < 1) $lim = 1;
        if ($lim > 30) $lim = 30;
        znav_setting_save('homeItemLimit', (string)$lim);
    }
    // 首页缩略图尺寸
    if (isset($input['thumb_w'])) {
        $tw = intval($input['thumb_w']); if ($tw < 40) $tw = 40; if ($tw > 480) $tw = 480;
        znav_setting_save('thumbW', (string)$tw);
    }
    if (isset($input['thumb_h'])) {
        $th = intval($input['thumb_h']); if ($th < 30) $th = 30; if ($th > 480) $th = 480;
        znav_setting_save('thumbH', (string)$th);
    }
    // 网址卡片：圆形图标尺寸 + 卡片最小宽/高（前台版式）
    if (isset($input['card_logo_w'])) {
        $v = intval($input['card_logo_w']); if ($v < 24) $v = 24; if ($v > 96) $v = 96;
        znav_setting_save('cardLogoW', (string)$v);
    }
    if (isset($input['card_logo_h'])) {
        $v = intval($input['card_logo_h']); if ($v < 24) $v = 24; if ($v > 96) $v = 96;
        znav_setting_save('cardLogoH', (string)$v);
    }
    if (isset($input['card_min_w'])) {
        $v = intval($input['card_min_w']); if ($v < 150) $v = 150; if ($v > 400) $v = 400;
        znav_setting_save('cardMinW', (string)$v);
    }
    if (isset($input['card_min_h'])) {
        $v = intval($input['card_min_h']); if ($v < 0) $v = 0; if ($v > 160) $v = 160;
        znav_setting_save('cardMinH', (string)$v);
    }
    // 功能隐藏开关（开启后，未输对功能密码前隐藏维护类按钮：更新Logo/上传图片/圆形截取/扫描死链/查重复等）
    if (isset($input['feat_lock_on'])) znav_setting_save('featLockOn', !empty($input['feat_lock_on']) ? '1' : '0');
    // 功能密码（只存 bcrypt 哈希，明文不落库）
    if (isset($input['feat_lock_pwd'])) {
        $fp = trim((string)$input['feat_lock_pwd']);
        if ($fp !== '') {
            if (mb_strlen($fp) < 4 || mb_strlen($fp) > 20) znav_json(array('error' => '功能密码需 4~20 位'), 400);
            znav_setting_save('featLockPwd', password_hash($fp, PASSWORD_BCRYPT));
        }
    }
    // 前台默认宽度档位（full/wide/normal/custom）
    if (!empty($input['page_width'])) {
        $pw = (string)$input['page_width'];
        if (!in_array($pw, array('full', 'wide', 'normal', 'custom'), true)) $pw = 'wide';
        znav_setting_save('pageWidth', $pw);
    }
    // 自定义版心宽度（px）
    if (isset($input['custom_page_w'])) {
        $cw = intval($input['custom_page_w']); if ($cw < 0) $cw = 0; if ($cw > 4000) $cw = 4000;
        znav_setting_save('customPageW', (string)$cw);
    }
    // 右栏展示模式：auto / image / photo / text
    if (isset($input['side_display'])) {
        $sd = (string)$input['side_display'];
        if (!in_array($sd, array('auto', 'image', 'photo', 'text'), true)) $sd = 'auto';
        znav_setting_save('sideDisplay', $sd);
    }
    // 前台默认显示模式：logo=图文（默认）/ text=全文字（游客可自由切换，此处设默认）
    if (isset($input['home_mode'])) {
        $hm = (string)$input['home_mode'];
        if (!in_array($hm, array('logo', 'text'), true)) $hm = 'logo';
        znav_setting_save('homeMode', $hm);
    }
    // 站点名称样式（大小 px / 颜色 / 字体）
    if (isset($input['site_name_style'])) {
        $sns = json_decode((string)$input['site_name_style'], true);
        if (!is_array($sns)) $sns = array();
        $clean = array();
        if (isset($sns['size'])) { $n = intval($sns['size']); $clean['size'] = max(0, min(80, $n)); }
        if (isset($sns['color'])) {
            $c = trim((string)$sns['color']);
            $clean['color'] = preg_match('/^#[0-9a-fA-F]{3,8}$/', $c) ? $c : '';
        }
        if (isset($sns['font'])) $clean['font'] = mb_substr(trim((string)$sns['font']), 0, 80);
        znav_setting_save('siteNameStyle', json_encode($clean, JSON_UNESCAPED_UNICODE));
    }
    // 自定义背景图列表（最多 5 张，每张为 uploads/xxx 路径）
    if (isset($input['bg_images'])) {
        $arr = json_decode((string)$input['bg_images'], true);
        if (!is_array($arr)) $arr = array();
        $clean = array();
        foreach ($arr as $u) {
            $u = trim((string)$u);
            if ($u !== '' && preg_match('#^uploads/[a-z0-9_\-]+\.(jpg|png|webp|gif|jpeg)$#i', $u)) $clean[] = $u;
            if (count($clean) >= 5) break;
        }
        znav_setting_save('bgImages', json_encode(array_values($clean)));
        // 兼容旧字段：第一张同时作为 bgImage
        znav_setting_save('bgImage', isset($clean[0]) ? $clean[0] : '');
    }
    // 常用网址自定义（id CSV，最多 60 个）
    if (isset($input['hot_site_ids'])) {
        $ids = array();
        foreach (explode(',', (string)$input['hot_site_ids']) as $t) { $t = intval(trim($t)); if ($t > 0) $ids[] = $t; }
        znav_setting_save('hotSiteIds', implode(',', array_slice($ids, 0, 60)));
    }
    // 下载页标题 / 描述
    if (isset($input['downloads_title'])) znav_setting_save('downloadsTitle', mb_substr(trim((string)$input['downloads_title']), 0, 30));
    if (isset($input['downloads_desc'])) znav_setting_save('downloadsDesc', mb_substr(trim((string)$input['downloads_desc']), 0, 200));
    // 聚合页（Link3 风格）设置：标题 / 副标题 / 首页入口按钮文字与位置 / 开关
    if (isset($input['hub_enabled'])) znav_setting_save('hubEnabled', !empty($input['hub_enabled']) ? '1' : '0');
    if (isset($input['hub_name'])) znav_setting_save('hubName', mb_substr(trim((string)$input['hub_name']), 0, 20));
    if (isset($input['hub_title'])) znav_setting_save('hubTitle', mb_substr(trim((string)$input['hub_title']), 0, 30));
    if (isset($input['hub_intro'])) znav_setting_save('hubIntro', mb_substr(trim((string)$input['hub_intro']), 0, 100));
    if (isset($input['hub_btn_text'])) znav_setting_save('hubBtnText', mb_substr(trim((string)$input['hub_btn_text']), 0, 20));
    if (isset($input['hub_btn_pos'])) {
        $bp = (string)$input['hub_btn_pos'];
        if ($bp === 'both') $bp = 'nav';   // 旧值兼容
        // right:N = 右侧栏内插到第 N 个模块之前（自由落点）；纯 right = 右栏默认槽位
        if (!in_array($bp, array('nav', 'main', 'side', 'right', 'hero', 'footer', 'none'), true) && !preg_match('/^right:(\d{1,2})$/', $bp)) $bp = 'nav';
        znav_setting_save('hubBtnPos', $bp);
    }
    // 广告排布：1 = 通栏单个 / 2 = 并排两个
    if (isset($input['ad_cols'])) {
        $ac = (string)$input['ad_cols'] === '2' ? '2' : '1';
        znav_setting_save('adCols', $ac);
    }
    // 鼠标样式（0 = 默认系统光标）
    if (isset($input['cursor_style'])) {
        $cs = intval($input['cursor_style']); if ($cs < 0) $cs = 0; if ($cs > 5) $cs = 5;
        znav_setting_save('cursorStyle', (string)$cs);
    }
    // 首页右栏模块列表（可增删 / 改名 / 排序 / 隐藏）；传空数组 = 恢复按页面管理自动生成
    if (isset($input['side_modules'])) {
        $in = $input['side_modules'];
        $arr = is_array($in) ? $in : json_decode((string)$in, true);
        $clean = array();
        $seen = array();
        if (is_array($arr)) {
            foreach ($arr as $m) {
                if (!is_array($m)) continue;
                $t = isset($m['type']) ? (string)$m['type'] : '';
                if (!in_array($t, array('page', 'arts', 'posts', 'ads', 'hub'), true)) continue;
                $one = array('type' => $t, 'title' => mb_substr(trim((string)(isset($m['title']) ? $m['title'] : '')), 0, 20));
                if ($t === 'page') {
                    $one['ref'] = intval(isset($m['ref']) ? $m['ref'] : 0);
                    if ($one['ref'] <= 0) continue;
                }
                if (!empty($m['hidden'])) $one['hidden'] = 1;
                // 去重：同类型同引用（或同类型非页面模块）只保留一个
                $key = $t === 'page' ? 'page-' . $one['ref'] : $t;
                if (isset($seen[$key])) continue;
                $seen[$key] = 1;
                $clean[] = $one;
            }
        }
        znav_setting_save('sideModules', json_encode(array_values($clean), JSON_UNESCAPED_UNICODE));
    }
    // 右栏被手动删掉的页面模块（不再自动补回）；传空 = 清空记录
    if (isset($input['side_removed_pages'])) {
        $ids = array();
        $src = is_array($input['side_removed_pages']) ? $input['side_removed_pages'] : explode(',', (string)$input['side_removed_pages']);
        foreach ($src as $x) { $x = intval(trim((string)$x)); if ($x > 0) $ids[] = $x; }
        $ids = array_values(array_unique($ids));
        znav_setting_save('sideRemovedPages', implode(',', $ids));
    }
    // 后台左侧菜单名称（JSON：{ tab: 名称 }）
    if (isset($input['admin_menu_names'])) {
        $arr = is_array($input['admin_menu_names']) ? $input['admin_menu_names'] : json_decode((string)$input['admin_menu_names'], true);
        $clean = array();
        if (is_array($arr)) {
            foreach ($arr as $k => $v) {
                $k = preg_replace('/[^a-z0-9_\-]/i', '', (string)$k);
                $v = mb_substr(trim((string)$v), 0, 24);
                if ($k !== '' && $v !== '') $clean[$k] = $v;
            }
        }
        znav_setting_save('adminMenuNames', json_encode($clean, JSON_UNESCAPED_UNICODE));
    }
    // 首页布局方案（命名保存的布局快照，最多 20 套）
    if (isset($input['layout_presets'])) {
        $arr = is_array($input['layout_presets']) ? $input['layout_presets'] : json_decode((string)$input['layout_presets'], true);
        $clean = array();
        if (is_array($arr)) {
            foreach ($arr as $one) {
                if (!is_array($one)) continue;
                $name = mb_substr(trim((string)(isset($one['name']) ? $one['name'] : '')), 0, 30);
                if ($name === '') continue;
                $data = array();
                if (isset($one['data']) && is_array($one['data'])) {
                    foreach ($one['data'] as $dk => $dv) {
                        if (!in_array($dk, array('homeLayout', 'homeSecOrder', 'sideOrder', 'hubBtnPos', 'sidebarPos', 'pageWidth', 'customPageW'), true)) continue;
                        $data[$dk] = mb_substr((string)$dv, 0, 4000);
                    }
                }
                $clean[] = array(
                    'id' => mb_substr(trim((string)(isset($one['id']) ? $one['id'] : '')), 0, 32) ?: substr(md5($name . microtime()), 0, 10),
                    'name' => $name,
                    'at' => mb_substr(trim((string)(isset($one['at']) ? $one['at'] : '')), 0, 19) ?: date('Y-m-d H:i:s'),
                    'data' => $data,
                );
                if (count($clean) >= 20) break;
            }
        }
        znav_setting_save('layoutPresets', json_encode($clean, JSON_UNESCAPED_UNICODE));
    }
    // 前台 Logo 长宽（0 = 跟随 logoSize 正方形）
    if (isset($input['logo_w'])) {
        $lw = intval($input['logo_w']); if ($lw < 0) $lw = 0; if ($lw > 400) $lw = 400;
        znav_setting_save('logoW', (string)$lw);
    }
    if (isset($input['logo_h'])) {
        $lh = intval($input['logo_h']); if ($lh < 0) $lh = 0; if ($lh > 400) $lh = 400;
        znav_setting_save('logoH', (string)$lh);
    }
    // Logo 填充方式：fill=拉伸铺满(不保持比例) / contain=等比缩放留白 / cover=等比裁剪填满
    if (isset($input['logo_fit'])) {
        $lf = trim((string)$input['logo_fit']);
        if (!in_array($lf, array('fill', 'contain', 'cover'), true)) $lf = 'fill';
        znav_setting_save('logoFit', $lf);
    }
    // 顶部标语：可用图片替换 + 自定义长宽 + 是否保留文字
    if (isset($input['hero_image'])) znav_setting_save('heroImage', substr(trim((string)$input['hero_image']), 0, 500));
    if (isset($input['hero_img_w'])) {
        $hw = intval($input['hero_img_w']); if ($hw < 0) $hw = 0; if ($hw > 1600) $hw = 1600;
        znav_setting_save('heroImgW', (string)$hw);
    }
    if (isset($input['hero_img_h'])) {
        $hh = intval($input['hero_img_h']); if ($hh < 0) $hh = 0; if ($hh > 600) $hh = 600;
        znav_setting_save('heroImgH', (string)$hh);
    }
    if (isset($input['hero_text_show'])) znav_setting_save('heroTextShow', !empty($input['hero_text_show']) ? '1' : '0');
    // 首页内容模块：后台挑选的文章/页面（JSON 数组）
    if (isset($input['home_blocks'])) {
        $hb = trim((string)$input['home_blocks']);
        if ($hb === '' || $hb === '[]') znav_setting_save('homeBlocks', '');
        else {
            $decoded = json_decode($hb, true);
            if (!is_array($decoded)) znav_json(array('error' => '首页模块数据格式错误'), 400);
            $clean = array();
            foreach ($decoded as $b) {
                if (!is_array($b)) continue;
                $type = isset($b['type']) ? (string)$b['type'] : '';
                if (!in_array($type, array('article', 'page'), true)) continue;
                $clean[] = array('type' => $type, 'id' => intval(isset($b['id']) ? $b['id'] : 0));
            }
            znav_setting_save('homeBlocks', json_encode($clean, JSON_UNESCAPED_UNICODE));
        }
    }
    // 前台 Logo 尺寸（20~120px，正方形基准）
    if (isset($input['logo_size'])) {
        $ls = intval($input['logo_size']);
        if ($ls < 20) $ls = 20;
        if ($ls > 120) $ls = 120;
        znav_setting_save('logoSize', (string)$ls);
    }
    // 右栏模块开关与排序 / 搜索下方标签 / 首页分区排序 / 访客收集开关
    if (isset($input['side_arts_show'])) znav_setting_save('sideArtsShow', !empty($input['side_arts_show']) ? '1' : '0');
    if (isset($input['side_order'])) znav_setting_save('sideOrder', substr(trim((string)$input['side_order']), 0, 100));
    // 左侧分类导航位置：left / right（拖动侧栏时保存）
    if (isset($input['sidebar_pos'])) {
        znav_setting_save('sidebarPos', (string)$input['sidebar_pos'] === 'right' ? 'right' : 'left');
    }
    if (isset($input['home_sec_order'])) znav_setting_save('homeSecOrder', substr(trim((string)$input['home_sec_order']), 0, 500));
    // 首页可视化布局：{ 容器选择器: [区块键...] }，旧格式 {main:[...],side:[...]} 兼容
    if (isset($input['home_layout'])) {
        $hl = json_decode((string)$input['home_layout'], true);
        if (!is_array($hl)) {
            // 空串 / 非法 JSON = 重置为默认布局
            znav_setting_save('homeLayout', '');
        } else {
            $hosts = array('#sections', '#colSide', '.col-main', '.footer', '.top-nav', '#mainContent');
            $isLegacy = isset($hl['main']) || isset($hl['side']);
            $out = array();
            if ($isLegacy) {
                $out['main'] = array();
                $out['side'] = array();
                foreach (array('main', 'side') as $zone) {
                    if (isset($hl[$zone]) && is_array($hl[$zone])) {
                        foreach ($hl[$zone] as $k) {
                            $k = preg_replace('/[^A-Za-z0-9_\-]/', '', (string)$k);
                            if ($k !== '') $out[$zone][] = substr($k, 0, 24);
                        }
                    }
                }
                if (!count($out['main']) && !count($out['side'])) $out = array();
            } else {
                foreach ($hl as $host => $keys) {
                    if (!in_array((string)$host, $hosts, true) || !is_array($keys)) continue;
                    $clean = array();
                    foreach ($keys as $k) {
                        $k = preg_replace('/[^A-Za-z0-9_\-:.]/', '', (string)$k);   // 保留冒号：键格式 sec:1 / side:arts / href:...
                        if ($k !== '' && count($clean) < 400) $clean[] = substr($k, 0, 60);
                    }
                    if (count($clean)) $out[(string)$host] = $clean;
                }
            }
            if (count($out) || $isLegacy) znav_setting_save('homeLayout', json_encode($out));
        }
    }
    if (isset($input['hero_tag_ids'])) {
        $ids = array();
        foreach (explode(',', (string)$input['hero_tag_ids']) as $t) { $t = intval(trim($t)); if ($t > 0) $ids[] = $t; }
        znav_setting_save('heroTagIds', implode(',', $ids));
    }
    if (isset($input['visits_enabled'])) znav_setting_save('visitsEnabled', !empty($input['visits_enabled']) ? '1' : '0');
    // 右栏模块：关闭 / 缩小（逗号分隔的模块键：ads / arts / pages）
    if (isset($input['side_closed'])) znav_setting_save('sideClosed', znav_side_keys_csv($input['side_closed']));
    if (isset($input['side_collapsed'])) znav_setting_save('sideCollapsed', znav_side_keys_csv($input['side_collapsed']));
    // 右栏各模块图片 / 缩略图尺寸（0 = 跟随默认）
    foreach (array(
        'side_ads_img_w' => 'sideAdsImgW', 'side_ads_img_h' => 'sideAdsImgH',
        'side_arts_img_w' => 'sideArtsImgW', 'side_arts_img_h' => 'sideArtsImgH',
        'side_pages_img_w' => 'sidePagesImgW', 'side_pages_img_h' => 'sidePagesImgH'
    ) as $inKey => $setKey) {
        if (isset($input[$inKey])) {
            $n = intval($input[$inKey]);
            if ($n < 0) $n = 0;
            if ($n > 600) $n = 600;
            znav_setting_save($setKey, (string)$n);
        }
    }
    // 首页版式
    if (!empty($input['home_style'])) znav_setting_save('homeStyle', substr((string)$input['home_style'], 0, 20));
    // 右上角齿轮面板：每一项独立显示 / 隐藏（传 1 显示，0 隐藏；不传则保持不变）
    foreach (array(
        'dock_page_width' => 'dockPageWidth',
        'dock_cursor'     => 'dockCursor',
        'dock_bg'         => 'dockBg',
        'dock_skin'       => 'dockSkin',
        'dock_theme'      => 'dockTheme',
        'dock_admin'      => 'dockAdmin',
        'dock_lang'       => 'dockLang',
        'dock_user'       => 'dockUser',
        'dock_chat'       => 'dockChat',
        'dock_music'      => 'dockMusic',
    ) as $inKey => $setKey) {
        if (isset($input[$inKey])) {
            znav_setting_save($setKey, (!empty($input[$inKey]) && $input[$inKey] !== '0') ? '1' : '0');
        }
    }
    // 背景音乐列表：JSON 数组 [{name,url}]，最多 8 首
    if (isset($input['music_list'])) {
        $ml = json_decode((string)$input['music_list'], true);
        if (!is_array($ml)) $ml = array();
        $out = array();
        foreach ($ml as $m) {
            if (!is_array($m) || count($out) >= 8) break;
            $n = trim((string)(isset($m['name']) ? $m['name'] : ''));
            $u = trim((string)(isset($m['url']) ? $m['url'] : ''));
            if ($u === '') continue;
            $out[] = array('name' => $n !== '' ? mb_substr($n, 0, 60) : '未命名', 'url' => mb_substr($u, 0, 500));
        }
        znav_setting_save('musicList', json_encode(array_values($out), JSON_UNESCAPED_UNICODE));
    }
    // 网络出口（本地 VPN/代理）：补图标 / 高清图标 / 死链扫描等出站请求统一走它
    if (isset($input['net_proxy_on'])) znav_setting_save('netProxyOn', !empty($input['net_proxy_on']) && $input['net_proxy_on'] !== '0' ? '1' : '0');
    if (isset($input['net_proxy'])) znav_setting_save('netProxy', trim(mb_substr((string)$input['net_proxy'], 0, 120)));
    if (!empty($input['new_password'])) {
        if (strlen((string)$input['new_password']) < 4) znav_json(array('error' => '新密码至少 4 位'), 400);
        znav_setting_save('adminPassword', password_hash((string)$input['new_password'], PASSWORD_DEFAULT));
    }
    znav_json(array('ok' => true));
}

/** 网络出口连通性测试：百度=基础网络，Google=外网（需 VPN/代理）；返回两项结果 */
case 'proxy_test': {
    znav_require_admin();
    // 只保存请求里显式传入的字段（避免订阅管理接管出口后，点一次「测试连通」把出口清空）
    if (array_key_exists('proxy', $input)) {
        znav_setting_save('netProxy', mb_substr(trim((string)$input['proxy']), 0, 120));
    }
    if (array_key_exists('on', $input)) {
        znav_setting_save('netProxyOn', !empty($input['on']) ? '1' : '0');
    }
    $probe = function ($url) {
        $t0 = microtime(true);
        list($body,) = znav_http_get($url, 8);
        $ok = is_string($body) && $body !== '';
        return array('ok' => $ok, 'ms' => $ok ? intval(round((microtime(true) - $t0) * 1000)) : 0);
    };
    $via = znav_net_proxy() !== '' ? '代理 ' . znav_net_proxy() : '直连';
    $cn = $probe('https://www.baidu.com/favicon.ico');
    $g = $probe('https://www.google.com/favicon.ico');
    $msg = "出口：{$via}；";
    $msg .= '国内网络 ' . ($cn['ok'] ? "✅（{$cn['ms']}ms）" : '❌ 不通');
    $msg .= '；外网 ' . ($g['ok'] ? "✅（{$g['ms']}ms）——补图标/高清图标/死链扫描可正常抓取国外站点" : '❌ 不通（图标源大多在国外，建议开启 VPN 后再跑批量任务）');
    znav_json(array('ok' => $cn['ok'], 'cn' => $cn, 'global' => $g, 'via' => $via, 'msg' => $msg));
}

/** 订阅管理：拉取订阅并解析节点 */
case 'sub_fetch': {
    znav_require_admin();
    $url = trim((string)(isset($input['url']) ? $input['url'] : ''));
    if ($url === '') znav_json(array('error' => '请填写订阅链接或节点链接'), 400);
    // 支持直接粘贴节点链接（vless:// vmess:// trojan:// ss://），可多行
    if (preg_match('~^(?:vless|vmess|trojan|ss)://~i', $url)) {
        $raw = $url; $url = 'direct:' . md5($url);
    } else {
        if (!preg_match('~^https?://~i', $url)) znav_json(array('error' => '请填写 http(s) 订阅链接或 vless/vmess/trojan/ss 节点链接'), 400);
        list($raw, $err) = znav_sub_fetch($url);
        if ($err !== '') znav_json(array('error' => $err), 502);
    }
    $nodes = znav_sub_parse($raw);
    if (!count($nodes)) znav_json(array('error' => '订阅内容里没解析到可用节点（vmess/vless/trojan/ss）'), 422);
    znav_setting_save('subUrl', mb_substr((string)(isset($input['url']) ? $input['url'] : ''), 0, 500));
    znav_setting_save('subNodes', json_encode($nodes, JSON_UNESCAPED_UNICODE));
    $names = array_map(function ($n) { return $n['name'] . '（' . $n['proto'] . ' ' . $n['server'] . '）'; }, $nodes);
    znav_json(array('ok' => true, 'count' => count($nodes), 'nodes' => $names));
}

/** 订阅管理：测速（临时启动核心跑选中节点，不改变网站出口） */
case 'sub_speed': {
    znav_require_admin();
    $idx = intval(isset($input['sel']) ? $input['sel'] : 0);
    list($ok, $ret) = znav_xray_start($idx);
    if (!$ok) {
        znav_xray_kill();
        znav_json(array('error' => $ret), 502);
    }
    znav_setting_save('subSel', (string)$idx);
    // 单节点结果也并入缓存，供下拉框展示
    $speed = json_decode((string)znav_setting('subSpeed', '{}'), true);
    if (!is_array($speed)) $speed = array();
    $speed[$idx] = $ret['ms'];
    znav_setting_save('subSpeed', json_encode($speed));
    znav_json(array('ok' => true, 'ms' => $ret['ms'], 'ip' => $ret['ip'],
        'msg' => '节点可用：' . $ret['ms'] . 'ms，出口IP ' . $ret['ip'] . '（核心保持运行，网站出口未改动）'));
}

/** 订阅管理：批量测速（一个 xray 实例跑全部节点，并发测延迟） */
case 'sub_speed_all': {
    znav_require_admin();
    list($ok, $res, $err) = znav_speed_all();
    if (!$ok) znav_json(array('error' => $err), 502);
    $nodes = json_decode((string)znav_setting('subNodes', '[]'), true);
    $best = -1; $bestMs = PHP_INT_MAX;
    $items = array();
    foreach ($res as $idx => $ms) {
        $name = isset($nodes[$idx]) ? $nodes[$idx]['name'] : ('节点' . $idx);
        $items[] = array('idx' => intval($idx), 'ms' => $ms, 'name' => $name);
        if ($ms >= 0 && $ms < $bestMs) { $bestMs = $ms; $best = intval($idx); }
    }
    usort($items, function ($a, $b) { return $a['ms'] === $b['ms'] ? 0 : ($a['ms'] < 0 ? 1 : ($b['ms'] < 0 ? -1 : $a['ms'] - $b['ms'])); });
    $alive = count(array_filter($res, function ($m) { return $m >= 0; }));
    $msg = '测完 ' . count($res) . ' 个节点：' . $alive . ' 个可用';
    if ($best >= 0) $msg .= '，最快 ' . $bestMs . 'ms（' . (isset($nodes[$best]) ? $nodes[$best]['name'] : $best) . '）';
    znav_json(array('ok' => true, 'speed' => $res, 'items' => $items, 'best' => $best, 'bestMs' => $best >= 0 ? $bestMs : -1, 'msg' => $msg));
}

/** 订阅管理：启动选中节点，成功后自动接管网络出口 */
case 'sub_start': {
    znav_require_admin();
    $idx = intval(isset($input['sel']) ? $input['sel'] : 0);
    list($ok, $ret) = znav_xray_start($idx);
    $port = znav_sub_paths()['port'];
    if (!$ok) {
        znav_xray_kill();
        // 核心已停 → 若网站出口还指向这个本地端口，必须切回直连，否则全站抓取（Logo/死链）会全部失效
        if (trim((string)znav_setting('netProxy', '')) === 'socks5://127.0.0.1:' . $port) {
            znav_setting_save('netProxyOn', '0');
            $ret .= '（已自动切回直连，避免影响抓取）';
        }
        znav_json(array('error' => $ret), 502);
    }
    // 出口自动切到本地核心
    znav_setting_save('netProxyOn', '1');
    znav_setting_save('netProxy', 'socks5://127.0.0.1:' . $port);
    znav_setting_save('subSel', (string)$idx);
    znav_json(array('ok' => true, 'pid' => $ret['pid'], 'ms' => $ret['ms'], 'ip' => $ret['ip'], 'port' => $port,
        'msg' => '节点已连通（' . $ret['ms'] . 'ms，出口IP ' . $ret['ip'] . '），网站出口已自动切换到本地核心'));
}

/** 订阅管理：停止核心；出口若指向本核心则一并关闭 */
case 'sub_stop': {
    znav_require_admin();
    $port = znav_sub_paths()['port'];
    znav_xray_kill();
    if (trim((string)znav_setting('netProxy', '')) === 'socks5://127.0.0.1:' . $port) {
        znav_setting_save('netProxyOn', '0');
    }
    znav_json(array('ok' => true, 'msg' => '已停止，网站出口恢复直连'));
}

/** 订阅管理：当前状态 */
case 'sub_status': {
    znav_require_admin();
    $st = znav_xray_status();
    $nodes = json_decode((string)znav_setting('subNodes', '[]'), true);
    $names = array();
    if (is_array($nodes)) $names = array_map(function ($n) { return $n['name'] . '（' . $n['proto'] . ' ' . $n['server'] . '）'; }, $nodes);
    znav_json(array(
        'running' => $st['listening'], 'pid' => $st['pid'], 'log' => $st['log'],
        'port' => znav_sub_paths()['port'],
        'subUrl' => (string)znav_setting('subUrl', ''),
        'sel' => intval(znav_setting('subSel', '0')),
        'nodes' => $names,
        'speed' => json_decode((string)znav_setting('subSpeed', '{}'), true),
        'egressOn' => znav_setting('netProxyOn', '0') === '1',
        'egress' => (string)znav_setting('netProxy', ''),
    ));
}

// ---------- 分类 ----------
case 'cat_add': {
    znav_require_admin();
    $name = trim(isset($input['name']) ? $input['name'] : '');
    if ($name === '') znav_json(array('error' => '分类名称必填'), 400);
    $parent = !empty($input['parent_id']) ? intval($input['parent_id']) : null;
    $db = znav_db();
    if ($parent !== null) {
        $st = $db->prepare('SELECT id FROM categories WHERE id=?'); $st->execute(array($parent));
        if (!$st->fetch()) znav_json(array('error' => '父分类不存在'), 400);
    }
    $st = $db->prepare('SELECT id FROM categories WHERE name=? AND ' . ($parent ? 'parent_id=?' : 'parent_id IS NULL'));
    $parent ? $st->execute(array($name, $parent)) : $st->execute(array($name));
    if ($st->fetch()) znav_json(array('error' => '同级分类名称已存在'), 400);
    $max = intval($db->query('SELECT COALESCE(MAX(sort),0) m FROM categories')->fetch()['m']) + 1;
    $db->prepare('INSERT INTO categories(name,icon,parent_id,sort) VALUES(?,?,?,?)')
       ->execute(array(mb_substr($name, 0, 20), trim(isset($input['icon']) ? $input['icon'] : '') ?: '📁', $parent, $max));
    znav_json(array('ok' => true, 'id' => intval($db->lastInsertId())));
}

case 'cat_update': {
    znav_require_admin();
    $db = znav_db();
    $st = $db->prepare('SELECT * FROM categories WHERE id=?'); $st->execute(array(intval($input['id'])));
    $cat = $st->fetch();
    if (!$cat) znav_json(array('error' => '分类不存在'), 404);
    $name = trim(isset($input['name']) ? $input['name'] : '') ?: $cat['name'];
    $icon = trim(isset($input['icon']) ? $input['icon'] : '') ?: $cat['icon'];
    try {
        $db->prepare('UPDATE categories SET name=?, icon=? WHERE id=?')
           ->execute(array(mb_substr($name, 0, 20), $icon, $cat['id']));
        znav_json(array('ok' => true));
    } catch (Exception $e) { znav_json(array('error' => '分类名称已存在'), 400); }
}

case 'cat_delete': {
    znav_require_admin();
    $db = znav_db();
    $st = $db->prepare('SELECT * FROM categories WHERE id=?'); $st->execute(array(intval($input['id'])));
    $cat = $st->fetch();
    if (!$cat) znav_json(array('error' => '分类不存在'), 404);
    $catIds = znav_cat_ids($cat['id']);
    $unc = $db->query("SELECT id FROM categories WHERE name='未分类' AND parent_id IS NULL")->fetch();
    $uncId = $unc ? intval($unc['id']) : 0;
    $isUnc = ($cat['name'] === '未分类' && ($cat['parent_id'] === null || $cat['parent_id'] === ''));

    // 删除的就是「未分类」：其下网址移入排序最前的其他主分类；
    // 若全站已没有其他主分类，则拒绝删除 —— 绝不允许为了删分类而删除网址
    if ($isUnc) {
        $others = $db->query('SELECT id FROM categories WHERE parent_id IS NULL AND id != ' . intval($cat['id']) . ' ORDER BY sort,id')->fetchAll();
        $in = implode(',', $catIds);
        if (!$others) {
            $cnt = $in !== '' ? intval($db->query("SELECT COUNT(*) c FROM sites WHERE category_id IN ($in)")->fetch()['c']) : 0;
            znav_json(array(
                'error' => $cnt > 0
                    ? "不能删除「未分类」：它是 {$cnt} 个网址的唯一归属，且当前没有其他主分类可以接收它们。请先新建其它分类，或直接修改「未分类」的名称/图标。"
                    : "不能删除「未分类」：全站没有其他主分类，删除后将无法收纳网址。请先新建一个分类。",
            ), 400);
        }
        $to = intval($others[0]['id']);
        $moved = 0;
        if ($in !== '') {
            $moved = intval($db->query("SELECT COUNT(*) c FROM sites WHERE category_id IN ($in)")->fetch()['c']);
            $db->exec("UPDATE sites SET category_id=$to WHERE category_id IN ($in)");
            $db->exec("DELETE FROM categories WHERE id IN ($in)");
        }
        znav_json(array('ok' => true, 'moved' => $moved, 'uncRemoved' => true));
    }

    // 普通分类：网址移入「未分类」（此时才惰性创建），分类本身删除
    if (!$uncId) {
        $db->exec("INSERT INTO categories(name,icon,parent_id,sort) VALUES('未分类','🗂️',NULL,99999)");
        $uncId = intval($db->query("SELECT id FROM categories WHERE name='未分类' AND parent_id IS NULL")->fetch()['id']);
    }
    $in = implode(',', array_diff($catIds, array($uncId)));
    $moved = 0;
    if ($in !== '') {
        $moved = intval($db->query("SELECT COUNT(*) c FROM sites WHERE category_id IN ($in)")->fetch()['c']);
        $db->exec("UPDATE sites SET category_id=$uncId WHERE category_id IN ($in)");
        $db->exec("DELETE FROM categories WHERE id IN ($in) AND id != $uncId");
    }
    znav_json(array('ok' => true, 'moved' => $moved));
}

// ---------- 网址 ----------
case 'site_add': {
    // 管理员直接加；登录会员有 can_link 权限也可加（记录 user_id，可自删）
    $isAdmin = znav_is_admin_req();
    $user = null;
    if (!$isAdmin) {
        znav_require_user_header();
        $user = znav_current_user();
        if (!$user) znav_json(array('error' => '请先登录'), 401);
        if (!intval($user['can_link'])) znav_json(array('error' => '当前账号没有添加网址的权限，请联系管理员开通'), 403);
        $cnt = znav_db()->prepare('SELECT COUNT(*) c FROM sites WHERE user_id=?');
        $cnt->execute(array($user['id']));
        if (intval($cnt->fetch()['c']) >= 50) znav_json(array('error' => '最多添加 50 个网址'), 400);
    }
    $url = trim(isset($input['url']) ? $input['url'] : '');
    $name = trim(isset($input['name']) ? $input['name'] : '');
    $catId = intval(isset($input['category_id']) ? $input['category_id'] : 0);
    if ($url === '' || !$catId) znav_json(array('error' => '网址和分类均为必填'), 400);
    if (!preg_match('#^https?://#i', $url)) $url = 'https://' . $url;
    // 提速：名称留空时先用域名占位（前端会在失焦时自动抓标题），Logo 由前端补调 logo_get，不阻塞本请求
    if ($name === '') $name = preg_replace('#^https?://(www\.)?#i', '', $url);
    $db = znav_db();
    $st = $db->prepare('SELECT id FROM categories WHERE id=?'); $st->execute(array($catId));
    if (!$st->fetch()) znav_json(array('error' => '分类不存在'), 400);
    $st = $db->prepare('SELECT COALESCE(MAX(sort),0)+1 m FROM sites WHERE category_id=?');
    $st->execute(array($catId));
    $sort = intval($st->fetch()['m']);
    // 会员添加的网址排在模块最前（否则排在末尾、超出首页每模块展示上限时根本看不到）
    if ($user) $sort = 0;
    $descr = mb_substr(trim(isset($input['descr']) ? $input['descr'] : ''), 0, 100);
    if ($descr === '') { // 描述留空时默认显示域名，保证卡片下方能看到链接
        $host = parse_url($url, PHP_URL_HOST);
        if ($host) $descr = mb_substr($host, 0, 100);
    }
    try {
        $db->prepare('INSERT INTO sites(category_id,name,url,descr,icon,add_date,sort,user_id) VALUES(?,?,?,?,?,?,?,?)')
           ->execute(array($catId, mb_substr($name, 0, 100), substr($url, 0, 800), $descr,
               '', date('Y-m-d H:i:s'), $sort, $user ? intval($user['id']) : 0));
        znav_json(array('ok' => true, 'id' => intval($db->lastInsertId()), 'name' => $name));
    } catch (Exception $e) { znav_json(array('error' => '该网址已存在'), 400); }
}

case 'site_update': {
    znav_require_admin();
    $db = znav_db();
    $st = $db->prepare('SELECT * FROM sites WHERE id=?'); $st->execute(array(intval($input['id'])));
    $site = $st->fetch();
    if (!$site) znav_json(array('error' => '网址不存在'), 404);
    $name = trim(isset($input['name']) ? $input['name'] : '') ?: $site['name'];
    $url = trim(isset($input['url']) ? $input['url'] : '') ?: $site['url'];
    if (!preg_match('#^https?://#i', $url)) $url = 'https://' . $url;
    $descr = isset($input['descr']) ? mb_substr(trim((string)$input['descr']), 0, 100) : $site['descr'];
    $catId = !empty($input['category_id']) ? intval($input['category_id']) : intval($site['category_id']);
    try {
        $db->prepare('UPDATE sites SET category_id=?, name=?, url=?, descr=? WHERE id=?')
           ->execute(array($catId, mb_substr($name, 0, 100), substr($url, 0, 800), $descr, $site['id']));
        // 网址变更时重新识别 Logo
        if ($url !== $site['url']) {
            $logo = '';
            try { $logo = znav_logo_fit(znav_fetch_logo($url)); } catch (Exception $e) {}
            $db->prepare('UPDATE sites SET logo=? WHERE id=?')->execute(array($logo, $site['id']));
        }
        znav_json(array('ok' => true));
    } catch (Exception $e) { znav_json(array('error' => '该网址已存在'), 400); }
}

/** 置顶 / 取消置顶 */
case 'site_pin': {
    znav_require_admin();
    $db = znav_db();
    $st = $db->prepare('SELECT pinned FROM sites WHERE id=?'); $st->execute(array(intval($input['id'])));
    $row = $st->fetch();
    if (!$row) znav_json(array('error' => '网址不存在'), 404);
    $pinned = isset($input['pinned']) ? intval($input['pinned']) : (intval($row['pinned']) ? 0 : 1);
    $db->prepare('UPDATE sites SET pinned=? WHERE id=?')->execute(array($pinned, intval($input['id'])));
    znav_json(array('ok' => true, 'pinned' => $pinned));
}

/** 单个刷新 Logo（管理员；或有 can_link 权限的会员刷新自己添加的） */
case 'logo_get': {
    $isAdmin = znav_is_admin_req();
    $db = znav_db();
    $st = $db->prepare('SELECT id, url, user_id FROM sites WHERE id=?'); $st->execute(array(intval($input['id'])));
    $site = $st->fetch();
    if (!$site) znav_json(array('error' => '网址不存在'), 404);
    if (!$isAdmin) {
        znav_require_user_header();
        $user = znav_current_user();
        if (!$user || intval($site['user_id']) !== intval($user['id'])) znav_json(array('error' => '无权操作'), 403);
    }
    $logo = '';
    try { $logo = znav_logo_fit(znav_fetch_logo($site["url"])); } catch (Exception $e) {}
    $db->prepare('UPDATE sites SET logo=? WHERE id=?')->execute(array($logo, $site['id']));
    znav_json(array('ok' => true, 'logo' => $logo));
}

/** 一键抓取官网 Logo：并发抓取官网首页上的品牌 Logo 大图，只有比现在的更清晰才替换
 *  说明：历史数据里大量图标存在 icon 列（多是 16×16 的 data URI），本接口同时处理 icon 与 logo，
 *        抓取到的高清图标统一写入 logo 列（前台优先显示 logo），本地上传与 emoji 图标不动。 */
case 'logo_hd': {
    znav_require_admin();
    // 单批上限 12：批太大时首页+候选图+兜底三轮的总耗时可能撞上 php.ini 的
    // max_execution_time=100s，请求被强杀后前端重试同一批 → 永远卡住。宁小勿断。
    $limit = min(12, max(1, intval(isset($input['limit']) ? $input['limit'] : 16)));
    // 游标：必须带上，否则每批都从 id 最小处开始，会永远重复处理同一批、进度推不动
    $after = max(0, intval(isset($input['after']) ? $input['after'] : 0));
    // 断点续跑：中途刷新/关掉页面后再点一次，从上次的位置继续，而不是从头重扫
    if ($after === 0) $after = max(0, intval(znav_setting('hdLogoAfter', '0')));
    $db = znav_db();
    // 注意整段必须再包一层括号：OR 的优先级低于 AND，
    // 直接写成 "$where AND id>N" 会被解析成 "(A) OR ((B) AND id>N)" 导致游标失效、永远重复处理同一批
    // uploads/logos/ 是系统自动下载的，可以被重新评估；其它 uploads/ 是用户手工上传的，不参与
    // 用 'uploads/%'（开头匹配）而非 '%uploads%'：否则外链图标里带 uploads/ 字样的会被误判成本地文件
    // 加上 C：完全没有图标的网址也要抓（原先是「自动补齐图标」干的活，两个入口合并后由这里一并处理）
    $where = "((logo<>'' AND (logo NOT LIKE 'uploads/%' OR logo LIKE 'uploads/logos/%'))"
           . " OR (icon LIKE 'http%' OR icon LIKE 'data:%')"
           . " OR ((logo IS NULL OR logo='') AND (icon IS NULL OR icon='')))";
    $total = intval($db->query("SELECT COUNT(*) c FROM sites WHERE $where")->fetch()['c']);
    // 轻量模式：只回总数和断点，不抓任何网页——前端预检用它，避免"准备中"卡几十秒
    if (!empty($input['total_only'])) {
        znav_json(array('ok' => true, 'total' => $total, 'nextId' => $after, 'left' => max(0, $total - intval($db->query("SELECT COUNT(*) c FROM sites WHERE $where AND id<={$after}")->fetch()['c']))));
    }
    $rows = $db->query("SELECT id,name,url,icon,logo FROM sites WHERE $where AND id>$after ORDER BY id LIMIT $limit")->fetchAll();

    $updated = 0; $kept = 0; $failed = 0; $moved = 0; $lastId = $after; $t0 = microtime(true);
    $need = array();       // id => array(oldPx, host, url)
    $upd  = $db->prepare('UPDATE sites SET logo=? WHERE id=?');
    // 逐站点明细（供前端导出 Excel）：[名称, 网址, 状态, 尺寸]
    $logRows = array();
    $logPush = function ($name, $url, $status, $px) use (&$logRows) {
        if (count($logRows) >= 600) return;
        $logRows[] = array((string)$name, (string)$url, $status, $px);
    };
    // 没抓到 Logo 的网址名单（原本就无图标的）：任务结束导出 Excel，方便人工补录
    $nologRows = array();
    $nologPush = function ($name, $url) use (&$nologRows) {
        if (count($nologRows) >= 800) return;
        $nologRows[] = array((string)$name, (string)$url);
    };

    foreach ($rows as $r) {
        $lastId = intval($r['id']);                 // 无论成败游标都要前进（只按本批实际取到的行推进）
        // 扫描阶段留够时间给后面的并发抓取：znav_logo_px 遇到外链图标要下载，单个最坏 5s
        if (microtime(true) - $t0 > 12) break;
        // 用户手工上传的图标（uploads/ 下非 logos 目录）不动；系统自动下载的 uploads/logos/ 仍可重抓
        $lg = trim((string)$r['logo']);
        if ($lg !== '' && preg_match('#^/?uploads/#i', $lg) && stripos($lg, 'uploads/logos/') === false) { $kept++; $logPush($r['name'], $r['url'], '本地上传，不处理', ''); continue; }
        $iconRaw = trim((string)$r['icon']);
        if ($iconRaw !== '' && !preg_match('#^(https?://|data:image)#i', $iconRaw)) { $kept++; continue; } // emoji
        $cur = $lg !== '' ? $lg : $iconRaw;
        // 完全没有图标的网址（原先由「自动补齐图标」负责）：直接进抓取流程，不要跳过
        $oldPx = $cur === '' ? 0 : znav_logo_px($cur);
        // GitHub/Gitee 仓库页特判：旧版本会误把 og:image 宣传卡（1200×600 → 存成 512×256）
        // 当成 Logo，尺寸虽大却不是站点标志。现图只要是系统抓的（uploads/logos/，非人工上传），
        // 就允许无条件换成左上角 owner 头像（oldPx 归零参与比较）。
        if ($oldPx > 0 && stripos($lg, 'uploads/logos/') !== false
            && preg_match('#^https?://(?:www\.)?(?:github|gitee)\.com/[^/]+/[^/]+#i', (string)$r['url'])) {
            $oldPx = 0;
        }
        if ($cur !== '' && $oldPx >= 128) {
            // 已经是高清：若还是内联的 data URI，顺手转存到服务器——
            // 减小数据库体积、浏览器可缓存、不依赖外链。纯本地操作，几乎不耗时。
            if (stripos($cur, 'data:image') === 0 && preg_match('#^data:image/[a-z0-9.+-]+;base64,(.+)$#is', $cur, $mm)) {
                $raw = base64_decode($mm[1], true);
                if ($raw !== false && strlen($raw) >= 60) {
                    $p = znav_logo_store($raw);
                    if ($p !== '') { $upd->execute(array($p, intval($r['id']))); $moved++; $logPush($r['name'], $r['url'], '已是高清，转存服务器', $oldPx . 'px'); continue; }
                }
            }
            $kept++; $logPush($r['name'], $r['url'], '已是高清', $oldPx . 'px'); continue;
        }
        $host = znav_host_of($r['url']);
        if ($host === '') { $failed++; $logPush($r['name'], $r['url'], '网址无效', ''); if ($cur === '') $nologPush($r['name'], $r['url']); continue; }
        $need[intval($r['id'])] = array('oldPx' => $oldPx, 'host' => $host, 'url' => (string)$r['url'], 'name' => (string)$r['name']);
    }

    // 按 host 去重：同一个域名只抓一次，结果应用到该域名下的所有网址。
    // 实测 1515 个网址只有 1103 个不同 host（github.com 一个就占 119 个），不去重要白白多抓 27%
    $hostSites = array();   // host => array(id...)
    foreach ($need as $id => $v) $hostSites[$v['host']][] = $id;
    // 同域名、但不在本批游标范围内的网址也一起带上（后面会一并更新，避免下一批再抓同一个域名）
    // 注意：这些行的 id 可能远超本批游标，但游标只按本批实际取到的行推进，下一批还会正常经过它们
    // （届时已是高清会秒跳过，纯本地测量、不联网）
    $stSame = $db->prepare("SELECT id,name,url,icon,logo FROM sites WHERE $where AND (url LIKE ? OR url LIKE ?)");
    foreach (array_keys($hostSites) as $h) {
        $stSame->execute(array('%://' . $h . '/%', '%://' . $h));
        foreach ($stSame->fetchAll() as $x) {
            $id = intval($x['id']);
            if (isset($need[$id])) continue;
            $lg = trim((string)$x['logo']);
            if ($lg !== '' && stripos($lg, 'uploads/') !== false && stripos($lg, 'uploads/logos/') === false) continue;
            $ic = trim((string)$x['icon']);
            $cur = $lg !== '' ? $lg : $ic;
            if ($cur === '') continue;
            $px = znav_logo_px($cur);
            // 与主循环同样的 GitHub/Gitee 特判：系统抓的宣传卡不算"已是高清"，允许换成 owner 头像
            if ($px > 0 && stripos($lg, 'uploads/logos/') !== false
                && preg_match('#^https?://(?:www\.)?(?:github|gitee)\.com/[^/]+/[^/]+#i', (string)$x['url'])) {
                $px = 0;
            }
            if ($px >= 128) continue;
            $need[$id] = array('oldPx' => $px, 'host' => $h, 'url' => (string)$x['url'], 'name' => (string)$x['name']);
            $hostSites[$h][] = $id;
        }
    }

    // ===== 第一轮：下载官网首页，解析页面上的品牌 Logo 大图 =====
    // 这是能拿到「官网 Logo」的唯一步骤（百度首页的 bd_logo1.png 就是这么来的），
    // 必须放第一轮：若让 favicon 先跑，绝大多数站点第一轮就返回结果了，
    // 根本轮不到这一步，最终抓到的永远只是标签上的小方块。
    // znav_logo_batch_pages 内部已按「品牌 Logo 档 > favicon 档」择优，抓不到 Logo 的站点会自己退回 favicon。
    $pages = array();
    foreach ($hostSites as $h => $ids) $pages[$h] = $need[$ids[0]]['url'];
    try {
        $got = znav_logo_batch_pages($pages, 7, 5);
    } catch (Exception $e) { $got = array(); }

    // 逐个 host 定出最优图，再套用到该域名下的所有网址（同一份文件多处复用，只落盘一次）
    $retry = array();      // host => array(host, url)，没抓到的留给第二轮兜底
    foreach ($hostSites as $h => $ids) {
        $best = isset($got[$h]) ? $got[$h] : null;
        if (!$best) { $retry[$h] = array('host' => $h, 'url' => $need[$ids[0]]['url']); continue; }
        $val = '';
        foreach ($ids as $id) {
            if ($best['px'] <= $need[$id]['oldPx']) { $logPush($need[$id]['name'], $need[$id]['url'], '无更大图', $need[$id]['oldPx'] . 'px'); continue; }   // 这条已经比抓到的更清晰
            if ($val === '') $val = znav_logo_value($best);     // 选定后才落盘，避免孤儿文件
            if ($val === '' || mb_strlen($val) > 60000) { $retry[$h] = array('host' => $h, 'url' => $need[$ids[0]]['url']); break; }
            $upd->execute(array($val, $id));
            $updated++;
            $logPush($need[$id]['name'], $need[$id]['url'], '✅ 已更新Logo', $need[$id]['oldPx'] . 'px → ' . $best['px'] . 'px');
        }
    }

    // 第二轮兜底：第一轮没抓到的，改为下载站点首页解析 <link rel=icon sizes> / apple-touch-icon。
    // 走批量并发版（两轮并发），实测 favicon.im 拿不到的站点（抖音/快手/百度系/阿里等）这条路大多能拿到 32~152px
    // ===== 第二轮兜底：首页完全打不开 / 页面里没有任何图片线索的站点 =====
    // 改走约定路径（android-chrome-512 / apple-touch-icon / favicon.ico / favicon.im）捞最后一张能用的图
    // 已耗时超过 55s 就跳过本轮：防止撞上 php.ini max_execution_time=100s 被强杀
    // （代价：这批里兜底也没抓到的站点本次不重试；数量极少，可下次任务重头跑时补上）
    if ($retry && (microtime(true) - $t0) < 55) {
        // 超时刻意压到 4 秒：抓不到的站点越早失败越好，整批耗时取决于最慢的那个请求
        $tasks = array();
        foreach ($retry as $h => $v) {
            foreach (znav_logo_sources($h) as $i => $u) $tasks[$h . '#' . $i] = $u;
        }
        $res = $tasks ? znav_logo_multi($tasks, 4) : array();
        foreach ($retry as $h => $v) {
            $info = null;
            foreach (znav_logo_sources($h) as $i => $u) {
                // 门槛取 24：多数站点官方图标只有 32×32，但仍比 16×16 清晰
                $x = znav_logo_from_bytes(isset($res[$h . '#' . $i]) ? $res[$h . '#' . $i] : '', $u, 24);
                if ($x && ($info === null || $x['px'] > $info['px'])) $info = $x;
            }
            $val = '';
            $hit = false;
            if ($info) {
                foreach ($hostSites[$h] as $id) {
                    if ($info['px'] <= $need[$id]['oldPx']) { $logPush($need[$id]['name'], $need[$id]['url'], '无更大图', $need[$id]['oldPx'] . 'px'); continue; }
                    if ($val === '') $val = znav_logo_value($info);   // 确认采用后才落盘
                    if ($val === '' || mb_strlen($val) > 60000) break;
                    $upd->execute(array($val, $id));
                    $updated++; $hit = true;
                    $logPush($need[$id]['name'], $need[$id]['url'], '✅ 已更新高清', $need[$id]['oldPx'] . 'px → ' . $info['px'] . 'px');
                }
            }
            if (!$hit) {
                $failed += count($hostSites[$h]);   // 站点本身没有更大的图标，保持原样
                foreach ($hostSites[$h] as $id) {
                    $logPush($need[$id]['name'], $need[$id]['url'], '未找到更大图标', $need[$id]['oldPx'] . 'px');
                    if (intval($need[$id]['oldPx']) === 0) $nologPush($need[$id]['name'], $need[$id]['url']);   // 本来就没有图标的 → 进"无Logo名单"
                }
            }
        }
    }

    // 同域名的网址 id 可能超出本批游标范围（已被一并更新），但游标【只按本批实际取到的行】推进：
    // 之前把 lastId 推到扩展行的最大 id（如 github.com 散布全表），导致 left 直接算成 0、跑一两批就"完成"，
    // 这就是"只下载几个就停止"的根因。扩展行下一批会被正常扫到（届时已是高清，纯本地测量秒过）。
    $left = intval($db->query("SELECT COUNT(*) c FROM sites WHERE $where AND id>" . intval($lastId))->fetch()['c']);
    // $where 已自带外层括号，AND 不会被 OR 吞掉
    // 记下断点；跑完则清掉，下次点击从头开始（已是高清的会自动跳过，很快）
    znav_setting_save('hdLogoAfter', $left > 0 ? (string)intval($lastId) : '');
    znav_json(array('ok' => true, 'updated' => $updated, 'kept' => $kept,
        'failed' => $failed, 'left' => $left, 'total' => $total, 'nextId' => intval($lastId),
        'moved' => $moved, 'log' => $logRows, 'nolog' => $nologRows));
}

/**
 * 一键高清化：把库里全部网址图标重做成 128px 高清 + WebP（视网膜清晰、体积更小加载更快）。
 * 操作前自动备份 uploads/logos 到 uploads/logos._bak_时间戳；逐张处理并更新 DB 引用，旧文件清理。
 */
case 'logo_opt': {
    znav_require_admin();
    $db = znav_db();
    $dir = __DIR__ . '/uploads/logos';   // api.php 在站点根目录，uploads 就在同级的 uploads/
    if (!is_dir($dir)) znav_json(array('error' => 'logos 目录不存在'), 404);
    $limit = min(50, max(1, intval(isset($input['limit']) ? $input['limit'] : 10)));
    $after = max(0, intval(isset($input['after']) ? $input['after'] : 0));
    $doBackup = !empty($input['backup']);

    // 收集 DB 引用的全部 logo 路径（去重，稳定排序，便于分批游标）
    $set = array();
    foreach (array('logo', 'icon') as $col) {
        $rs = $db->query("SELECT DISTINCT $col AS p FROM sites WHERE $col LIKE 'uploads/logos/%' ORDER BY $col ASC")->fetchAll();
        foreach ($rs as $r) if (!empty($r['p'])) $set[$r['p']] = true;
    }
    $paths = array_values(array_keys($set));
    $total = count($paths);

    // 备份只在第一批做（backup=1），并记录目录名供最终汇总；后续批次跳过，避免重复备份
    if ($doBackup) {
        $bak = $dir . '._bak_' . date('YmdHis');
        znav_copy_dir($dir, $bak);
        znav_setting_save('logoOptBak', basename($bak));
    }
    $bakName = znav_setting('logoOptBak', '');

    // 只处理本批切片（游标 = 数组下标），避免一次性处理全部导致前端长时间无反馈 / PHP 超时
    $slice = array_slice($paths, $after, $limit);
    $proc = 0; $err = 0; $sizeBefore = 0; $sizeAfter = 0; $map = array();
    foreach ($slice as $old) {
        $fp = $dir . '/' . basename($old);
        if (!is_file($fp)) continue;
        $sizeBefore += filesize($fp);
        $b = file_get_contents($fp);
        $src0 = @imagecreatefromstring($b);
        if (!$src0) $src0 = znav_ico_best_image($b);
        if (!$src0) { $err++; continue; }
        $src = znav_logo_normalize($src0, 128);
        if ($src === false) { $err++; continue; }
        $base = 'lg_' . date('YmdHis') . '_' . mt_rand(1000, 9999);
        $new = znav_logo_write($src, $dir, $base);
        imagedestroy($src);
        if ($new === '') { $err++; continue; }
        $map[$old] = $new;
        $sizeAfter += @filesize($dir . '/' . basename($new));
        $proc++;
    }
    // 统一更新 DB 引用
    foreach ($map as $old => $new) {
        $db->prepare('UPDATE sites SET logo=? WHERE logo=?')->execute(array($new, $old));
        $db->prepare('UPDATE sites SET icon=? WHERE icon=?')->execute(array($new, $old));
    }
    // 删除已被替换的旧文件
    foreach ($map as $old => $new) {
        if ($new !== $old) { $fp = $dir . '/' . basename($old); if (is_file($fp)) @unlink($fp); }
    }
    @touch($dir);   // 触发 lgv 变化 → 前端 ?v= 缓存失效
    $nextAfter = $after + count($slice);
    $left = max(0, $total - $nextAfter);
    znav_json(array(
        'ok' => true, 'processed' => $proc, 'errors' => $err,
        'sizeBeforeKB' => round($sizeBefore / 1024), 'sizeAfterKB' => round($sizeAfter / 1024),
        'after' => $nextAfter, 'left' => $left, 'total' => $total,
        'backup' => $bakName ? ('uploads/' . $bakName) : '',
    ));
}

/**
 * 把库里所有内联的 data URI 图标转存成服务器文件（uploads/logos/）。
 * 纯本地操作、不联网：减小数据库体积、浏览器可缓存、统一存储方式。
 */
case 'logo_files': {
    znav_require_admin();
    $limit = min(400, max(1, intval(isset($input['limit']) ? $input['limit'] : 300)));
    $after = max(0, intval(isset($input['after']) ? $input['after'] : 0));
    $db  = znav_db();
    $cond = "((logo LIKE 'data:image%') OR (logo='' AND icon LIKE 'data:image%'))";
    $rows = $db->query("SELECT id,icon,logo FROM sites WHERE $cond AND id>$after ORDER BY id LIMIT $limit")->fetchAll();
    $moved = 0; $lastId = $after;
    $upd = $db->prepare('UPDATE sites SET logo=? WHERE id=?');
    foreach ($rows as $r) {
        $lastId = intval($r['id']);
        $cur = trim((string)$r['logo']) !== '' ? trim((string)$r['logo']) : trim((string)$r['icon']);
        if (stripos($cur, 'data:image') !== 0) continue;
        if (!preg_match('#^data:image/[a-z0-9.+-]+;base64,(.+)$#is', $cur, $m)) continue;
        $raw = base64_decode($m[1], true);
        if ($raw === false || strlen($raw) < 60) continue;
        $p = znav_logo_store($raw);
        if ($p !== '') { $upd->execute(array($p, intval($r['id']))); $moved++; }
    }
    $left = intval($db->query("SELECT COUNT(*) c FROM sites WHERE $cond AND id>" . intval($lastId))->fetch()['c']);
    znav_json(array('ok' => true, 'moved' => $moved, 'left' => $left, 'nextId' => intval($lastId)));
}

case 'site_delete': {
    // 管理员可删任何；登录会员只能删自己添加的网址
    if (znav_is_admin_req()) {
        znav_db()->prepare('DELETE FROM sites WHERE id=?')->execute(array(intval($input['id'])));
        znav_json(array('ok' => true));
    }
    znav_require_user_header();
    $user = znav_current_user();
    if (!$user) znav_json(array('error' => '请先登录'), 401);
    $st = znav_db()->prepare('SELECT user_id FROM sites WHERE id=?');
    $st->execute(array(intval($input['id'])));
    $row = $st->fetch();
    if (!$row) znav_json(array('ok' => true));
    if (intval($row['user_id']) !== intval($user['id'])) znav_json(array('error' => '只能删除自己添加的网址'), 403);
    znav_db()->prepare('DELETE FROM sites WHERE id=?')->execute(array(intval($input['id'])));
    znav_json(array('ok' => true));
}

/** 网址批量操作：delete / move */
case 'site_batch': {
    znav_require_admin();
    $ids = array_filter(array_map('intval', isset($input['ids']) ? (array)$input['ids'] : array()));
    if (!$ids) znav_json(array('error' => '未选择任何网址'), 400);
    $in = implode(',', $ids);
    $db = znav_db();
    $act = isset($input['action']) ? $input['action'] : '';
    if ($act === 'delete') {
        $db->exec("DELETE FROM sites WHERE id IN ($in)");
        znav_json(array('ok' => true, 'affected' => count($ids)));
    }
    if ($act === 'move') {
        $catId = intval(isset($input['category_id']) ? $input['category_id'] : 0);
        if (!$catId) znav_json(array('error' => '请选择目标分类'), 400);
        $db->exec("UPDATE sites SET category_id=$catId WHERE id IN ($in)");
        znav_json(array('ok' => true, 'affected' => count($ids)));
    }
    znav_json(array('error' => '未知批量操作'), 400);
}

/** 功能隐藏解锁：校验功能密码（bcrypt 哈希比对，出厂默认见 ZNAV_FEAT_PWD_DEFAULT_HASH，后台「系统设置」可改） */
case 'feat_unlock': {
    znav_require_admin();
    $pwd = trim((string)(isset($input['pwd']) ? $input['pwd'] : ''));
    if (!znav_feat_verify($pwd)) znav_json(array('error' => '功能密码不对，再想想'), 403);
    znav_json(array('ok' => true));
}

/** 单个网址：立即重抓高清 Logo（网址管理每行「🖼 Logo」按钮） */
case 'logo_one': {
    znav_require_admin();
    $id = intval(isset($input['id']) ? $input['id'] : 0);
    $db = znav_db();
    $st = $db->prepare('SELECT id,name,url,icon,logo FROM sites WHERE id=?'); $st->execute(array($id));
    $r = $st->fetch();
    if (!$r) znav_json(array('error' => '网址不存在'), 404);
    $host = znav_host_of((string)$r['url']);
    if ($host === '') znav_json(array('error' => '网址无效，无法抓取'), 400);
    $lg = trim((string)$r['logo']); $iconRaw = trim((string)$r['icon']);
    $cur = $lg !== '' ? $lg : $iconRaw;
    $oldPx = $cur === '' ? 0 : znav_logo_px($cur);
    // GitHub/Gitee 特判：系统抓的 og 宣传卡不算高清，允许无条件换成 owner 头像
    if ($oldPx > 0 && stripos($lg, 'uploads/logos/') !== false
        && preg_match('~^https?://(?:www\.)?(?:github|gitee)\.com/[^/]+/[^/]+~i', (string)$r['url'])) {
        $oldPx = 0;
    }
    // 第一轮：下载官网首页解析品牌 Logo 大图（与批量任务同源）
    $best = null;
    try {
        $got = znav_logo_batch_pages(array($host => (string)$r['url']), 7, 5);
        if (isset($got[$host])) $best = $got[$host];
    } catch (Exception $e) { $best = null; }
    // 第二轮兜底：约定路径（apple-touch-icon / favicon.ico 等）
    if (!$best) {
        $tasks = array();
        foreach (znav_logo_sources($host) as $i => $u) $tasks[$host . '#' . $i] = $u;
        $res = $tasks ? znav_logo_multi($tasks, 4) : array();
        foreach (znav_logo_sources($host) as $i => $u) {
            $x = znav_logo_from_bytes(isset($res[$host . '#' . $i]) ? $res[$host . '#' . $i] : '', $u, 24);
            if ($x && ($best === null || $x['px'] > $best['px'])) $best = $x;
        }
    }
    if (!$best) znav_json(array('error' => '没有抓到可用的 Logo（站点打不开或页面上没有图标）'), 200);
    // 单站抓取 = 强制更新：只要抓到就用最新的，不再因"现有更清晰"而保持不变
    $val = znav_logo_value($best);
    if ($val === '' || mb_strlen($val) > 60000) znav_json(array('error' => '抓到的图片无法保存'), 500);
    $db->prepare('UPDATE sites SET logo=? WHERE id=?')->execute(array($val, $id));
    znav_json(array('ok' => true, 'px' => intval($best['px']), 'old' => $oldPx,
        'msg' => '已更新为 ' . intval($best['px']) . 'px 图标' . ($oldPx > 0 ? '（原 ' . $oldPx . 'px）' : '')));
}

/** 音乐文件上传（后台「系统设置 → 背景音乐」）：mp3/m4a/wav/ogg/flac/aac/opus，≤50MB，存 uploads/music/ */
case 'music_upload': {
    znav_require_admin();
    if (empty($_FILES['file'])) znav_json(array('error' => '没有收到文件'), 400);
    $f = $_FILES['file'];
    $name = isset($f['name']) ? (string)$f['name'] : '';
    $size = isset($f['size']) ? intval($f['size']) : 0;
    $err  = isset($f['error']) ? intval($f['error']) : 1;
    $tmp  = isset($f['tmp_name']) ? $f['tmp_name'] : '';
    if ($err === UPLOAD_ERR_INI_SIZE || $err === UPLOAD_ERR_FORM_SIZE) {
        znav_json(array('error' => '文件超过服务器限制（需调大 PHP 的 upload_max_filesize / post_max_size）'), 400);
    }
    $path = znav_save_music($tmp, $err, $size, 50, $name);
    if ($path === '') znav_json(array('error' => '上传失败：仅支持 mp3/m4a/wav/ogg/flac/aac/opus，≤50MB'), 400);
    $title = pathinfo($name, PATHINFO_FILENAME);
    znav_json(array('ok' => true, 'url' => '/' . $path, 'name' => $title !== '' ? $title : '未命名'));
}

/** 上传网址 Logo（表单字段 file）。id 兼容查询串：multipart 请求的 $input 回退为 $_POST，URL 上的 id 必须从 $_GET 取 */
case 'logo_upload': {
    znav_require_admin();
    $id = intval(isset($input['id']) ? $input['id'] : (isset($_GET['id']) ? $_GET['id'] : 0));
    $db = znav_db();
    $st = $db->prepare('SELECT id FROM sites WHERE id=?'); $st->execute(array($id));
    if (!$st->fetch()) znav_json(array('error' => '网址不存在'), 404);
    $path = znav_save_image($_FILES['file']['tmp_name'] ?? '', $_FILES['file']['error'] ?? 1, $_FILES['file']['size'] ?? 0, 3);
    if ($path === '') znav_json(array('error' => '上传失败：仅支持 jpg/png/webp/gif/ico，≤3MB'), 400);
    $db->prepare('UPDATE sites SET logo=? WHERE id=?')->execute(array($path, $id));
    znav_json(array('ok' => true, 'logo' => $path));
}

/** 圆形截取 Logo：前端 canvas 已裁好 256×256 圆形透明 PNG（dataURI），这里只负责落盘并绑定 */
case 'logo_crop': {
    znav_require_admin();
    $id = intval(isset($input['id']) ? $input['id'] : (isset($_GET['id']) ? $_GET['id'] : 0));
    $data = trim((string)(isset($input['data']) ? $input['data'] : ''));
    $db = znav_db();
    $st = $db->prepare('SELECT id FROM sites WHERE id=?'); $st->execute(array($id));
    if (!$st->fetch()) znav_json(array('error' => '网址不存在'), 404);
    if (!preg_match('#^data:image/(png|jpeg|webp);base64,(.+)$#is', $data, $m)) znav_json(array('error' => '图片数据无效'), 400);
    $bytes = base64_decode($m[2], true);
    if (!$bytes || strlen($bytes) < 60 || strlen($bytes) > 1500000) znav_json(array('error' => '图片数据无效或过大'), 400);
    $path = znav_logo_store($bytes, 256);
    if ($path === '') znav_json(array('error' => '保存失败：无法解析图片'), 500);
    $db->prepare('UPDATE sites SET logo=? WHERE id=?')->execute(array($path, $id));
    znav_json(array('ok' => true, 'logo' => $path));
}

/** 图片代理：把外链图片取回本域（带 SSRF 防护），供截取弹窗加载进 canvas（避免跨域污染画布） */
case 'logo_proxy': {
    znav_require_admin();
    $url = trim((string)(isset($input['url']) ? $input['url'] : (isset($_GET['url']) ? $_GET['url'] : '')));
    if (!preg_match('#^https?://#i', $url)) znav_json(array('error' => '仅支持 http(s) 图片地址'), 400);
    if (!znav_safe_remote_url($url)) znav_json(array('error' => '该地址不允许访问'), 400);
    list($bytes, ) = znav_http_get($url, 12);
    if (!$bytes || $bytes === '') znav_json(array('error' => '服务器抓不到这张图（超时或地址不可达）'), 502);
    $info = @getimagesizefromstring($bytes);
    $head = substr(ltrim($bytes), 0, 1024);
    $isSvg = (stripos($head, '<svg') !== false);
    if (!$info && !$isSvg) znav_json(array('error' => '该地址不是有效图片（返回的是网页或其它内容）'), 400);
    $mime = $isSvg ? 'image/svg+xml' : (!empty($info['mime']) ? $info['mime'] : 'image/png');   // 小图（如 1×1 gif）也放行，不再按体积拒绝
    header('Content-Type: ' . $mime);
    header('Content-Length: ' . strlen($bytes));
    header('Cache-Control: private, max-age=300');
    echo $bytes;
    exit;
}

/** 重复网址扫描：按规范化 URL 分组。
 *  只剥离跟踪参数（spm_id_from / vd_source / utm_* 等），保留 p= 等有效参数——
 *  像 B 站同一视频的 p=74 / p=77 是不同分集，不能算重复；
 *  「同页面不同参数」另外列为疑似重复，默认不勾选。 */
case 'dup_scan': {
    znav_require_admin();
    $db = znav_db();
    $rows = $db->query('SELECT s.id,s.name,s.url,s.clicks,c.name AS cat FROM sites s LEFT JOIN categories c ON c.id=s.category_id ORDER BY s.id')->fetchAll();
    $TRACK = 'spm_id_from|spm_id|vd_source|utm_\w+|from|share_\w+|fr|vd|bbid|buvid|unique_k|timestamp|sign';
    $normFull = function ($u) use ($TRACK) {   // 完全相同才算重复
        $u = trim((string)$u);
        if ($u === '') return '';
        $u = preg_replace('~^https?://~i', '', $u);
        $u = preg_replace('~^www\.~i', '', $u);
        $u = preg_replace('~#.*$~', '', $u);
        $u = preg_replace('~(' . $TRACK . ')=[^&]*&?~i', '', $u);
        $u = rtrim($u, '&');
        $u = preg_replace('~\?$~', '', $u);
        $u = preg_replace('~/index\.(html?|php)$~i', '', $u);
        $u = rtrim($u, '/');
        $u = preg_replace('~&{2,}~', '&', $u);
        // 域名部分小写，路径保留原样（有些站点路径区分大小写）
        $slash = strpos($u, '/');
        return $slash === false ? strtolower($u) : strtolower(substr($u, 0, $slash)) . substr($u, $slash);
    };
    $normPath = function ($u) {                // 同页面（忽略参数）：疑似重复
        $u = trim((string)$u);
        if ($u === '') return '';
        $u = preg_replace('~^https?://~i', '', $u);
        $u = preg_replace('~^www\.~i', '', $u);
        $u = preg_replace('~[?#].*$~', '', $u);
        $u = preg_replace('~/index\.(html?|php)$~i', '', $u);
        return strtolower(rtrim($u, '/'));
    };
    $byFull = array(); $byPath = array();
    foreach ($rows as $r) {
        $f = $normFull($r['url']);
        $p = $normPath($r['url']);
        if ($f !== '') {
            $it = array('id' => intval($r['id']), 'name' => (string)$r['name'], 'url' => (string)$r['url'], 'cat' => (string)$r['cat'], 'clicks' => intval($r['clicks']));
            $byFull[$f][] = $it;
            $byPath[$p][] = $it;
        }
    }
    $dups = array_values(array_filter($byFull, function ($g) { return count($g) > 1; }));
    usort($dups, function ($a, $b) { return count($b) - count($a); });
    // 疑似：同页面多条但不是完全重复（排除已进 dups 的）
    $exactKeys = array();
    foreach ($dups as $g) foreach ($g as $it) $exactKeys[$it['id']] = 1;
    $sus = array();
    foreach ($byPath as $p => $g) {
        if (count($g) < 2) continue;
        $q = array_filter($g, function ($it) use ($exactKeys) { return empty($exactKeys[$it['id']]); });
        if (count($q) > 1) $sus[] = array_values($q);
    }
    usort($sus, function ($a, $b) { return count($b) - count($a); });
    $dupSites = 0; foreach ($dups as $g) $dupSites += count($g);
    $susSites = 0; foreach ($sus as $g) $susSites += count($g);
    znav_json(array('ok' => true, 'groups' => $dups, 'dupSites' => $dupSites,
        'suspects' => $sus, 'suspectSites' => $susSites, 'total' => count($rows)));
}

/** 删除重复扫描里勾选的网址 */
case 'dup_delete': {
    znav_require_admin();
    $ids = array_values(array_unique(array_filter(array_map('intval', isset($input['ids']) ? (array)$input['ids'] : array()))));
    if (!$ids) znav_json(array('error' => '未选择要删除的网址'), 400);
    $in = implode(',', $ids);
    $n = znav_db()->exec("DELETE FROM sites WHERE id IN ($in)");
    znav_json(array('ok' => true, 'affected' => $n));
}

/** 上传分类图标（表单字段 file） */
case 'icon_upload': {
    znav_require_admin();
    $path = znav_save_image($_FILES['file']['tmp_name'] ?? '', $_FILES['file']['error'] ?? 1, $_FILES['file']['size'] ?? 0, 3);
    if ($path === '') znav_json(array('error' => '上传失败：仅支持 jpg/png/webp/gif/ico，≤3MB'), 400);
    znav_json(array('ok' => true, 'icon' => $path));
}

// ---------- 分类批量 ----------
case 'cat_batch': {
    znav_require_admin();
    $ids = array_filter(array_map('intval', isset($input['ids']) ? (array)$input['ids'] : array()));
    if (!$ids) znav_json(array('error' => '未选择任何分类'), 400);
    $in = implode(',', $ids);
    $db = znav_db();
    $act = isset($input['action']) ? $input['action'] : '';
    if ($act === 'delete') {
        $unc = $db->query("SELECT id FROM categories WHERE name='未分类' AND parent_id IS NULL")->fetch();
        if (!$unc) {
            $db->exec("INSERT INTO categories(name,icon,parent_id,sort) VALUES('未分类','🗂️',NULL,99999)");
            $unc = $db->query("SELECT id FROM categories WHERE name='未分类' AND parent_id IS NULL")->fetch();
        }
        $uncId = intval($unc['id']);
        // 收集选中分类及其子分类
        $all = $ids;
        $st = $db->query("SELECT id FROM categories WHERE parent_id IN ($in)");
        foreach ($st->fetchAll() as $r) { $all[] = intval($r['id']); }
        $allIn = implode(',', array_unique($all));
        $db->exec("UPDATE sites SET category_id=$uncId WHERE category_id IN ($allIn) AND category_id != $uncId");
        $db->exec("DELETE FROM categories WHERE id IN ($allIn) AND id != $uncId");
        znav_json(array('ok' => true, 'affected' => count($all)));
    }
    if ($act === 'move') {
        // parent_id=null → 提为主分类；否则移到指定主分类下
        $parent = isset($input['parent_id']) && $input['parent_id'] !== '' && $input['parent_id'] !== null
            ? intval($input['parent_id']) : null;
        foreach ($ids as $id) {
            // 不能把自己挂到自己/自己的子分类下
            if ($parent !== null && ($id === $parent || intval($db->query("SELECT parent_id FROM categories WHERE id=$id")->fetch()['parent_id']) === $id)) continue;
            $st = $db->prepare('UPDATE categories SET parent_id=? WHERE id=?');
            $st->execute(array($parent, $id));
        }
        znav_json(array('ok' => true, 'affected' => count($ids)));
    }
    znav_json(array('error' => '未知批量操作'), 400);
}

// ---------- 广告 ----------
case 'ads_list': {
    znav_require_admin();
    $items = znav_db()->query('SELECT * FROM ads ORDER BY position,sort,id')->fetchAll();
    foreach ($items as &$a) {
        $a['id'] = intval($a['id']); $a['sort'] = intval($a['sort']);
        $a['enabled'] = intval($a['enabled']);
        $a['img_w'] = isset($a['img_w']) ? intval($a['img_w']) : 0;
        $a['img_h'] = isset($a['img_h']) ? intval($a['img_h']) : 0;
    }
    znav_json(array('ok' => true, 'items' => $items));
}

case 'ad_delete': {
    znav_require_admin();
    znav_db()->prepare('DELETE FROM ads WHERE id=?')->execute(array(intval($input['id'])));
    znav_json(array('ok' => true));
}

case 'ad_add': {
    znav_require_admin();
    $title = trim(isset($input['title']) ? $input['title'] : '');
    $pos = isset($input['position']) ? $input['position'] : 'top';
    if ($title === '') znav_json(array('error' => '广告标题必填'), 400);
    if (!in_array($pos, array('top', 'bottom', 'left', 'right', 'inline'))) znav_json(array('error' => '广告位置无效'), 400);
    $db = znav_db();
    $imgW = max(0, min(2000, intval(isset($input['img_w']) ? $input['img_w'] : 0)));
    $imgH = max(0, min(2000, intval(isset($input['img_h']) ? $input['img_h'] : 0)));
    $style = isset($input['style']) ? trim((string)$input['style']) : 'image';
    if (!in_array($style, array('image', 'mixed', 'text', 'html'), true)) $style = 'image';
    $fit = isset($input['img_fit']) ? trim((string)$input['img_fit']) : 'cover';
    if (!in_array($fit, array('cover', 'contain', 'fill'), true)) $fit = 'cover';
    $radius = max(0, min(40, intval(isset($input['radius']) ? $input['radius'] : 14)));
    $bgcolor = substr(trim(isset($input['bgcolor']) ? (string)$input['bgcolor'] : ''), 0, 24);
    $target = (isset($input['target']) && (string)$input['target'] === '_self') ? '_self' : '_blank';

    $st = $db->prepare('SELECT COALESCE(MAX(sort),0)+1 m FROM ads WHERE position=?'); $st->execute(array($pos));
    $db->prepare('INSERT INTO ads(title,image,link,descr,position,img_w,img_h,sort,enabled,style,img_fit,radius,bgcolor,target) VALUES(?,?,?,?,?,?,?,?,1,?,?,?,?,?)')
       ->execute(array(mb_substr($title, 0, 60), substr(trim(isset($input['image']) ? $input['image'] : ''), 0, 500),
           substr(trim(isset($input['link']) ? $input['link'] : ''), 0, 500),
           mb_substr(trim(isset($input['content']) ? (string)$input['content'] : ''), 0, 3000),
           $pos, $imgW, $imgH,
           intval($st->fetch()['m']), $style, $fit, $radius, $bgcolor, $target));
    znav_json(array('ok' => true, 'id' => intval($db->lastInsertId())));
}

case 'ad_update': {
    znav_require_admin();
    $db = znav_db();
    $st = $db->prepare('SELECT * FROM ads WHERE id=?'); $st->execute(array(intval($input['id'])));
    $ad = $st->fetch();
    if (!$ad) znav_json(array('error' => '广告不存在'), 404);
    $enabled = isset($input['enabled']) ? (empty($input['enabled']) ? 0 : 1) : intval($ad['enabled']);
    $style = isset($input['style']) ? trim((string)$input['style']) : (isset($ad['style']) ? (string)$ad['style'] : 'image');
    if (!in_array($style, array('image', 'mixed', 'text', 'html'), true)) $style = 'image';
    $fit = isset($input['img_fit']) ? trim((string)$input['img_fit']) : (isset($ad['img_fit']) ? (string)$ad['img_fit'] : 'cover');
    if (!in_array($fit, array('cover', 'contain', 'fill'), true)) $fit = 'cover';
    $radius = isset($input['radius']) ? max(0, min(40, intval($input['radius']))) : intval(isset($ad['radius']) ? $ad['radius'] : 14);
    $bgcolor = isset($input['bgcolor']) ? substr(trim((string)$input['bgcolor']), 0, 24) : (isset($ad['bgcolor']) ? (string)$ad['bgcolor'] : '');
    $target = isset($input['target']) ? (((string)$input['target'] === '_self') ? '_self' : '_blank') : (isset($ad['target']) ? (string)$ad['target'] : '_blank');
    // descr 存短文案（兼容富文本正文）
    $db->prepare('UPDATE ads SET title=?, image=?, link=?, descr=?, position=?, img_w=?, img_h=?, sort=?, enabled=?, style=?, img_fit=?, radius=?, bgcolor=?, target=? WHERE id=?')
       ->execute(array(
           mb_substr(trim(isset($input['title']) ? $input['title'] : $ad['title']), 0, 60),
           substr(trim(isset($input['image']) ? $input['image'] : $ad['image']), 0, 500),
           substr(trim(isset($input['link']) ? $input['link'] : $ad['link']), 0, 500),
           mb_substr(trim(isset($input['descr']) ? (string)$input['descr'] : (isset($input['content']) ? (string)$input['content'] : $ad['descr'])), 0, 3000),
           isset($input['position']) ? $input['position'] : $ad['position'],
           isset($input['img_w']) ? max(0, min(2000, intval($input['img_w']))) : intval($ad['img_w']),
           isset($input['img_h']) ? max(0, min(2000, intval($input['img_h']))) : intval($ad['img_h']),
           isset($input['sort']) ? intval($input['sort']) : intval($ad['sort']),
           $enabled, $style, $fit, $radius, $bgcolor, $target, $ad['id']));
    znav_json(array('ok' => true));
}

/** 广告图片上传（表单字段 file，返回路径） */
case 'ad_upload': {
    znav_require_admin();
    $f = isset($_FILES['file']) ? $_FILES['file'] : array();
    $path = znav_save_image_any(
        $f['tmp_name'] ?? '',
        $f['error'] ?? 1,
        $f['size'] ?? 0,
        8,
        isset($f['name']) ? (string)$f['name'] : ''
    );
    if ($path === '') znav_json(array('error' => '上传失败：仅支持图片，≤8MB'), 400);
    znav_json(array('ok' => true, 'url' => $path));
}

/** 通用多媒体上传端点：支持图片与视频，返回 {ok,url,type,size}
 *  form 字段：file；可选字段 kind=image|video|auto（默认 auto） */
case 'media_upload': {
    znav_require_admin();
    if (empty($_FILES['file'])) znav_json(array('error' => '没有收到文件'), 400);
    $f = $_FILES['file'];
    $name = isset($f['name']) ? (string)$f['name'] : '';
    $size = isset($f['size']) ? intval($f['size']) : 0;
    $err  = isset($f['error']) ? intval($f['error']) : 1;
    $tmp  = isset($f['tmp_name']) ? $f['tmp_name'] : '';
    if ($err === UPLOAD_ERR_INI_SIZE || $err === UPLOAD_ERR_FORM_SIZE) {
        znav_json(array('error' => '文件超过服务器限制（请到 PHP 设置里调大 upload_max_filesize / post_max_size）'), 400);
    }
    if ($err === UPLOAD_ERR_PARTIAL) znav_json(array('error' => '文件上传不完整，请重试'), 400);
    if ($err !== UPLOAD_ERR_OK) znav_json(array('error' => '上传失败，错误码 ' . $err), 400);

    $path = '';
    $type = 'image';
    // 图片优先：≤10MB 且不是明显视频扩展名
    $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
    $videoExt = array('mp4', 'webm', 'mov', 'm4v', 'avi', 'mkv', 'ogv', 'flv');
    if (!in_array($ext, $videoExt, true)) {
        $path = znav_save_image_any($tmp, $err, $size, 10, $name);
        $type = 'image';
    }
    if ($path === '') {
        $path = znav_save_video($tmp, $err, $size, 200, $name);
        $type = 'video';
    }
    if ($path === '') {
        // 最后兜底：再试一次图片（某些视频被浏览器识别为 octet-stream 但实为图片）
        $alt = znav_save_image_any($tmp, $err, $size, 10, $name);
        if ($alt !== '') { $path = $alt; $type = 'image'; }
    }
    if ($path === '') znav_json(array('error' => '不支持的文件类型（图片 ≤10MB / 视频 ≤200MB）'), 400);
    znav_json(array('ok' => true, 'url' => '/' . $path, 'type' => $type, 'size' => $size, 'name' => $name));
}

case 'video_upload': {
    znav_require_admin();
    $f = isset($_FILES['file']) ? $_FILES['file'] : array();
    if (empty($f)) znav_json(array('error' => '没有收到文件'), 400);
    $path = znav_save_video(
        $f['tmp_name'] ?? '',
        $f['error'] ?? 1,
        $f['size'] ?? 0,
        200,
        isset($f['name']) ? (string)$f['name'] : ''
    );
    if ($path === '') znav_json(array('error' => '视频上传失败：仅支持 mp4/webm/mov/avi/mkv，≤200MB'), 400);
    znav_json(array('ok' => true, 'url' => $path));
}

/** 死链扫描：并发探测一批网址，前端循环调用
 *  body: {offset, batch} → 返回本批每条结果 + 总数
 *  提速要点：整批 URL 一起并发发出（znav_probe_multi），墙钟时间 ≈ 本批最慢的一个，
 *  而不是所有耗时的累加。老版本逐条串行 + 每条失败再重试一次，单个超时站就能耗 10 秒，
 *  扫完 1761 条要几个小时；现在一批 30 条约 6 秒，全程 6 分钟左右。
 *  判定要点：连不上（unreachable）与真失效（dead）分开——YouTube 这类站在国内服务器
 *  直连必超时，老版本把它们一律算成死链并提示删除，属于误判。 */
case 'site_check': {
    znav_require_admin();
    $batch   = min(80, max(1, intval(isset($input['batch']) ? $input['batch'] : 30)));
    $timeout = min(10, max(3, intval(isset($input['timeout']) ? $input['timeout'] : 5)));
    $offset  = max(0, intval(isset($input['offset']) ? $input['offset'] : 0));
    // 并发几十个请求可能需要超过默认 30 秒的限制
    if (function_exists('set_time_limit')) @set_time_limit(180);
    $db = znav_db();
    $total = intval($db->query('SELECT COUNT(*) FROM sites')->fetchColumn());
    $rows  = $db->query("SELECT id,name,url FROM sites ORDER BY id LIMIT $batch OFFSET $offset")->fetchAll();

    $items = array();
    $map   = array();      // id => url（空网址直接不进探测队列）
    $meta  = array();      // id => row
    foreach ($rows as $r) {
        $id = intval($r['id']);
        $u  = trim((string)$r['url']);
        $meta[$id] = $r;
        if ($u === '') continue;
        $map[$id] = $u;
    }

    $t0 = microtime(true);
    $probe = array();
    if ($map) {
        try {
            // 内部已含一轮兜底：HEAD 拿不到状态码的会并发重发一次 GET
            $probe = znav_probe_multi($map, $timeout);
        } catch (Throwable $ex) {
            $probe = array();      // 并发层整体异常时退化成"全部不可达"，但绝不把请求打成 500
        }
    }
    $costMs = intval(round((microtime(true) - $t0) * 1000));

    foreach ($meta as $id => $r) {
        $url = trim((string)$r['url']);
        if ($url === '') {
            $items[] = array('id' => $id, 'name' => (string)$r['name'], 'url' => '',
                'alive' => 0, 'code' => 0, 'note' => '网址为空', 'kind' => 'dead', 'ms' => 0);
            continue;
        }
        if (isset($probe[$id])) {
            $p = $probe[$id];
            $cls = znav_status_classify($p['code'], $p['errno'], $p['errmsg']);
            $ms  = intval($p['ms']);
        } else {
            // 探测队列里没有它（被 SSRF 防护拦下 / 并发层异常）
            $cls = array(false, 0, '未探测（已跳过）', 'unreachable');
            $ms = 0;
        }
        $items[] = array(
            'id'    => $id,
            'name'  => (string)$r['name'],
            'url'   => $url,
            'alive' => $cls[0] ? 1 : 0,
            'code'  => intval($cls[1]),
            'note'  => $cls[2],
            'kind'  => $cls[3],
            'ms'    => $ms,
        );
    }
    $isAlive = function ($x) { return !empty($x['alive']); };
    znav_json(array(
        'ok'      => true,
        'total'   => $total,
        'offset'  => $offset,
        'checked' => count($meta),
        'costMs'  => $costMs,
        'items'   => $items,
        'dead'    => array_values(array_filter($items, function ($x) { return empty($x['alive']); })),
    ));
}

// ---------- 文章（首页右侧，可拖动排序） ----------
case 'articles_list': {
    $items = znav_db()->query('SELECT * FROM articles ORDER BY sort,id')->fetchAll();
    foreach ($items as &$a) {
        $a['id'] = intval($a['id']); $a['sort'] = intval($a['sort']); $a['enabled'] = intval($a['enabled']);
    }
    znav_json(array('ok' => true, 'items' => $items));
}

case 'article_save': {
    znav_require_admin();
    $db = znav_db();
    $title = mb_substr(trim(isset($input['title']) ? $input['title'] : ''), 0, 80);
    if ($title === '') znav_json(array('error' => '文章标题必填'), 400);
    $id = intval(isset($input['id']) ? $input['id'] : 0);
    $summary = mb_substr(trim(isset($input['summary']) ? (string)$input['summary'] : ''), 0, 200);
    $content = mb_substr((string)(isset($input['content']) ? $input['content'] : ''), 0, 30000);
    $image = substr(trim(isset($input['image']) ? (string)$input['image'] : ''), 0, 500);
    $link = substr(trim(isset($input['link']) ? (string)$input['link'] : ''), 0, 500);
    $sort = isset($input['sort']) ? intval($input['sort']) : 99;
    $enabled = isset($input['enabled']) && !$input['enabled'] ? 0 : 1;
    $pageSlug = isset($input['page_slug']) ? preg_replace('/[^a-z0-9\-]/i', '', (string)$input['page_slug']) : null;
    if ($id) {
        $db->prepare('UPDATE articles SET title=?,summary=?,content=?,image=?,link=?,sort=?,enabled=?'
            . ($pageSlug !== null ? ',page_slug=?' : '') . ' WHERE id=?')
           ->execute(array_merge(
               array($title, $summary, $content, $image, $link, $sort, $enabled),
               $pageSlug !== null ? array($pageSlug) : array(),
               array($id)));
    } else {
        $ps = $pageSlug === null ? '' : $pageSlug;
        $db->prepare('INSERT INTO articles(title,summary,content,image,link,sort,enabled,created_at,page_slug) VALUES(?,?,?,?,?,?,?,?,?)')
           ->execute(array($title, $summary, $content, $image, $link, $sort, $enabled, date('Y-m-d H:i:s'), $ps));
        $id = intval($db->lastInsertId());
    }
    znav_seo_build_sitemap();   // 文章变动 → sitemap 同步更新
    znav_json(array('ok' => true, 'id' => $id));
}

/** 公开：取某页面下的文章（用于页面视图只显示本页文章） */
case 'articles_public': {
    $slug = isset($_GET['slug']) ? preg_replace('/[^a-z0-9\-]/i', '', (string)$_GET['slug']) : '';
    if ($slug === '') znav_json(array('ok' => true, 'items' => array()));
    $items = znav_db()->prepare('SELECT id,title,summary,content,image,link,page_slug FROM articles WHERE enabled=1 AND page_slug=? ORDER BY sort,id');
    $items->execute(array($slug));
    $rows = $items->fetchAll();
    foreach ($rows as &$r) { $r['id'] = intval($r['id']); }
    znav_json(array('ok' => true, 'items' => $rows));
}

case 'article_delete': {
    znav_require_admin();
    $db = znav_db();
    // 会员帖子镜像文章：后台删除时同步删除社区帖子
    $st = $db->prepare('SELECT user_id FROM articles WHERE id=?');
    $st->execute(array(intval($input['id'])));
    $row = $st->fetch();
    $db->prepare('DELETE FROM articles WHERE id=?')->execute(array(intval($input['id'])));
    if ($row && intval($row['user_id']) > 0) {
        $db->prepare('DELETE FROM posts WHERE article_id=?')->execute(array(intval($input['id'])));
    }
    znav_json(array('ok' => true));
}

/** 通用批量删除：article_batch / page_batch / ad_batch */
case 'article_batch':
case 'page_batch':
case 'ad_batch': {
    znav_require_admin();
    $table = strpos($action, 'article') === 0 ? 'articles' : (strpos($action, 'page') === 0 ? 'pages' : 'ads');
    $ids = array_values(array_filter(array_map('intval', isset($input['ids']) ? (array)$input['ids'] : array())));
    if (!count($ids)) znav_json(array('error' => '未选择任何项'), 400);
    $db = znav_db();
    $st = $db->prepare('DELETE FROM ' . $table . ' WHERE id=?');
    // 批量删文章时同步清理会员帖子镜像，避免留下孤儿帖子
    $stPost = ($table === 'articles') ? $db->prepare('DELETE FROM posts WHERE article_id=?') : null;
    $n = 0;
    foreach ($ids as $id) {
        $st->execute(array($id));
        $n += $st->rowCount();
        if ($stPost) { try { $stPost->execute(array($id)); } catch (Exception $e) {} }
    }
    znav_json(array('ok' => true, 'affected' => $n));
}

/** 前台拖动网址后保存顺序（按分类内顺序提交 id 数组） */
case 'site_reorder': {
    znav_require_admin();
    $ids = array_values(array_filter(array_map('intval', isset($input['ids']) ? (array)$input['ids'] : array())));
    if (!count($ids)) znav_json(array('error' => 'ids 为空'), 400);
    $db = znav_db();
    $st = $db->prepare('UPDATE sites SET sort=? WHERE id=?');
    foreach ($ids as $i => $id) { $st->execute(array($i + 1, $id)); }
    znav_json(array('ok' => true, 'affected' => count($ids)));
}

/** 分类排序保存（左侧栏 / 首页分区拖动后按顺序提交 id 数组） */
case 'cat_reorder': {
    znav_require_admin();
    $ids = array_values(array_filter(array_map('intval', isset($input['ids']) ? (array)$input['ids'] : array())));
    if (!count($ids)) znav_json(array('error' => 'ids 为空'), 400);
    $db = znav_db();
    // 首次拖动前记录一份「原始分类顺序」快照，供「还原默认布局」使用
    if (znav_setting('catSortBaseline', '') === '') {
        $snap = array();
        foreach ($db->query('SELECT id,sort FROM categories')->fetchAll() as $r) { $snap[intval($r['id'])] = intval($r['sort']); }
        znav_setting_save('catSortBaseline', json_encode($snap));
    }
    $st = $db->prepare('UPDATE categories SET sort=? WHERE id=?');
    foreach ($ids as $i => $id) { $st->execute(array($i + 1, $id)); }
    znav_json(array('ok' => true, 'affected' => count($ids)));
}

/** 一键还原首页默认布局（清空所有拖动产生的顺序 / 位置设置） */
case 'layout_reset': {
    znav_require_admin();
    foreach (array('homeLayout', 'homeSecOrder', 'sideOrder', 'sideClosed', 'sideCollapsed') as $k) {
        znav_setting_save($k, '');
    }
    znav_setting_save('sidebarPos', 'left');
    znav_setting_save('hubBtnPos', 'nav');
    // 分类顺序还原到「首次拖动前」的快照（没有快照则按创建顺序 id 排列）
    $db = znav_db();
    $base = json_decode((string)znav_setting('catSortBaseline', ''), true);
    $st = $db->prepare('UPDATE categories SET sort=? WHERE id=?');
    if (is_array($base) && count($base)) {
        foreach ($base as $id => $sort) { $st->execute(array(intval($sort), intval($id))); }
    } else {
        $i = 1;
        foreach ($db->query('SELECT id FROM categories ORDER BY id ASC')->fetchAll() as $r) { $st->execute(array($i++, intval($r['id']))); }
    }
    znav_setting_save('catSortBaseline', '');
    znav_json(array('ok' => true));
}
case 'article_reorder': {
    znav_require_admin();
    $ids = isset($input['ids']) ? (array)$input['ids'] : array();
    $db = znav_db();
    $st = $db->prepare('UPDATE articles SET sort=? WHERE id=?');
    foreach (array_values($ids) as $i => $id) { $st->execute(array($i + 1, intval($id))); }
    znav_json(array('ok' => true));
}

// ---------- 书签导入（保留二级子分类结构，URL 去重） ----------
case 'import': {
    znav_require_admin();
    $html = isset($input['html']) ? (string)$input['html'] : '';
    if (strlen($html) < 50) znav_json(array('error' => '请提供书签 HTML 内容'), 400);

    // DOM 解析书签树（不依赖缩进，嵌套目录 / 深层子分类都能完整识别）
    $doc = new DOMDocument();
    libxml_use_internal_errors(true);
    $doc->loadHTML('<?xml encoding="UTF-8">' . $html);
    libxml_clear_errors();

    $tree = array(); $seen = array();
    // Netscape 书签文件解析：libxml 会把嵌套 <DL> 解析成 DT 兄弟节点、把未闭合的连续 DT 嵌套成子节点，znav_bm_dl/znav_bm_dt 统一兼容
    $dls = $doc->getElementsByTagName('dl');
    if (!$dls || !$dls->length) znav_json(array('error' => '未识别到书签目录（DL 结构）'), 400);
    znav_bm_dl($dls->item(0), array(), $tree, $seen);

    // 归类：路径里第一层有效名称当主分类，第二层当子分类
    $flat = array();
    foreach ($tree as $key => $items) {
        $path = explode("\x01", $key);
        $clean = array_values(array_filter($path, function ($n) {
            $n = trim($n);
            return $n !== '' && $n !== '收藏夹栏' && $n !== '书签栏' && $n !== 'Bookmarks bar' && $n !== '其他书签';
        }));
        $lv1 = count($clean) > 0 ? $clean[0] : '常用推荐';
        $lv2 = count($clean) > 1 ? $clean[1] : '';
        foreach ($items as $it) $flat[$lv1][$lv2][] = $it;
    }

    $db = znav_db();
    $added = 0; $dup = 0;
    $db->exec('BEGIN');
    try {
        foreach ($flat as $lv1 => $subs) {
            $pid = znav_ensure_cat($lv1, znav_auto_cat_icon($lv1), null);
            foreach ($subs as $lv2 => $items) {
                $target = $lv2 !== '' ? znav_ensure_cat($lv2, znav_auto_cat_icon($lv2), $pid) : $pid;
                foreach ($items as $it) {
                    $st = $db->prepare('SELECT COALESCE(MAX(sort),0)+1 m FROM sites WHERE category_id=?');
                    $st->execute(array($target));
                    $sort = intval($st->fetch()['m']);
                    $host = preg_replace('#^https?://#i', '', $it[1]);
                    $host = explode('/', $host)[0];
                    $ins = $db->prepare('INSERT OR IGNORE INTO sites(category_id,name,url,descr,icon,add_date,sort) VALUES(?,?,?,?,?,?,?)');
                    $ins->execute(array($target, mb_substr($it[0], 0, 100), substr($it[1], 0, 800), $host, $it[2], $it[3], $sort));
                    $ins->rowCount() > 0 ? $added++ : $dup++;
                }
            }
        }
        $db->exec('COMMIT');
    } catch (Exception $e) {
        $db->exec('ROLLBACK');
        znav_json(array('error' => '导入失败：' . $e->getMessage()), 500);
    }
    $totalSites = intval($db->query('SELECT COUNT(*) c FROM sites')->fetch()['c']);
    $totalCats = intval($db->query('SELECT COUNT(*) c FROM categories')->fetch()['c']);
    znav_json(array('ok' => true, 'added' => $added, 'dup' => $dup, 'totalSites' => $totalSites, 'totalCats' => $totalCats));
}

// ---------- 页面（关于/更新日志/排行榜等，后台可增删） ----------
case 'pages_list': {
    $db = znav_db();
    try {
        $items = $db->query('SELECT id,slug,title,content,images,sort,enabled,nav_parent FROM pages ORDER BY sort,id')->fetchAll();
    } catch (Exception $e) {
        $items = $db->query('SELECT id,slug,title,content,images,sort,enabled,"" AS nav_parent FROM pages ORDER BY sort,id')->fetchAll();
    }
    foreach ($items as &$p) { $p['id'] = intval($p['id']); $p['sort'] = intval($p['sort']); $p['enabled'] = intval($p['enabled']); $p['nav_parent'] = trim((string)$p['nav_parent']); }
    znav_json(array('ok' => true, 'items' => $items));
}

case 'page_save': {
    znav_require_admin();
    $db = znav_db();
    $title = mb_substr(trim(isset($input['title']) ? $input['title'] : ''), 0, 30);
    if ($title === '') znav_json(array('error' => '页面标题必填'), 400);
    $slug = strtolower(preg_replace('/[^a-z0-9]+/i', '-', isset($input['slug']) ? (string)$input['slug'] : ''));
    if ($slug === '' || $slug === '-') $slug = 'page-' . time();
    $slug = substr($slug, 0, 30);
    $content = (string)(isset($input['content']) ? $input['content'] : '');
    $images = array_values(array_filter(array_map('trim', explode("\n", (string)(isset($input['images']) ? $input['images'] : '')))));
    $imagesStr = implode("\n", array_slice($images, 0, 12));
    $sort = intval(isset($input['sort']) ? $input['sort'] : 99);
    $enabled = !empty($input['enabled']) ? 1 : 0;
    $navParent = '';
    if (isset($input['nav_parent'])) {
        $np = trim((string)$input['nav_parent']);
        $navParent = preg_match('/^[a-z0-9\-]{1,30}$/', $np) ? $np : '';
    }
    $id = intval(isset($input['id']) ? $input['id'] : 0);
    if ($id) {
        $db->prepare('UPDATE pages SET title=?,slug=?,content=?,images=?,sort=?,enabled=?,nav_parent=? WHERE id=?')
           ->execute(array($title, $slug, mb_substr($content, 0, 50000), $imagesStr, $sort, $enabled, $navParent, $id));
    } else {
        $db->prepare('INSERT INTO pages(title,slug,content,images,sort,enabled,nav_parent) VALUES(?,?,?,?,?,?,?)')
           ->execute(array($title, $slug, mb_substr($content, 0, 50000), $imagesStr, $sort, $enabled, $navParent));
    }
    znav_seo_build_sitemap();   // 页面变动 → sitemap 同步更新
    znav_json(array('ok' => true));
}

case 'page_delete': {
    znav_require_admin();
    znav_db()->prepare('DELETE FROM pages WHERE id=?')->execute(array(intval($input['id'])));
    znav_json(array('ok' => true));
}

// ---------- 友情链接 ----------
case 'friends_list': {
    $items = znav_db()->query('SELECT id,name,url,logo,sort,enabled FROM friends ORDER BY sort,id')->fetchAll();
    foreach ($items as &$f) { $f['id'] = intval($f['id']); $f['sort'] = intval($f['sort']); $f['enabled'] = intval($f['enabled']); }
    znav_json(array('ok' => true, 'items' => $items));
}

case 'friend_save': {
    znav_require_admin();
    $db = znav_db();
    $name = mb_substr(trim(isset($input['name']) ? $input['name'] : ''), 0, 30);
    $url = trim(isset($input['url']) ? $input['url'] : '');
    if ($name === '' || $url === '') znav_json(array('error' => '名称和链接必填'), 400);
    if (!preg_match('#^https?://#i', $url)) $url = 'https://' . $url;
    $logo = mb_substr(trim(isset($input['logo']) ? $input['logo'] : ''), 0, 60000);
    $sort = intval(isset($input['sort']) ? $input['sort'] : 99);
    $enabled = !empty($input['enabled']) ? 1 : 0;
    $id = intval(isset($input['id']) ? $input['id'] : 0);
    if ($id) {
        $db->prepare('UPDATE friends SET name=?,url=?,logo=?,sort=?,enabled=? WHERE id=?')
           ->execute(array($name, substr($url, 0, 500), $logo, $sort, $enabled, $id));
    } else {
        $db->prepare('INSERT INTO friends(name,url,logo,sort,enabled) VALUES(?,?,?,?,?)')
           ->execute(array($name, substr($url, 0, 500), $logo, $sort, $enabled));
    }
    znav_json(array('ok' => true));
}

case 'friend_delete': {
    znav_require_admin();
    znav_db()->prepare('DELETE FROM friends WHERE id=?')->execute(array(intval($input['id'])));
    znav_json(array('ok' => true));
}

// ---------- 聚合页组件块（Link3 风格：轮播 / 视频 / 推广 / 链接 / 贴文 / 二维码） ----------

case 'hub_list': {
    znav_require_admin();
    $db = znav_db();
    $groups = $db->query('SELECT id,name,sort,enabled,show_home FROM hub_groups ORDER BY sort ASC, id ASC')->fetchAll();
    $items = $db->query('SELECT id,gid,type,title,content,sort,enabled,created_at FROM hub_blocks ORDER BY sort ASC, id ASC')->fetchAll();
    znav_json(array('ok' => true, 'groups' => $groups, 'items' => $items));
}

case 'hub_save': {
    znav_require_admin();
    $db = znav_db();
    $type = trim((string)(isset($input['type']) ? $input['type'] : ''));
    if (!in_array($type, znav_hub_types(), true)) znav_json(array('error' => '未知的组件类型'), 400);
    $title = mb_substr(trim((string)(isset($input['title']) ? $input['title'] : '')), 0, 60);
    $content = znav_hub_clean_content($type, isset($input['content']) ? $input['content'] : '');
    $sort = intval(isset($input['sort']) ? $input['sort'] : 99);
    $enabled = !empty($input['enabled']) ? 1 : 0;
    $gid = intval(isset($input['gid']) ? $input['gid'] : 0);
    if ($gid) {
        $g = $db->query('SELECT id FROM hub_groups WHERE id=' . $gid)->fetch();
        if (!$g) $gid = 0;
    }
    $id = intval(isset($input['id']) ? $input['id'] : 0);
    if ($id) {
        $db->prepare('UPDATE hub_blocks SET type=?,title=?,content=?,sort=?,enabled=?,gid=? WHERE id=?')
           ->execute(array($type, $title, $content, $sort, $enabled, $gid, $id));
    } else {
        $db->prepare('INSERT INTO hub_blocks(type,title,content,gid,sort,enabled,created_at) VALUES(?,?,?,?,?,?,?)')
           ->execute(array($type, $title, $content, $gid, $sort, $enabled, date('Y-m-d H:i:s')));
        $id = intval($db->lastInsertId());
    }
    znav_json(array('ok' => true, 'id' => $id));
}

case 'hub_delete': {
    znav_require_admin();
    znav_db()->prepare('DELETE FROM hub_blocks WHERE id=?')->execute(array(intval($input['id'])));
    znav_json(array('ok' => true));
}

case 'hub_reorder': {
    znav_require_admin();
    $db = znav_db();
    $st = $db->prepare('UPDATE hub_blocks SET sort=? WHERE id=?');
    $i = 0;
    foreach (explode(',', (string)(isset($input['ids']) ? $input['ids'] : '')) as $t) {
        $t = intval(trim($t));
        if ($t > 0) { $st->execute(array(++$i, $t)); }
    }
    znav_json(array('ok' => true));
}

/* ---------- 聚合页模块（分组） ---------- */

case 'hub_group_save': {
    znav_require_admin();
    $db = znav_db();
    $name = mb_substr(trim((string)(isset($input['name']) ? $input['name'] : '')), 0, 30);
    $sort = intval(isset($input['sort']) ? $input['sort'] : 99);
    $enabled = !empty($input['enabled']) ? 1 : 0;
    $showHome = !empty($input['show_home']) ? 1 : 0;
    $id = intval(isset($input['id']) ? $input['id'] : 0);
    if ($id) {
        if ($name !== '') {
            $db->prepare('UPDATE hub_groups SET name=?,sort=?,enabled=?,show_home=? WHERE id=?')
               ->execute(array($name, $sort, $enabled, $showHome, $id));
        } else {
            $db->prepare('UPDATE hub_groups SET sort=?,enabled=?,show_home=? WHERE id=?')
               ->execute(array($sort, $enabled, $showHome, $id));
        }
    } else {
        if ($name === '') znav_json(array('error' => '请填写模块名称'), 400);
        $db->prepare('INSERT INTO hub_groups(name,sort,enabled,show_home) VALUES(?,?,?,?)')
           ->execute(array($name, $sort, $enabled, $showHome));
        $id = intval($db->lastInsertId());
    }
    znav_json(array('ok' => true, 'id' => $id));
}

case 'hub_group_delete': {
    znav_require_admin();
    $db = znav_db();
    $id = intval(isset($input['id']) ? $input['id'] : 0);
    // 模块下的组件回到未分组，不丢数据
    $db->prepare('UPDATE hub_blocks SET gid=0 WHERE gid=?')->execute(array($id));
    $db->prepare('DELETE FROM hub_groups WHERE id=?')->execute(array($id));
    znav_json(array('ok' => true));
}

case 'hub_group_reorder': {
    znav_require_admin();
    $db = znav_db();
    $st = $db->prepare('UPDATE hub_groups SET sort=? WHERE id=?');
    $i = 0;
    foreach (explode(',', (string)(isset($input['ids']) ? $input['ids'] : '')) as $t) {
        $t = intval(trim($t));
        if ($t > 0) { $st->execute(array(++$i, $t)); }
    }
    znav_json(array('ok' => true));
}

/** 上传底部二维码（key = qq | weixin | reward | logo | ctqq | ctwx | ctwxqr）
 *  ctqq=QQ 头像 · ctwx=微信头像 · ctwxqr=微信二维码（「联系我」小组件） */
case 'qr_upload': {
    znav_require_admin();
    $key = isset($input['key']) ? $input['key'] : '';
    if (!in_array($key, array('qq', 'weixin', 'reward', 'logo', 'ctqq', 'ctwx', 'ctwxqr', 'deflogo', 'favicon'))) znav_json(array('error' => 'key 必须是 qq / weixin / reward / logo / ctqq / ctwx / ctwxqr / deflogo / favicon'), 400);
    // 网站图标（favicon）单独走 znav_save_favicon，额外支持 SVG / ICO
    if ($key === 'favicon') {
        $path = znav_save_favicon($_FILES['file']['tmp_name'] ?? '', $_FILES['file']['error'] ?? 1, $_FILES['file']['size'] ?? 0, 3);
    } else {
        $path = znav_save_image($_FILES['file']['tmp_name'] ?? '', $_FILES['file']['error'] ?? 1, $_FILES['file']['size'] ?? 0, 3);
    }
    if ($path === '') znav_json(array('error' => '上传失败：仅支持图片 / svg / ico，≤3MB'), 400);
    $map = array('qq' => 'qrQQ', 'weixin' => 'qrWeixin', 'reward' => 'qrReward', 'logo' => 'siteLogo',
                 'ctqq' => 'ctQQAvatar', 'ctwx' => 'ctWxAvatar', 'ctwxqr' => 'ctWxImg', 'deflogo' => 'defaultLogo',
                 'favicon' => 'siteFavicon');
    znav_setting_save($map[$key], $path);
    znav_json(array('ok' => true, 'url' => $path));
}

/** 保存底部「联系我」小组件设置（QQ 号 / 提示语 / 开关） */
case 'contact_save': {
    znav_require_admin();
    if (isset($input['on'])) znav_setting_save('ctOn', (!empty($input['on']) && $input['on'] !== '0') ? '1' : '0');
    if (isset($input['qq']))      znav_setting_save('ctQQ', preg_replace('/\D+/', '', trim((string)$input['qq'])));
    if (isset($input['wxTip']))   znav_setting_save('ctWxTip', mb_substr(trim((string)$input['wxTip']), 0, 40));
    if (isset($input['wxImg'])) {
        $v = trim((string)$input['wxImg']);
        if ($v === '' || preg_match('#^https?://#i', $v) || preg_match('#^/?uploads/[A-Za-z0-9_.\\-/]+$#', $v) || preg_match('#^/?assets/[A-Za-z0-9_.\\-/]+$#', $v)) {
            znav_setting_save('ctWxImg', $v);
        }
    }
    znav_json(array('ok' => true, 'ctQQ' => znav_setting('ctQQ', ''), 'ctWxImg' => znav_setting('ctWxImg', ''), 'ctWxTip' => znav_setting('ctWxTip', '')));
}

case 'qr_clear': {
    znav_require_admin();
    $key = isset($input['key']) ? $input['key'] : '';
    $map = array('qq' => 'qrQQ', 'weixin' => 'qrWeixin', 'reward' => 'qrReward', 'logo' => 'siteLogo',
                 'ctqq' => 'ctQQAvatar', 'ctwx' => 'ctWxAvatar', 'ctwxqr' => 'ctWxImg', 'deflogo' => 'defaultLogo',
                 'favicon' => 'siteFavicon');
    if (isset($map[$key])) {
        znav_setting_save($map[$key], '');
    }
    znav_json(array('ok' => true));
}

// ---------- 访客记录 ----------
case 'visits_list': {
    znav_require_admin();
    $db = znav_db();
    $page = max(1, intval(isset($_GET['page']) ? $_GET['page'] : 1));
    $psRaw = isset($_GET['pageSize']) ? trim((string)$_GET['pageSize']) : '30';
    $size = ($psRaw === 'all' || $psRaw === '0') ? 2000 : min(2000, max(10, intval($psRaw)));
    $today = date('Y-m-d');
    $todayPv = intval($db->query("SELECT COUNT(*) c FROM visits WHERE visited_at LIKE '$today%'")->fetch()['c']);
    $todayUv = intval($db->query("SELECT COUNT(DISTINCT ip) c FROM visits WHERE visited_at LIKE '$today%'")->fetch()['c']);
    $totalPv = intval($db->query('SELECT COUNT(*) c FROM visits')->fetch()['c']);
    // LIMIT/OFFSET 用整数内联：部分主机（MariaDB 服务端预编译）不接受字符串绑定
    $off = ($page - 1) * $size;
    $st = $db->query("SELECT id,vid,ip,ua,page,referer,visited_at,stay,clicks,device FROM visits ORDER BY id DESC LIMIT $size OFFSET $off");
    $items = $st->fetchAll();
    // 地域批量解析（本页去重后最多 30 个，公网 IP 才查，结果缓存）
    $regions = array();
    $uniqIps = array_values(array_unique(array_map(function ($v) { return (string)$v['ip']; }, $items)));
    foreach (array_slice($uniqIps, 0, 30) as $ip) { $regions[$ip] = znav_ip_region($ip); }
    foreach ($items as &$v) {
        $v['id'] = intval($v['id']); $v['stay'] = intval($v['stay']); $v['clicks'] = intval($v['clicks']);
        $v['device'] = znav_device_label($v['device']);
        $v['region'] = isset($regions[$v['ip']]) ? $regions[$v['ip']] : '';
    }
    znav_json(array('ok' => true, 'todayPv' => $todayPv, 'todayUv' => $todayUv, 'totalPv' => $totalPv,
        'page' => $page, 'items' => $items));
}

/** 访客记录批量删除（ids 数组或 all=true 全部清空） */
case 'visit_batch': {
    znav_require_admin();
    $db = znav_db();
    if (!empty($input['all'])) {
        $n = $db->exec('DELETE FROM visits');
        znav_json(array('ok' => true, 'affected' => $n));
    }
    $ids = array();
    foreach ((isset($input['ids']) && is_array($input['ids']) ? $input['ids'] : array()) as $i) {
        $i = intval($i); if ($i > 0) $ids[] = $i;
    }
    if (!$ids) znav_json(array('error' => '未选择记录'), 400);
    $ph = implode(',', array_fill(0, count($ids), '?'));
    $st = $db->prepare("DELETE FROM visits WHERE id IN ($ph)");
    $st->execute($ids);
    znav_json(array('ok' => true, 'affected' => $st->rowCount()));
}

/** 首页按分类分区展示：每个主分类默认显示全部网址（不截断） */
case 'sections': {
    $db = znav_db();
    // 首页每个分区初始展示的网址数量（后台「系统设置」可配 homePerSection，默认 24）；其余点击「展开全部」按需加载
    $homePer = (int)znav_setting('homePerSection', '24');
    if ($homePer < 1) $homePer = 24;
    $secLimit = $homePer;
    $mains = $db->query("SELECT c.id, c.name, c.icon,
        (SELECT COUNT(*) FROM sites s WHERE s.category_id=c.id
           OR s.category_id IN (SELECT id FROM categories c2 WHERE c2.parent_id=c.id)) AS count
        FROM categories c WHERE c.parent_id IS NULL ORDER BY c.sort, c.id")->fetchAll();
    $out = array();
    foreach ($mains as $m) {
        if (intval($m['count']) === 0) continue;
        $id = intval($m['id']);
        $subs = $db->prepare("SELECT id,name,icon,(SELECT COUNT(*) FROM sites s WHERE s.category_id=categories.id) count
            FROM categories WHERE parent_id=? ORDER BY sort,id");
        $subs->execute(array($id));
        $children = array();
        foreach ($subs->fetchAll() as $c) {
            $children[] = array('id' => intval($c['id']), 'name' => $c['name'], 'icon' => $c['icon'], 'count' => intval($c['count']));
        }
        try {
            $st = $db->prepare("SELECT s.id, s.category_id AS categoryId, s.name, s.url, s.descr, s.icon, s.logo,
            CAST(s.user_id AS INTEGER) AS userId,
            CAST(s.clicks AS INTEGER) AS clicks, CAST(s.pinned AS INTEGER) AS pinned,
            c2.name AS categoryName, c2.icon AS categoryIcon
            FROM sites s LEFT JOIN categories c2 ON c2.id=s.category_id
            WHERE s.category_id=? OR s.category_id IN (SELECT id FROM categories c3 WHERE c3.parent_id=?)
            ORDER BY s.pinned DESC, s.sort, s.clicks DESC, s.id LIMIT $homePer");
            $st->execute(array($id, $id));
            $sites = $st->fetchAll();
        } catch (Throwable $e) {
            // 单个分类查询异常时跳过它，保证其它分区照常下发，首页不会整块空白
            $sites = array();
        }
        $out[] = array('id' => $id, 'name' => $m['name'], 'icon' => $m['icon'],
            'count' => intval($m['count']), 'children' => $children, 'sites' => $sites,
            'hasMore' => intval($m['count']) > $homePer);
    }
    znav_json(array('ok' => true, 'sections' => $out, 'perSection' => $secLimit, 'lgv' => znav_logos_ver()));
}

// ---------- SEO 与收录 ----------
/** 保存 SEO 设置（站点地址 / 描述 / 关键词 / 站长验证 / 推送密钥），并自动重建 sitemap 与 robots */
case 'seo_save': {
    znav_require_admin();
    $keys = array(
        'siteUrl' => 200, 'siteSeoDesc' => 300, 'siteSeoKeywords' => 300,
        'seoBaiduVerify' => 100, 'seoGoogleVerify' => 100, 'seoBingVerify' => 100,
        'seoSogouVerify' => 100, 'seoS360Verify' => 100,
        'seoBaiduSite' => 100, 'seoBaiduToken' => 100, 'seoIndexNowKey' => 100,
        'seoRobotsExtra' => 1000, 'hubSeoDesc' => 300,
    );
    foreach ($keys as $k => $max) {
        if (!isset($input[$k])) continue;
        $v = trim((string)$input[$k]);
        if ($k === 'siteUrl' && $v !== '' && !preg_match('#^https?://#i', $v)) $v = 'https://' . ltrim($v, '/');
        if ($k === 'siteUrl') $v = rtrim($v, '/');
        znav_setting_save($k, mb_substr($v, 0, $max));
    }
    $built = znav_seo_rebuild();
    znav_json(array('ok' => true, 'built' => $built, 'siteUrl' => znav_seo_site_url()));
}

/** 立即重建 sitemap.xml / robots.txt */
case 'seo_rebuild': {
    znav_require_admin();
    znav_json(array('ok' => true, 'built' => znav_seo_rebuild(), 'count' => count(znav_seo_urls())));
}

/** 查看当前 sitemap 收录了哪些地址 */
case 'seo_urls': {
    znav_require_admin();
    znav_json(array('ok' => true, 'urls' => znav_seo_urls(), 'siteUrl' => znav_seo_site_url()));
}

/** 主动把网址推给百度 / IndexNow，加快收录 */
case 'seo_push': {
    znav_require_admin();
    if (!function_exists('curl_init')) znav_json(array('error' => '服务器未开启 curl 扩展，无法主动推送'), 500);
    znav_seo_rebuild();
    $r = znav_seo_push(2000);
    znav_json(array('ok' => true, 'result' => $r));
}

// ---------- 背景 / 备份 ----------
case 'bg_preset': {
    znav_require_admin();
    $preset = isset($input['preset']) ? preg_replace('/[^a-z0-9_]/i', '', (string)$input['preset']) : 'aurora';
    znav_setting_save('bgPreset', $preset);
    znav_json(array('ok' => true));
}

/** 上传背景图片（multipart，≤5MB，jpg/png/webp/gif）；最多保留 5 张，超出自动挤掉最早的 */
case 'bg_upload': {
    znav_require_admin();
    if (empty($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
        znav_json(array('error' => '请选择图片文件'), 400);
    }
    $f = $_FILES['file'];
    if ($f['size'] > 5 * 1024 * 1024) znav_json(array('error' => '图片不能超过 5MB'), 400);
    $info = @getimagesize($f['tmp_name']);
    if (!$info) znav_json(array('error' => '不是有效的图片文件'), 400);
    $extMap = array(IMAGETYPE_JPEG => 'jpg', IMAGETYPE_PNG => 'png', IMAGETYPE_WEBP => 'webp', IMAGETYPE_GIF => 'gif');
    if (!isset($extMap[$info[2]])) znav_json(array('error' => '仅支持 jpg / png / webp / gif'), 400);
    $dir = __DIR__ . '/uploads';
    if (!is_dir($dir)) @mkdir($dir, 0777, true);
    $name = 'bg_' . date('YmdHis') . '_' . mt_rand(100, 999) . '.' . $extMap[$info[2]];
    if (!move_uploaded_file($f['tmp_name'], $dir . '/' . $name)) {
        znav_json(array('error' => '保存失败，请检查 uploads 目录写入权限'), 500);
    }
    $list = json_decode(znav_setting('bgImages', '[]'), true);
    if (!is_array($list)) $list = array();
    $list[] = 'uploads/' . $name;
    while (count($list) > 5) { $old = array_shift($list); if (is_file(__DIR__ . '/' . $old)) @unlink(__DIR__ . '/' . $old); }
    znav_setting_save('bgImages', json_encode(array_values($list)));
    znav_setting_save('bgImage', $list[count($list) - 1]);
    znav_json(array('ok' => true, 'url' => 'uploads/' . $name, 'list' => $list));
}

/** 删除某一张背景图（body: {url}） */
case 'bg_delete': {
    znav_require_admin();
    $url = trim(isset($input['url']) ? (string)$input['url'] : '');
    if (!preg_match('#^uploads/[a-z0-9_\-]+\.(jpg|png|webp|gif|jpeg)$#i', $url)) znav_json(array('error' => '路径无效'), 400);
    $list = json_decode(znav_setting('bgImages', '[]'), true);
    if (!is_array($list)) $list = array();
    $list = array_values(array_filter($list, function ($u) use ($url) { return $u !== $url; }));
    if (is_file(__DIR__ . '/' . $url)) @unlink(__DIR__ . '/' . $url);
    znav_setting_save('bgImages', json_encode($list));
    znav_setting_save('bgImage', isset($list[count($list) - 1]) ? $list[count($list) - 1] : '');
    znav_json(array('ok' => true, 'list' => $list));
}

case 'bg_clear': {
    znav_require_admin();
    // 同时删除已上传的背景文件，避免「移除后前台还显示旧图」
    $list = json_decode(znav_setting('bgImages', '[]'), true);
    if (is_array($list)) {
        foreach ($list as $u) {
            if (is_string($u) && preg_match('#^uploads/#', $u) && is_file(__DIR__ . '/' . $u)) @unlink(__DIR__ . '/' . $u);
        }
    }
    $bg = znav_setting('bgImage', '');
    if ($bg && preg_match('#^uploads/#', $bg) && is_file(__DIR__ . '/' . $bg)) @unlink(__DIR__ . '/' . $bg);
    znav_setting_save('bgImages', '[]');
    znav_setting_save('bgImage', '');
    znav_json(array('ok' => true));
}

/** 上传数据库备份并还原（覆盖前自动备份当前库） */
case 'restore': {
    znav_require_admin();
    if (empty($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
        znav_json(array('error' => '请选择备份文件'), 400);
    }
    $f = $_FILES['file'];
    if ($f['size'] > 50 * 1024 * 1024) znav_json(array('error' => '文件过大'), 400);
    $tmp = $f['tmp_name'];

    // MySQL 版：还原 .sql 备份（由本程序导出的结构 + 数据）
    if (ZNAV_DB_DRIVER === 'mysql') {
        $sqlText = (string)file_get_contents($tmp);
        if (stripos($sqlText, 'INSERT INTO') === false) {
            znav_json(array('error' => '不是有效的 SQL 备份文件（MySQL 版请上传 .sql 备份）'), 400);
        }
        $db = znav_db();
        $ok = 0; $bad = 0;
        foreach (preg_split('/;\s*\r?\n/', $sqlText) as $stmt) {
            $stmt = trim($stmt);
            if ($stmt === '' || strpos($stmt, '--') === 0) continue;
            try { $db->exec($stmt); $ok++; } catch (Exception $e) { $bad++; }
        }
        znav_json(array('ok' => true, 'statements' => $ok, 'failed' => $bad));
    }

    // 校验是 SQLite 且包含 sites 表
    if (substr(file_get_contents($tmp, false, null, 0, 16), 0, 6) !== 'SQLite') {
        znav_json(array('error' => '不是有效的 SQLite 数据库文件'), 400);
    }
    try {
        $check = new PDO('sqlite:' . $tmp);
        $check->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $check->query('SELECT COUNT(*) FROM sites');
        $check->query('SELECT COUNT(*) FROM categories');
    } catch (Exception $e) {
        znav_json(array('error' => '备份文件不完整（缺少必要数据表）'), 400);
    }
    // WAL 落盘 → 生成「还原前自动备份」（名字清晰、可直接选它再还原回去）→ 替换
    znav_db()->exec('PRAGMA wal_checkpoint(TRUNCATE)');
    $target = ZNAV_DB;
    $pre = dirname($target) . '/nav.pre-restore-' . date('Ymd-His') . '.db';
    if (is_file($target) && !is_file($pre) && !@copy($target, $pre)) $pre = '';
    $bak = $target . '.bak-' . date('YmdHis');
    if (is_file($target)) rename($target, $bak);
    foreach (array($target . '-wal', $target . '-shm') as $side) {
        if (is_file($side)) @unlink($side);
    }
    if (!copy($tmp, $target)) {
        if (is_file($bak)) rename($bak, $target); // 回滚
        znav_json(array('error' => '还原失败：无法写入数据库文件'), 500);
    }
    znav_json(array(
        'ok' => true,
        'backup' => basename($bak),
        'pre' => $pre ? basename($pre) : '',
        'tip' => '还原前的数据已保存为 nav.pre-restore-*.db，需要退回时选它再还原一次即可',
    ));
}

/** 下载完整数据库备份（SQLite 下载 .db 文件；MySQL 导出 .sql） */
case 'backup': {
    znav_require_admin();
    $db = znav_db();
    if (ZNAV_DB_DRIVER === 'mysql') {
        $out = "-- 趣导 NavVerse MySQL 备份 " . date('Y-m-d H:i:s') . "\n";
        foreach (znav_tables() as $t) {
            $tbl = znav_t($t);
            try { $rows = $db->query('SELECT * FROM `' . $tbl . '`')->fetchAll(); }
            catch (Exception $e) { continue; }
            $out .= "\n-- 表 {$tbl}\nDELETE FROM `{$tbl}`;\n";
            foreach ($rows as $r) {
                $cols = array(); $vals = array();
                foreach ($r as $k => $v) {
                    if (is_int($k)) continue;
                    $cols[] = '`' . $k . '`';
                    $vals[] = ($v === null) ? 'NULL' : $db->quote((string)$v);
                }
                if ($cols) $out .= 'INSERT INTO `' . $tbl . '`(' . implode(',', $cols) . ') VALUES(' . implode(',', $vals) . ");\n";
            }
        }
        header('Content-Type: application/sql; charset=UTF-8');
        header('Content-Disposition: attachment; filename="nav-backup-' . date('Ymd-His') . '.sql"');
        header('Content-Length: ' . strlen($out));
        echo $out;
        exit;
    }
    $file = ZNAV_DB;
    if (!is_file($file)) znav_json(array('error' => '数据库文件不存在'), 404);
    // WAL 落盘，保证备份完整
    $db->exec('PRAGMA wal_checkpoint(TRUNCATE)');
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="nav-backup-' . date('Ymd-His') . '.db"');
    header('Content-Length: ' . filesize($file));
    readfile($file);
    exit;
}

/**
 * 源码更新检查：拉取远端 manifest（navverse-update.json），对比本地版本号。
 * 结果缓存 6 小时（存 settings 表 updateCache），避免每次后台加载都打外部请求。
 * body: { force?:1 } 强制跳过缓存。需要后台登录。
 */
case 'update_check': {
    znav_require_admin();
    $force = !empty($input['force']);
    $now = time();
    $current = defined('ZNAV_VERSION') ? ZNAV_VERSION : '1.0';
    $out = array(
        'ok' => true, 'current' => $current, 'url' => '', 'checkedAt' => $now, 'latest' => '',
        'noAnnouncement' => false,   // true = 暂无公告（开发者未发布 / 地址不可达），静默处理，不报错
    );
    // 命中有效缓存（6 小时内），直接返回，省一次外网请求
    if (!$force) {
        $cached = json_decode(znav_setting('updateCache', ''), true);
        if (is_array($cached) && !empty($cached['checkedAt']) && $now - intval($cached['checkedAt']) < 21600 && isset($cached['latest'])) {
            $cached['cached'] = true;
            znav_json($cached);
        }
    }
    $url = function_exists('znav_update_url') ? znav_update_url() : '';
    $out['url'] = $url;
    if (!$url) {
        // 未配置地址：不报错，当作暂无公告（静默）
        $out['noAnnouncement'] = true;
        $out['disabled'] = true;
        znav_json($out);
    }
    list($body, $final, $httpCode) = znav_http_get($url, 6);
    if ($body === false || $body === '') {
        // 网络失败 / 被 SSRF 拦截 / 超时：开发者可能尚未发布，静默，不吓用户
        $out['noAnnouncement'] = true;
        $out['reachable'] = false;
        znav_setting_save('updateCache', json_encode($out));
        znav_json($out);
    }
    if ($httpCode && $httpCode >= 400) {
        // 404 / 5xx 等：公告文件还不存在（开发者没发），属于正常「暂无公告」，静默
        $out['noAnnouncement'] = true;
        $out['httpCode'] = $httpCode;
        znav_setting_save('updateCache', json_encode($out));
        znav_json($out);
    }
    $j = json_decode($body, true);
    if (!is_array($j) || empty($j['version'])) {
        // HTTP 200 但内容不是合法公告（开发者放错文件）：才提示格式错误
        $out['ok'] = false;
        $out['error'] = '更新公告格式不正确（应为含 version 字段的 JSON）。';
        znav_json($out);
    }
    $latest = (string)$j['version'];
    $out['latest'] = $latest;
    $out['hasUpdate'] = version_compare($latest, $current, '>');
    $out['title'] = isset($j['title']) ? $j['title'] : ('NavVerse ' . $latest);
    $out['date'] = isset($j['date']) ? $j['date'] : '';
    $out['changelog'] = isset($j['changelog']) ? $j['changelog'] : (isset($j['notes']) ? $j['notes'] : '');
    $out['download'] = isset($j['download']) ? $j['download'] : (isset($j['url']) ? $j['url'] : (isset($j['link']) ? $j['link'] : ''));
    $out['doc'] = isset($j['doc']) ? $j['doc'] : (isset($j['url_doc']) ? $j['url_doc'] : '');
    $out['requires'] = isset($j['requires']) ? $j['requires'] : '';
    znav_setting_save('updateCache', json_encode($out));
    znav_json($out);
}

/** 商业授权：查询当前授权状态（域名 / 有效期 / 最近回检 / 剩余宽限天数） */
case 'license_state': {
    znav_require_admin();
    $st = znav_lic_state(false);
    $st['server'] = function_exists('znav_lic_servers') ? implode(',', znav_lic_servers()) : ZNAV_LIC_SERVER;
    $st['graceDays'] = ZNAV_LIC_GRACE_DAYS;
    $st['locked'] = function_exists('znav_lic_locked') ? znav_lic_locked() : false;
    $st['version'] = defined('ZNAV_VERSION') ? ZNAV_VERSION : '1.0';   // 当前源码版本（后台「关于」卡片用）
    // 授权卡片里的「联系方式 / 购买信息」：数据库值优先，否则用 lib/lic_contact.php 的出厂默认
    $st['contact'] = znav_lic_contact();
    znav_json($st);
}

/** 授权卡片联系方式：保存文字信息（自动保存调用，body: {qq,wechat,plans,buy}） */
case 'lic_contact_save': {
    znav_require_admin();
    if (isset($input['qq']))     znav_setting_save('licContactQQ', trim(mb_substr((string)$input['qq'], 0, 40)));
    if (isset($input['wechat'])) znav_setting_save('licContactWechat', trim(mb_substr((string)$input['wechat'], 0, 64)));
    if (isset($input['plans']))  znav_setting_save('licContactPlans', trim(mb_substr((string)$input['plans'], 0, 1000)));
    if (isset($input['buy']))    znav_setting_save('licContactBuy', trim(mb_substr((string)$input['buy'], 0, 1000)));
    // 图片移除：传空串 = 删除该图（含文件）
    foreach (array('pay_img' => 'licContactPayImg', 'wx_img' => 'licContactWxImg') as $k => $skey) {
        if (isset($input[$k]) && trim((string)$input[$k]) === '') {
            $old = znav_setting($skey, '');
            if ($old && preg_match('#^uploads/#', $old) && is_file(__DIR__ . '/' . $old)) @unlink(__DIR__ . '/' . $old);
            znav_setting_save($skey, '');
        }
    }
    znav_json(array('ok' => true, 'contact' => znav_lic_contact()));
}

/** 授权卡片联系方式：上传收款码 / 微信二维码（multipart: file + type=pay|wx） */
case 'lic_contact_upload': {
    znav_require_admin();
    $type = 'wx';   // 收款码已移除，仅支持微信二维码
    if (empty($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
        znav_json(array('error' => '请选择图片文件'), 400);
    }
    $f = $_FILES['file'];
    if ($f['size'] > 5 * 1024 * 1024) znav_json(array('error' => '图片不能超过 5MB'), 400);
    $info = @getimagesize($f['tmp_name']);
    if (!$info) znav_json(array('error' => '不是有效的图片文件'), 400);
    $extMap = array(IMAGETYPE_JPEG => 'jpg', IMAGETYPE_PNG => 'png', IMAGETYPE_WEBP => 'webp', IMAGETYPE_GIF => 'gif');
    if (!isset($extMap[$info[2]])) znav_json(array('error' => '仅支持 jpg / png / webp / gif'), 400);
    $dir = __DIR__ . '/uploads';
    if (!is_dir($dir)) @mkdir($dir, 0777, true);
    $skey = 'licContactWxImg';
    // 换图前删掉旧文件，避免垃圾文件堆积
    $old = znav_setting($skey, '');
    if ($old && preg_match('#^uploads/#', $old) && is_file(__DIR__ . '/' . $old)) @unlink(__DIR__ . '/' . $old);
    $name = 'lic' . $type . '_' . date('YmdHis') . '_' . mt_rand(100, 999) . '.' . $extMap[$info[2]];
    if (!move_uploaded_file($f['tmp_name'], $dir . '/' . $name)) {
        znav_json(array('error' => '保存失败，请检查 uploads 目录写入权限'), 500);
    }
    znav_setting_save($skey, 'uploads/' . $name);
    znav_json(array('ok' => true, 'url' => 'uploads/' . $name, 'contact' => znav_lic_contact()));
}

/** 授权服务器远程下发「立即失效」（公网可达，靠一次性令牌鉴权，不等回检） */
case 'license_kill': {
    $tk = isset($input['tk']) ? trim((string)$input['tk']) : '';
    if (!function_exists('znav_lic_kill')) znav_json(array('error' => 'not supported'), 404);
    $done = znav_lic_kill($tk);
    if (!$done) znav_json(array('ok' => false, 'error' => '令牌不符'), 403);
    znav_json(array('ok' => true, 'msg' => '已失效'));
}

/** 商业授权：用授权码激活（需要能连通授权服务器） */
case 'license_activate': {
    znav_require_admin();
    $key = isset($input['key']) ? trim((string)$input['key']) : '';
    $r = znav_lic_activate($key);
    if (!$r[0]) znav_json(array('error' => $r[1]), 400);
    znav_json(array('ok' => true, 'msg' => $r[1], 'state' => znav_lic_state(false)));
}

/** 商业授权：立即联网回检一次（可验证是否被吊销） */
case 'license_recheck': {
    znav_require_admin();
    $rc = znav_lic_recheck(true);
    if (!$rc[0]) znav_json(array('error' => $rc[1], 'code' => $rc[2]), 400);
    znav_json(array('ok' => true, 'msg' => $rc[1], 'state' => znav_lic_state(false)));
}

/** 商业授权：解除本域名的绑定（换域名前先解绑，之后可在新域名重新激活） */
case 'license_remove': {
    znav_require_admin();
    $r = znav_lic_remove();
    if (!$r[0]) znav_json(array('error' => $r[1]), 400);
    znav_json(array('ok' => true, 'msg' => $r[1], 'state' => znav_lic_state(false)));
}

/** 导出书签（Netscape 格式，与 favorites 导入格式一致） */
case 'export_bookmarks': {
    znav_require_admin();
    $db = znav_db();
    $mains = $db->query('SELECT * FROM categories WHERE parent_id IS NULL ORDER BY sort,id')->fetchAll();
    header('Content-Type: text/html; charset=UTF-8');
    header('Content-Disposition: attachment; filename="bookmarks_' . date('Y_m_d') . '.html"');
    echo "<!DOCTYPE NETSCAPE-Bookmark-file-1>\n<META HTTP-EQUIV=\"Content-Type\" CONTENT=\"text/html; charset=UTF-8\">\n<TITLE>Bookmarks</TITLE>\n<H1>Bookmarks</H1>\n<DL><p>\n";
    echo '    <DT><H3>收藏夹栏</H3>' . "\n    <DL><p>\n";
    foreach ($mains as $m) {
        if ($m['name'] === '未分类') continue;
        echo '        <DT><H3>' . htmlspecialchars($m['name'], ENT_QUOTES) . "</H3>\n        <DL><p>\n";
        $subs = $db->prepare('SELECT * FROM categories WHERE parent_id=? ORDER BY sort,id');
        $subs->execute(array($m['id']));
        foreach ($subs->fetchAll() as $sub) {
            echo '            <DT><H3>' . htmlspecialchars($sub['name'], ENT_QUOTES) . "</H3>\n            <DL><p>\n";
            $st = $db->prepare('SELECT name,url,icon,add_date FROM sites WHERE category_id=?');
            $st->execute(array($sub['id']));
            foreach ($st->fetchAll() as $s) { echo '                <DT><A HREF="' . htmlspecialchars($s['url'], ENT_QUOTES) . '" ADD_DATE="1"' . ($s['icon'] ? ' ICON="' . $s['icon'] . '"' : '') . '>' . htmlspecialchars($s['name'], ENT_QUOTES) . "</A>\n"; }
            echo "            </DL><p>\n";
        }
        $st = $db->prepare('SELECT name,url,icon,add_date FROM sites WHERE category_id=?');
        $st->execute(array($m['id']));
        foreach ($st->fetchAll() as $s) { echo '            <DT><A HREF="' . htmlspecialchars($s['url'], ENT_QUOTES) . '" ADD_DATE="1"' . ($s['icon'] ? ' ICON="' . $s['icon'] . '"' : '') . '>' . htmlspecialchars($s['name'], ENT_QUOTES) . "</A>\n"; }
        echo "        </DL><p>\n";
    }
    echo "    </DL><p>\n</DL><p>\n";
    exit;
}

// ---------- 媒体（网址图片/视频）导出与导入 ----------
// 助手函数 znav_media_bytes / znav_media_ext / znav_media_ref 在 lib/db.php（不能放在 switch 里，否则不会被执行）

/** 列出所有带媒体（图片/视频）的网址与视频块，供导出勾选 */
case 'media_list': {
    znav_require_admin();
    $db = znav_db();
    $sites = array();
    $st = $db->query("SELECT s.id, s.name, s.url, s.logo, s.icon, IFNULL(c.name,'未分类') cat
        FROM sites s LEFT JOIN categories c ON c.id = s.category_id
        WHERE s.logo <> '' OR s.icon <> '' ORDER BY s.id");
    foreach ($st->fetchAll() as $r) {
        $has = array();
        foreach (array('logo', 'icon') as $f) {
            if (znav_media_ref($r[$f])) $has[$f] = (preg_match('#^data:#i', $r[$f]) ? 'inline' : (preg_match('#^/?uploads/#i', $r[$f]) ? 'local' : 'remote'));
        }
        if (!$has) continue;
        $sites[] = array('id' => intval($r['id']), 'name' => $r['name'], 'url' => $r['url'], 'cat' => $r['cat'],
            'logo' => (string)$r['logo'], 'icon' => (string)$r['icon'], 'has' => $has);
    }
    $videos = array();
    try {
        $st = $db->query("SELECT id, title, content FROM hub_blocks WHERE type = 'video' AND enabled = 1 ORDER BY id");
        foreach ($st->fetchAll() as $r) {
            $c = json_decode((string)$r['content'], true);
            if (!is_array($c)) continue;
            $url = trim((string)(isset($c['url']) ? $c['url'] : ''));
            $cover = trim((string)(isset($c['cover']) ? $c['cover'] : ''));
            if (!znav_media_ref($url) && !znav_media_ref($cover)) continue;
            $videos[] = array('id' => intval($r['id']), 'title' => (string)$r['title'], 'url' => $url, 'cover' => $cover);
        }
    } catch (Exception $e) { /* 旧库没有聚合页表时忽略 */ }
    znav_json(array('ok' => true, 'sites' => $sites, 'videos' => $videos));
}

/** 打包导出：body {sites:[id...], videos:[id...]} → zip 下载（manifest.json + media/） */
case 'media_export': {
    znav_require_admin();
    @set_time_limit(600);
    $wantSites = isset($input['sites']) && is_array($input['sites']) ? array_map('intval', $input['sites']) : array();
    $wantVideos = isset($input['videos']) && is_array($input['videos']) ? array_map('intval', $input['videos']) : array();
    if (!$wantSites && !$wantVideos) znav_json(array('error' => '请先勾选要导出的内容'), 400);
    $db = znav_db();
    $warn = array();
    $zipFiles = array();     // 内容 md5 => array('path' => zip 内路径, 'bytes' => 原始字节)（同内容只存一份）
    $zipNameN = 0;
    $addBytes = function ($bytes, $ref) use (&$zipFiles, &$zipNameN) {
        if ($bytes === '' || strlen($bytes) > 80 * 1024 * 1024) return '';
        $key = md5($bytes);
        if (isset($zipFiles[$key])) return $zipFiles[$key]['path'];
        $zipNameN++;
        $name = 'm' . $zipNameN . '_' . substr($key, 0, 8) . '.' . znav_media_ext($bytes, $ref);
        $zipFiles[$key] = array('path' => 'media/' . $name, 'bytes' => $bytes);
        return $zipFiles[$key]['path'];
    };

    $mSites = array();
    if ($wantSites) {
        $in = implode(',', $wantSites);
        $st = $db->query("SELECT s.id, s.name, s.url, s.logo, s.icon, IFNULL(c.name,'未分类') cat, s.descr
            FROM sites s LEFT JOIN categories c ON c.id = s.category_id WHERE s.id IN ($in) ORDER BY s.id");
        foreach ($st->fetchAll() as $r) {
            $item = array('id' => intval($r['id']), 'name' => $r['name'], 'url' => $r['url'], 'cat' => $r['cat'], 'descr' => (string)$r['descr']);
            foreach (array('logo', 'icon') as $f) {
                if (!znav_media_ref($r[$f])) continue;
                $bytes = znav_media_bytes($r[$f], $warn);
                $zpath = $bytes === '' ? '' : $addBytes($bytes, $r[$f]);
                if ($zpath === '') { $warn[] = '网址「' . $r['name'] . '」的' . ($f === 'logo' ? '图标' : '小图标') . '未能打包'; continue; }
                $item[$f] = $zpath;
            }
            if (isset($item['logo']) || isset($item['icon'])) $mSites[] = $item;
        }
    }
    $mVideos = array();
    if ($wantVideos) {
        $in = implode(',', $wantVideos);
        $st = $db->query("SELECT id, title, content FROM hub_blocks WHERE type = 'video' AND id IN ($in)");
        foreach ($st->fetchAll() as $r) {
            $c = json_decode((string)$r['content'], true);
            if (!is_array($c)) continue;
            $item = array('id' => intval($r['id']), 'title' => (string)$r['title'], 'desc' => (string)(isset($c['desc']) ? $c['desc'] : ''));
            foreach (array('url' => 'url', 'cover' => 'cover') as $k => $f) {
                if (!znav_media_ref($c[$k])) continue;
                $bytes = znav_media_bytes($c[$k], $warn);
                $zpath = $bytes === '' ? '' : $addBytes($bytes, $c[$k]);
                if ($zpath !== '') $item[$f] = $zpath;
            }
            if (isset($item['url']) || isset($item['cover'])) $mVideos[] = $item;
        }
    }
    if (!$mSites && !$mVideos) znav_json(array('error' => '勾选的内容里没有可打包的媒体文件' . ($warn ? '：' . implode('；', array_slice($warn, 0, 3)) : '')), 400);

    $tmp = tempnam(sys_get_temp_dir(), 'znvexp');
    $zip = new ZipArchive();
    if ($zip->open($tmp, ZipArchive::OVERWRITE) !== true) znav_json(array('error' => '创建压缩包失败'), 500);
    $zip->addFromString('manifest.json', json_encode(array(
        'version' => 1, 'app' => 'NavVerse', 'exportedAt' => date('c'),
        'sites' => $mSites, 'videos' => $mVideos,
    ), JSON_UNESCAPED_UNICODE));
    foreach ($zipFiles as $f) $zip->addFromString($f['path'], $f['bytes']);
    $zip->close();
    $bytes = file_get_contents($tmp);
    unlink($tmp);
    header('Content-Type: application/zip');
    header('Content-Disposition: attachment; filename="navverse_media_' . date('Ymd_His') . '.zip"');
    header('Content-Length: ' . strlen($bytes));
    header('X-Media-Warn: ' . rawurlencode(mb_substr(implode('；', $warn), 0, 500)));
    echo $bytes;
    exit;
}





/** 导入媒体包（multipart 字段 file=.zip） */
case 'media_import': {
    znav_require_admin();
    @set_time_limit(600);
    if (empty($_FILES['file']) || intval($_FILES['file']['error']) !== UPLOAD_ERR_OK) {
        znav_json(array('error' => znav_upload_error_msg()), 400);
    }
    znav_json(znav_media_import_zip($_FILES['file']['tmp_name'], !empty($input['overwrite'])));
}


/** 扫描服务器上可用的媒体包 zip（供「从服务器导入」直接选择） */
case 'media_scan': {
    znav_require_admin();
    $dirs = array();
    $base = __DIR__ . '/uploads';
    $dirs[] = $base;
    if (defined('ZNAV_DATA_DIR') && is_dir(ZNAV_DATA_DIR)) $dirs[] = rtrim(ZNAV_DATA_DIR, '\\/');
    $dirs[] = __DIR__;
    $out = array();
    foreach ($dirs as $d) {
        if (!is_dir($d)) continue;
        $fh = @opendir($d);
        if (!$fh) continue;
        while (($f = readdir($fh)) !== false) {
            if ($f === '.' || $f === '..') continue;
            if (strtolower(substr($f, -4)) !== '.zip') continue;
            $p = $d . '/' . $f;
            if (!is_file($p)) continue;
            $pr = znav_mi_probe($p);   // 顺带识别类型（媒体包 / 图片包 / 整站源码包），让用户一眼看出哪个能导入
            $out[] = array(
                'path' => fm_rel(str_replace('\\', '/', $p)),
                'name' => $f,
                'size' => filesize($p),
                'mtime' => filemtime($p),
                'valid' => !empty($pr['valid']),
                'kind'  => (string)$pr['kind'],
            );
        }
        closedir($fh);
    }
    usort($out, function ($a, $b) { return $b['mtime'] - $a['mtime']; });
    znav_json(array('ok' => true, 'files' => array_slice($out, 0, 30)));
}

/**
 * 从服务器本地文件导入（不受任何上传大小限制）
 * 支持参数 path=相对站点根路径（如 uploads/媒体包.zip）；
 * 不传则按顺序自动查找 uploads/媒体包.zip、uploads/media_import.zip，以及 uploads 下最新的 zip。
 */
case 'media_import_local': {
    znav_require_admin();
    @set_time_limit(600);
    znav_upload_limit_boost();

    $base    = __DIR__ . '/uploads';
    $explicit = isset($input['path']) ? $input['path'] : '';
    if (is_array($explicit)) $explicit = implode(',', $explicit);   // 防呆：前端误传数组不再变成 "Array"
    $explicit = trim((string)$explicit);
    $found   = '';

    // 收集 uploads 下所有 zip（含类型判别），备用
    $all = array();
    if (is_dir($base)) {
        $fh = @opendir($base);
        if ($fh) {
            while (($f = readdir($fh)) !== false) {
                if (strtolower(substr($f, -4)) !== '.zip') continue;
                $p = $base . '/' . $f;
                if (!is_file($p)) continue;
                $all[] = $p;
            }
            closedir($fh);
        }
    }
    usort($all, function ($a, $b) { return intval(@filemtime($b)) - intval(@filemtime($a)); });

    if ($explicit !== '') {
        $p = fm_path($explicit, true);
        if ($p !== null && is_file($p)) $found = $p;
        // 指定路径不存在 → 静默回退到自动挑选
    }
    if ($found === '') {
        // ① 约定文件名（命中即直接用，不校验内容）
        $cands = array($base . '/媒体包.zip', $base . '/media_import.zip', $base . '/media.zip');
        foreach ($cands as $c) { if (is_file($c)) { $found = $c; break; } }
        // ② 其余 zip：只挑「真正可导入的（含清单 / 纯图片包）」里最新的那个，
        //    避免误选到刚上传的整站源码包（旧逻辑直接拿最新 zip，于是报 manifest 缺失）
        if ($found === '') {
            foreach ($all as $p) {
                if (!empty(znav_mi_probe($p)['valid'])) { $found = $p; break; }
            }
        }
    }

    if ($found === '' || !is_file($found)) {
        // 没有自动命中 → 列出所有 zip 并标注类型，让用户自己选（选错也不会再是干巴巴一句 manifest 缺失）
        $list = array();
        foreach ($all as $p) $list[] = znav_mi_probe($p);
        $bad = 0;
        foreach ($list as $it) { if (empty($it['valid'])) $bad++; }
        znav_json(array(
            'ok' => false,
            'error' => count($list)
                ? 'uploads/ 里没有可导入的包（' . count($list) . ' 个 zip 中有 ' . $bad . ' 个不是媒体包，例如整站源码包）。请把后台「媒体/备份 → 导出」生成的 zip 上传到 uploads/ 后重试，或从下方列表里选一个标注「✅」的。'
                : '在 uploads/ 目录没有找到任何 zip。请先用 FTP / 主机文件管理器把导出的包上传到 uploads/ 目录，或用上面的「选择文件」直接上传。',
            'candidates' => array_slice($list, 0, 30),
        ));
    }
    // 先探测一次，给一个「到底是什么包」的明确提示，而不是让导入跑完才发现不对
    $probe = znav_mi_probe($found);
    if (empty($probe['valid'])) {
        $list = array();
        foreach ($all as $p) $list[] = znav_mi_probe($p);
        znav_json(array(
            'ok' => false,
            'error' => '选中的 ' . $probe['name'] . ' 无法导入（识别为：' . $probe['kind'] . '）。请改用它站后台「媒体/备份 → 导出」生成的包，或从下面列表里挑一个标注「✅」的。',
            'candidates' => array_slice($list, 0, 30),
        ));
    }
    $r = znav_media_import_start($found, !empty($input['overwrite']));
    if (!empty($r['ok'])) $r['source'] = fm_rel(str_replace('\\', '/', $found));
    znav_json($r);
}

/** 导入进度推进：每次处理一批（前端循环调用直到 done=true），大包可实时看到进度、绝不超时中断 */
case 'media_import_step': {
    znav_require_admin();
    @set_time_limit(300);
    $job = trim((string)(isset($input['job']) ? $input['job'] : ''));
    if ($job === '' || !preg_match('/^mi[0-9a-z]+$/i', $job)) znav_json(array('error' => '缺少任务号'), 400);
    znav_json(znav_media_import_step($job, isset($input['batch']) ? intval($input['batch']) : 40));
}

/**
 * 批量任务结果导出为 Excel（.xlsx）。
 * 前端把表头+数据行 POST 过来（rows[0] 为表头），这里用 ZipArchive 打包成真正的 xlsx 下载。
 * 批量任务（更新官网Logo / 扫描死链）的结果窗里都有「导出Excel」按钮。
 */
case 'batch_export': {
    znav_require_admin();
    $title = trim((string)(isset($input['title']) ? $input['title'] : '导出'));
    $title = mb_substr(preg_replace('/[\\\\\\/:*?"<>|]/', '', $title), 0, 40);
    if ($title === '') $title = '导出';
    $rows = isset($input['rows']) && is_array($input['rows']) ? $input['rows'] : array();
    if (!count($rows)) znav_json(array('error' => '没有可导出的数据，请先跑完一轮任务'), 400);
    if (count($rows) > 20000) $rows = array_slice($rows, 0, 20000);

    $colLetter = function ($n) { $s = ''; while ($n > 0) { $m = ($n - 1) % 26; $s = chr(65 + $m) . $s; $n = intval(($n - $m - 1) / 26); } return $s; };
    $esc = function ($s) { return htmlspecialchars((string)$s, ENT_QUOTES | ENT_XML1, 'UTF-8'); };

    $maxCols = 0;
    foreach ($rows as $r) $maxCols = max($maxCols, count($r));
    $maxCols = max(1, $maxCols);

    $xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
         . '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">';
    // 列宽（按列数给个够用的宽度，长网址列可横向滚动）
    $xml .= '<cols>';
    for ($c = 1; $c <= $maxCols; $c++) $xml .= '<col min="' . $c . '" max="' . $c . '" width="' . ($c <= 2 ? 34 : 22) . '" customWidth="1"/>';
    $xml .= '</cols><sheetData>';
    foreach ($rows as $i => $row) {
        $xml .= '<row r="' . ($i + 1) . '">';
        for ($c = 0; $c < $maxCols; $c++) {
            $v = isset($row[$c]) ? $row[$c] : '';
            $ref = $colLetter($c + 1) . ($i + 1);
            $sty = $i === 0 ? ' s="1"' : '';
            if (is_numeric($v) && strlen((string)$v) < 12) {
                $xml .= '<c r="' . $ref . '"' . $sty . '><v>' . ($v + 0) . '</v></c>';
            } else {
                $xml .= '<c r="' . $ref . '" t="inlineStr"' . $sty . '><is><t xml:space="preserve">' . $esc($v) . '</t></is></c>';
            }
        }
        $xml .= '</row>';
    }
    $xml .= '</sheetData></worksheet>';

    $wb = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
        . '<sheets><sheet name="Sheet1" sheetId="1" r:id="rId1"/></sheets></workbook>';
    $wbRels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        . '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>'
        . '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>';
    $rels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        . '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>';
    $ct = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
        . '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
        . '<Default Extension="xml" ContentType="application/xml"/>'
        . '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
        . '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
        . '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>';
    $sty = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
        . '<fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><name val="Calibri"/></font></fonts>'
        . '<fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills>'
        . '<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>'
        . '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
        . '<cellXfs count="2"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/></cellXfs>'
        . '</styleSheet>';

    $tmp = tempnam(sys_get_temp_dir(), 'zxlsx');
    $zip = new ZipArchive();
    if ($zip->open($tmp, ZipArchive::OVERWRITE) !== true) znav_json(array('error' => '创建临时文件失败'), 500);
    $zip->addFromString('[Content_Types].xml', $ct);
    $zip->addFromString('_rels/.rels', $rels);
    $zip->addFromString('xl/workbook.xml', $wb);
    $zip->addFromString('xl/_rels/workbook.xml.rels', $wbRels);
    $zip->addFromString('xl/worksheets/sheet1.xml', $xml);
    $zip->addFromString('xl/styles.xml', $sty);
    $zip->close();

    $fname = 'NavVerse-' . $title . '-' . date('Ymd-His') . '.xlsx';
    while (ob_get_level()) ob_end_clean();
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment; filename="export.xlsx"; filename*=UTF-8\'\'' . rawurlencode($fname));
    header('Content-Length: ' . filesize($tmp));
    header('Cache-Control: no-store');
    readfile($tmp);
    unlink($tmp);
    exit;
}

// ---------- 采集其他网站内容 ----------
case 'collect_fetch': {
    znav_require_admin();
    $url = trim(isset($input['url']) ? (string)$input['url'] : '');
    if (!preg_match('#^https?://#i', $url)) $url = 'https://' . $url;
    $host = parse_url($url, PHP_URL_HOST);
    if (!$host) znav_json(array('error' => '网址无效'), 400);
    $html = '';
    try { list($html, ) = znav_http_get($url, 15); } catch (Exception $e) {}
    if ($html === '') znav_json(array('error' => '无法获取该页面内容（目标站可能禁止访问）'), 400);
    if (!mb_check_encoding($html, 'UTF-8')) $html = mb_convert_encoding($html, 'UTF-8', 'HTML-ENTITIES');
    // 提取标题
    $pageTitle = '';
    if (preg_match('/<title[^>]*>([^<]*)<\/title>/i', $html, $tm)) $pageTitle = trim(html_entity_decode($tm[1], ENT_QUOTES, 'UTF-8'));
    // 提取链接（同域优先 + 有文字的；相对路径按页面地址补全）
    $base = parse_url($url);
    $root = ($base['scheme'] ?? 'https') . '://' . ($base['host'] ?? '');
    $links = array(); $seen = array();
    if (preg_match_all('/<a\s[^>]*href=(["\'])([^"\']+)\1[^>]*>(.*?)<\/a>/is', $html, $ms, PREG_SET_ORDER)) {
        foreach ($ms as $m) {
            $href = trim(html_entity_decode($m[2], ENT_QUOTES, 'UTF-8'));
            if ($href === '' || $href[0] === '#' || preg_match('/^(javascript|mailto):/i', $href)) continue;
            if (!preg_match('#^https?://#i', $href)) {
                if ($href[0] === '/') $href = $root . $href;
                else $href = $root . '/' . ltrim($href);
            }
            $text = trim(preg_replace('/\s+/', ' ', strip_tags($m[3])));
            if ($text === '' || mb_strlen($text) < 2 || isset($seen[$href])) continue;
            if (preg_match('/\.(jpg|png|gif|css|js|ico|svg)(\?|$)/i', $href)) continue;
            $seen[$href] = 1;
            $lhost = parse_url($href, PHP_URL_HOST);
            $links[] = array('title' => mb_substr($text, 0, 60), 'url' => mb_substr($href, 0, 500), 'host' => $lhost ?: '', 'same' => $lhost === $host ? 1 : 0);
            if (count($links) >= 200) break;
        }
    }
    // 同域的排前面
    usort($links, function ($a, $b) { return $b['same'] - $a['same']; });
    // 标记「已在网址库」的链接，方便一眼看出哪些是重复项（比较时忽略末尾斜杠）
    $have = array();
    try {
        foreach (znav_db()->query('SELECT url FROM sites')->fetchAll() as $r) {
            $have[rtrim((string)$r['url'], '/')] = 1;
        }
    } catch (Exception $e) { /* ignore */ }
    $existCount = 0;
    foreach ($links as &$l) {
        $l['exists'] = isset($have[rtrim($l['url'], '/')]) ? 1 : 0;
        if ($l['exists']) $existCount++;
    }
    unset($l);
    znav_json(array('ok' => true, 'pageTitle' => mb_substr($pageTitle, 0, 60), 'total' => count($links),
        'existCount' => $existCount, 'sameCount' => count(array_filter($links, function ($x) { return $x['same']; })),
        'items' => $links));
}

/** 采集二级页面：进入勾选的一级链接抓取其页面内的链接（更深层内容） */
case 'collect_deep': {
    znav_require_admin();
    $urls = isset($input['urls']) && is_array($input['urls']) ? array_slice($input['urls'], 0, 20) : array();
    if (!$urls) znav_json(array('error' => '请先勾选一级链接'), 400);
    $out = array();
    foreach ($urls as $u) {
        $u = trim((string)$u);
        if (!preg_match('#^https?://#i', $u)) continue;
        $html = '';
        try { list($html, ) = znav_http_get($u, 10); } catch (Exception $e) {}
        if ($html === '') continue;
        if (!mb_check_encoding($html, 'UTF-8')) $html = mb_convert_encoding($html, 'UTF-8', 'HTML-ENTITIES');

        // ---------- 标题 ----------
        $t = '';
        if (preg_match('/<title[^>]*>([^<]*)<\/title>/i', $html, $tm)) $t = trim(html_entity_decode($tm[1], ENT_QUOTES, 'UTF-8'));

        // ---------- 提取正文区域（去掉脚本/样式/导航等干扰） ----------
        $clean = preg_replace('#<(script|style|noscript|iframe|svg|form|nav|header|footer|aside)[^>]*>.*?</\1>#is', ' ', $html);
        // 优先 <article> / <main>，否则整页
        $bodySrc = $clean;
        if (preg_match('#<(article|main)[^>]*>(.*?)</\1>#is', $clean, $am)) $bodySrc = $am[2];

        // ---------- 段落正文：收集所有块级文本 ----------
        $paras = array();
        if (preg_match_all('#<(?:p|h[1-6]|li|blockquote|pre|div)[^>]*>(.*?)</(?:p|h[1-6]|li|blockquote|pre|div)>#is', $bodySrc, $pm)) {
            foreach ($pm[1] as $seg) {
                $txt = trim(preg_replace('/\s+/u', ' ', html_entity_decode(strip_tags($seg), ENT_QUOTES, 'UTF-8')));
                // 过滤太短/疑似菜单的片段
                if (mb_strlen($txt) < 12) continue;
                if (preg_match('/[\x{4e00}-\x{9fa5}a-zA-Z]/u', $txt) === false) continue;
                if (preg_match('/(版权所有|©|ICP备|登录|注册|首页|上一篇|下一篇|相关阅读|扫码|关注我们)/u', $txt)) continue;
                $paras[] = $txt;
                if (count($paras) >= 60) break;
            }
        }
        // 去重相邻重复段
        $unique = array();
        foreach ($paras as $pa) { if (!in_array($pa, $unique, true)) $unique[] = $pa; }
        $content = implode("\n\n", array_slice($unique, 0, 40));
        if (mb_strlen($content) > 6000) $content = mb_substr($content, 0, 6000) . '…';
        $summary = mb_substr(preg_replace('/\s+/u', ' ', $content), 0, 160);

        $base = parse_url($u);
        $root = ($base['scheme'] ?? 'https') . '://' . ($base['host'] ?? '');
        $items = array();
        if (preg_match_all('/<a\s[^>]*href=(["\'])([^"\']+)\1[^>]*>(.*?)<\/a>/is', $html, $ms, PREG_SET_ORDER)) {
            foreach ($ms as $m) {
                $href = trim(html_entity_decode($m[2], ENT_QUOTES, 'UTF-8'));
                if ($href === '' || $href[0] === '#' || preg_match('/^(javascript|mailto):/i', $href)) continue;
                if (!preg_match('#^https?://#i', $href)) {
                    $href = $href[0] === '/' ? $root . $href : $root . '/' . ltrim($href, './');
                }
                $text = trim(preg_replace('/\s+/', ' ', strip_tags($m[3])));
                if (mb_strlen($text) < 4) continue;
                if (preg_match('/\.(jpg|png|gif|css|js|ico|svg|zip|rar)(\?|$)/i', $href)) continue;
                $items[] = array('title' => mb_substr($text, 0, 60), 'url' => mb_substr($href, 0, 500),
                    'host' => parse_url($href, PHP_URL_HOST) ?: '', 'same' => 1);
                if (count($items) >= 40) break;
            }
        }
        $out[] = array('url' => $u, 'title' => mb_substr($t, 0, 60),
            'summary' => $summary, 'content' => $content, 'items' => $items);
    }
    znav_json(array('ok' => true, 'pages' => $out));
}

/** 采集成文章（把页面标题/摘要/正文存进文章表） */
case 'collect_article': {
    znav_require_admin();
    $pages = isset($input['pages']) && is_array($input['pages']) ? array_slice($input['pages'], 0, 20) : array();
    if (!$pages) znav_json(array('error' => '没有可采集的文章'), 400);
    $db = znav_db();
    $max = intval($db->query('SELECT COALESCE(MAX(sort),0) m FROM articles')->fetch()['m']);
    $added = 0;
    foreach ($pages as $p) {
        $title = mb_substr(trim((string)(isset($p['title']) ? $p['title'] : '')), 0, 80);
        if ($title === '') continue;
        $db->prepare('INSERT INTO articles(title,summary,content,image,link,sort,enabled,created_at) VALUES(?,?,?,?,?,?,1,?)')
           ->execute(array($title, mb_substr((string)(isset($p['summary']) ? $p['summary'] : ''), 0, 200),
               mb_substr((string)(isset($p['content']) ? $p['content'] : ''), 0, 30000), '',
               substr((string)(isset($p['url']) ? $p['url'] : ''), 0, 500),
               ++$max, date('Y-m-d H:i:s')));
        $added++;
    }
    znav_json(array('ok' => true, 'added' => $added));
}

// ---------- 分类导入导出 ----------
case 'cats_export': {
    znav_require_admin();
    $db = znav_db();
    $out = array();
    $mains = $db->query('SELECT * FROM categories WHERE parent_id IS NULL ORDER BY sort,id')->fetchAll();
    foreach ($mains as $m) {
        $node = array('name' => $m['name'], 'icon' => $m['icon'], 'children' => array());
        $subs = $db->prepare('SELECT * FROM categories WHERE parent_id=? ORDER BY sort,id');
        $subs->execute(array($m['id']));
        foreach ($subs->fetchAll() as $sub) {
            $node['children'][] = array('name' => $sub['name'], 'icon' => $sub['icon']);
        }
        $out[] = $node;
    }
    znav_json(array('ok' => true, 'categories' => $out));
}

case 'cats_import': {
    znav_require_admin();
    $cats = isset($input['categories']) && is_array($input['categories']) ? $input['categories'] : array();
    if (!$cats) znav_json(array('error' => '没有可导入的分类'), 400);
    $db = znav_db();
    $added = 0; $skip = 0;
    $findMain = $db->prepare('SELECT id FROM categories WHERE name=? AND parent_id IS NULL');
    $findSub = $db->prepare('SELECT id FROM categories WHERE name=? AND parent_id=?');
    $maxSort = intval($db->query('SELECT COALESCE(MAX(sort),0) m FROM categories')->fetch()['m']);
    foreach ($cats as $c) {
        $name = mb_substr(trim((string)(isset($c['name']) ? $c['name'] : '')), 0, 20);
        if ($name === '') continue;
        $findMain->execute(array($name));
        $row = $findMain->fetch();
        if ($row) { $pid = intval($row['id']); $skip++; }
        else {
            $db->prepare('INSERT INTO categories(name,icon,parent_id,sort) VALUES(?,?,NULL,?)')
               ->execute(array($name, trim((string)(isset($c['icon']) ? $c['icon'] : '')) ?: '📁', ++$maxSort));
            $pid = intval($db->lastInsertId()); $added++;
        }
        foreach ((isset($c['children']) && is_array($c['children']) ? $c['children'] : array()) as $sc) {
            $sn = mb_substr(trim((string)(isset($sc['name']) ? $sc['name'] : '')), 0, 20);
            if ($sn === '') continue;
            $findSub->execute(array($sn, $pid));
            if ($findSub->fetch()) { $skip++; continue; }
            $db->prepare('INSERT INTO categories(name,icon,parent_id,sort) VALUES(?,?,?,?)')
               ->execute(array($sn, trim((string)(isset($sc['icon']) ? $sc['icon'] : '')) ?: '📁', $pid, ++$maxSort));
            $added++;
        }
    }
    znav_json(array('ok' => true, 'added' => $added, 'skip' => $skip));
}

case 'collect_add': {
    znav_require_admin();
    $catId = intval(isset($input['category_id']) ? $input['category_id'] : 0);
    $items = isset($input['items']) && is_array($input['items']) ? $input['items'] : array();
    if (!$catId || !$items) znav_json(array('error' => '请选择分类和要采集的链接'), 400);
    $db = znav_db();
    $added = 0; $dup = 0; $ids = array();
    $st = $db->prepare('SELECT COALESCE(MAX(sort),0)+1 m FROM sites WHERE category_id=?');
    $exists = $db->prepare('SELECT COUNT(*) c FROM sites WHERE url=?');
    foreach ($items as $i => $it) {
        $url = substr(trim((string)$it['url']), 0, 800);
        $name = mb_substr(trim((string)$it['title']), 0, 100);
        if ($url === '' || $name === '') continue;
        $exists->execute(array($url));
        if (intval($exists->fetch()['c']) > 0) { $dup++; continue; }
        $st->execute(array($catId));
        $sort = intval($st->fetch()['m']);
        $db->prepare('INSERT INTO sites(category_id,name,url,descr,icon,add_date,sort) VALUES(?,?,?,?,?,?,?)')
           ->execute(array($catId, $name, $url, parse_url($url, PHP_URL_HOST) ?: '', '', date('Y-m-d H:i:s'), $sort));
        $ids[] = intval($db->lastInsertId());
        $added++;
    }
    znav_json(array('ok' => true, 'added' => $added, 'dup' => $dup, 'ids' => $ids));
}

/** 按 id 批量补图标（每次最多 10 个，前端循环调用直到 remain=0） */
case 'logo_fill_ids': {
    znav_require_admin();
    $ids = array_values(array_filter(array_map('intval', isset($input['ids']) ? (array)$input['ids'] : array())));
    if (!$ids) znav_json(array('error' => '未指定网址'), 400);
    $ids = array_slice($ids, 0, 10);
    $db = znav_db();
    $done = 0;
    foreach ($ids as $id) {
        $st = $db->prepare("SELECT id,url FROM sites WHERE id=? AND (logo IS NULL OR logo='') AND icon=''");
        $st->execute(array($id));
        $row = $st->fetch();
        if (!$row) continue;
        $logo = '';
        try { $logo = znav_logo_fit(znav_fetch_logo($row["url"])); } catch (Exception $e) {}
        $db->prepare('UPDATE sites SET logo=? WHERE id=?')->execute(array($logo, $row['id']));
        $done++;
    }
    znav_json(array('ok' => true, 'done' => $done));
}

// ---------- 通用内容编辑（可选择发布到任意页面 / 网址） ----------
case 'content_list': {
    znav_require_admin();
    $items = znav_db()->query("SELECT * FROM contents ORDER BY sort,id")->fetchAll();
    foreach ($items as &$c) { $c['id'] = intval($c['id']); $c['sort'] = intval($c['sort']); $c['enabled'] = intval($c['enabled']); }
    znav_json(array('ok' => true, 'items' => $items));
}

case 'content_save': {
    znav_require_admin();
    $db = znav_db();
    $title = mb_substr(trim(isset($input['title']) ? (string)$input['title'] : ''), 0, 120);
    if ($title === '') znav_json(array('error' => '标题必填'), 400);
    $image = substr(trim(isset($input['image']) ? (string)$input['image'] : ''), 0, 500);
    $content = mb_substr((string)(isset($input['content']) ? $input['content'] : ''), 0, 50000);
    $link = substr(trim(isset($input['link']) ? (string)$input['link'] : ''), 0, 500);
    $sort = isset($input['sort']) ? intval($input['sort']) : 99;
    $enabled = isset($input['enabled']) && !$input['enabled'] ? 0 : 1;
    $target = substr(trim(isset($input['target']) ? (string)$input['target'] : 'any'), 0, 120);
    $id = intval(isset($input['id']) ? $input['id'] : 0);
    if ($id) {
        $db->prepare('UPDATE contents SET title=?,image=?,content=?,link=?,target=?,sort=?,enabled=? WHERE id=?')
           ->execute(array($title, $image, $content, $link, $target, $sort, $enabled, $id));
    } else {
        $db->prepare('INSERT INTO contents(title,image,content,link,target,sort,enabled,created_at) VALUES(?,?,?,?,?,?,?,?)')
           ->execute(array($title, $image, $content, $link, $target, $sort, $enabled, date('Y-m-d H:i:s')));
    }
    znav_json(array('ok' => true));
}

case 'content_delete': {
    znav_require_admin();
    znav_db()->prepare('DELETE FROM contents WHERE id=?')->execute(array(intval($input['id'])));
    znav_json(array('ok' => true));
}

case 'content_reorder': {
    znav_require_admin();
    $ids = isset($input['ids']) ? (array)$input['ids'] : array();
    $db = znav_db();
    $st = $db->prepare('UPDATE contents SET sort=? WHERE id=?');
    foreach (array_values($ids) as $i => $id) { $st->execute(array($i + 1, intval($id))); }
    znav_json(array('ok' => true));
}

/** 前台取内容：target=any(所有页面) 或 页面 slug */
case 'contents_public': {
    $target = isset($_GET['target']) ? substr(trim((string)$_GET['target']), 0, 120) : '';
    $rows = znav_db()->query("SELECT id,title,image,content,link,target FROM contents WHERE enabled=1 ORDER BY sort,id")->fetchAll();
    $out = array();
    foreach ($rows as $r) {
        if ($r['target'] === 'any' || $r['target'] === $target) { $r['id'] = intval($r['id']); $out[] = $r; }
    }
    znav_json(array('ok' => true, 'items' => $out));
}

// ---------- 聊天室（前台右下角悬浮窗） ----------
/** 公开：拉取聊天记录（limit 默认 200，idAfter 增量拉取） */
case 'chat_list': {
    $db = znav_db();
    $ip = znav_client_ip();
    $who = znav_chat_who();
    $limit = min(500, max(1, intval(isset($_GET['limit']) ? $_GET['limit'] : 300)));
    // 取「最近 N 条」而非「最早 N 条」：按 id 倒序截取后再正序返回（limit 已 intval，整数内联兼容服务端预编译主机）
    $st = $db->query("SELECT id,name,text,img,ip,who,created_at FROM chats ORDER BY id DESC LIMIT $limit");
    $items = array_reverse($st->fetchAll());
    foreach ($items as &$c) {
        $c['id'] = intval($c['id']);
        $w = isset($c['who']) ? (string)$c['who'] : '';
        // 自己发的：身份一致；旧数据没身份列时退回按 IP 判断
        $c['mine'] = ($w !== '' && $w === $who) || ($w === '' && $ip !== '' && $c['ip'] === $ip) ? 1 : 0;
        unset($c['ip'], $c['who']);                       // 不把 IP / 指纹下发到前端
        if (mb_strlen((string)$c['img']) > 8) $c['hasImg'] = 1;
    }
    unset($c);
    // 本访客的昵称（没有则为空，前端提示取名）
    $nm = '';
    $q = $db->prepare('SELECT name FROM chat_names WHERE who=?');
    $q->execute(array($who));
    $row = $q->fetch();
    if ($row) $nm = (string)$row['name'];
    znav_json(array('ok' => true, 'items' => $items, 'myName' => $nm));
}

/** 公开：设置/修改本 IP 的聊天昵称（每个来访 IP 各自独立） */
case 'chat_setname': {
    $who = znav_chat_who();
    $ip = znav_client_ip();
    $name = mb_substr(trim(isset($input['name']) ? (string)$input['name'] : ''), 0, 20);
    if ($name === '') znav_json(array('error' => '昵称不能为空'), 400);
    znav_db()->prepare('INSERT OR REPLACE INTO chat_names(who,name,ip,updated_at) VALUES(?,?,?,?)')
             ->execute(array($who, $name, $ip, date('Y-m-d H:i:s')));
    znav_json(array('ok' => true, 'name' => $name));
}

/** 公开：发送消息（必须先取昵称；文字 ≤500 字 或 图片 dataURI ≤100KB，二者至少其一） */
case 'chat_send': {
    $name = mb_substr(trim(isset($input['name']) ? (string)$input['name'] : ''), 0, 20);
    $text = mb_substr(trim(isset($input['text']) ? (string)$input['text'] : ''), 0, 500);
    $img = trim(isset($input['img']) ? (string)$input['img'] : '');
    if ($name === '') znav_json(array('error' => '请先取一个昵称'), 400);
    if ($text === '' && $img === '') znav_json(array('error' => '说点什么再发送吧'), 400);
    if ($img !== '') {
        if (!preg_match('#^data:image/(png|jpe?g|gif|webp);base64,#i', $img)) znav_json(array('error' => '仅支持图片'), 400);
        if (strlen($img) > 140 * 1024) znav_json(array('error' => '图片超过 100KB，请压缩后再发'), 400);
    }
    // 聊天频率限制：同 IP 每 10 秒最多 3 条
    $ip = znav_client_ip();
    $db = znav_db();
    $st = $db->prepare("SELECT COUNT(*) c FROM chats WHERE ip=? AND created_at > ?");
    $st->execute(array($ip, date('Y-m-d H:i:s', time() - 10)));
    if (intval($st->fetch()['c']) >= 3) znav_json(array('error' => '发送太频繁，稍等几秒'), 429);
    $db->prepare('INSERT INTO chats(name,text,img,ip,who,created_at) VALUES(?,?,?,?,?,?)')
       ->execute(array($name, $text, $img, $ip, znav_chat_who(), date('Y-m-d H:i:s')));
    $id = intval($db->lastInsertId());
    // 记住「这个访客用的昵称」；不同 IP / 不同浏览器各自独立
    $db->prepare('INSERT OR REPLACE INTO chat_names(who,name,ip,updated_at) VALUES(?,?,?,?)')
       ->execute(array(znav_chat_who(), $name, $ip, date('Y-m-d H:i:s')));
    znav_json(array('ok' => true, 'id' => $id, 'created_at' => date('Y-m-d H:i:s')));
}

/** 后台：手动添加一条聊天记录 */
case 'chat_add': {
    znav_require_admin();
    $name = mb_substr(trim(isset($input['name']) ? (string)$input['name'] : '管理员'), 0, 20);
    $text = mb_substr(trim(isset($input['text']) ? (string)$input['text'] : ''), 0, 500);
    if ($text === '') znav_json(array('error' => '内容不能为空'), 400);
    $db = znav_db();
    $db->prepare('INSERT INTO chats(name,text,img,ip,created_at) VALUES(?,?,?,?,?)')
       ->execute(array($name, $text, '', '管理员', date('Y-m-d H:i:s')));
    znav_json(array('ok' => true, 'id' => intval($db->lastInsertId())));
}

/** 后台：删除聊天记录（ids 数组 或 all=true 清空） */
case 'chat_delete': {
    znav_require_admin();
    $db = znav_db();
    if (!empty($input['all'])) {
        $n = $db->exec('DELETE FROM chats');
        znav_json(array('ok' => true, 'affected' => $n));
    }
    $ids = array_values(array_filter(array_map('intval', (array)(isset($input['ids']) ? $input['ids'] : array()))));
    if (!$ids) znav_json(array('error' => '未选择记录'), 400);
    $ph = implode(',', array_fill(0, count($ids), '?'));
    $st = $db->prepare("DELETE FROM chats WHERE id IN ($ph)");
    $st->execute($ids);
    znav_json(array('ok' => true, 'affected' => $st->rowCount()));
}

/** 后台：聊天记录列表（分页） */
case 'chat_admin_list': {
    znav_require_admin();
    $db = znav_db();
    $page = max(1, intval(isset($_GET['page']) ? $_GET['page'] : 1));
    $size = min(200, max(10, intval(isset($_GET['pageSize']) ? $_GET['pageSize'] : 50)));
    $total = intval($db->query('SELECT COUNT(*) c FROM chats')->fetch()['c']);
    // LIMIT/OFFSET 整数内联（部分主机 MariaDB 服务端预编译不支持字符串绑定的分页参数）；
    // img 判断用单引号空串，避免 ANSI_QUOTES 模式把双引号当标识符
    $off = ($page - 1) * $size;
    $st = $db->query("SELECT id,name,text,ip,created_at, CASE WHEN img <> '' THEN 1 ELSE 0 END AS hasImg FROM chats ORDER BY id DESC LIMIT $size OFFSET $off");
    $items = $st->fetchAll();
    foreach ($items as &$c) { $c['id'] = intval($c['id']); $c['hasImg'] = intval($c['hasImg']); }
    znav_json(array('ok' => true, 'total' => $total, 'page' => $page, 'items' => $items));
}

// ---------- 下载页（软件 / App） ----------
case 'downloads_list': {
    $items = znav_db()->query('SELECT id,name,descr,icon,image,url,ver,fsize,sort,enabled FROM downloads WHERE enabled=1 ORDER BY sort,id')->fetchAll();
    foreach ($items as &$d) { $d['id'] = intval($d['id']); $d['sort'] = intval($d['sort']); $d['enabled'] = intval($d['enabled']); }
    znav_json(array('ok' => true, 'items' => $items));
}

case 'downloads_admin_list': {
    znav_require_admin();
    $items = znav_db()->query('SELECT id,name,descr,icon,image,url,ver,fsize,sort,enabled FROM downloads ORDER BY sort,id')->fetchAll();
    foreach ($items as &$d) { $d['id'] = intval($d['id']); $d['sort'] = intval($d['sort']); $d['enabled'] = intval($d['enabled']); }
    znav_json(array('ok' => true, 'items' => $items));
}

case 'download_save': {
    znav_require_admin();
    $db = znav_db();
    $name = mb_substr(trim(isset($input['name']) ? (string)$input['name'] : ''), 0, 60);
    if ($name === '') znav_json(array('error' => '名称必填'), 400);
    $descr = mb_substr(trim(isset($input['descr']) ? (string)$input['descr'] : ''), 0, 500);
    $icon = substr(trim(isset($input['icon']) ? (string)$input['icon'] : ''), 0, 500);
    $image = substr(trim(isset($input['image']) ? (string)$input['image'] : ''), 0, 500);
    $url = substr(trim(isset($input['url']) ? (string)$input['url'] : ''), 0, 800);
    $ver = mb_substr(trim(isset($input['ver']) ? (string)$input['ver'] : ''), 0, 40);
    $fsize = mb_substr(trim(isset($input['fsize']) ? (string)$input['fsize'] : ''), 0, 30);
    $sort = intval(isset($input['sort']) ? $input['sort'] : 99);
    $enabled = isset($input['enabled']) && !$input['enabled'] ? 0 : 1;
    $id = intval(isset($input['id']) ? $input['id'] : 0);
    if ($id) {
        $db->prepare('UPDATE downloads SET name=?,descr=?,icon=?,image=?,url=?,ver=?,fsize=?,sort=?,enabled=? WHERE id=?')
           ->execute(array($name, $descr, $icon, $image, $url, $ver, $fsize, $sort, $enabled, $id));
    } else {
        $db->prepare('INSERT INTO downloads(name,descr,icon,image,url,ver,fsize,sort,enabled,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)')
           ->execute(array($name, $descr, $icon, $image, $url, $ver, $fsize, $sort, $enabled, date('Y-m-d H:i:s')));
    }
    znav_json(array('ok' => true));
}

case 'download_delete': {
    znav_require_admin();
    znav_db()->prepare('DELETE FROM downloads WHERE id=?')->execute(array(intval($input['id'])));
    znav_json(array('ok' => true));
}

case 'download_reorder': {
    znav_require_admin();
    $ids = isset($input['ids']) ? (array)$input['ids'] : array();
    $db = znav_db();
    $st = $db->prepare('UPDATE downloads SET sort=? WHERE id=?');
    foreach (array_values($ids) as $i => $id) { $st->execute(array($i + 1, intval($id))); }
    znav_json(array('ok' => true));
}


case 'fm_list': {
    znav_require_admin();
    $dir = fm_path(isset($input['path']) ? $input['path'] : '');
    if ($dir === null || !is_dir($dir)) znav_json(array('error' => '目录不存在或无权访问（文件根：' . ZNAV_FM_ROOT . '）'), 400);
    $raw = @scandir($dir);
    if ($raw === false) {
        $eb = error_get_last();
        znav_json(array('error' => '目录列表失败：scandir 返回 false。很可能是 PHP 的 open_basedir 限制了「' . $dir . '」（当前 open_basedir=' . (ini_get('open_basedir') ?: '未设置') . '）。'
            . ($eb && !empty($eb['message']) ? ' PHP错误：' . $eb['message'] : '')
            . ' 请在服务器 php.ini 放开该目录或调整 ZNAV_FM_ROOT。'), 500);
    }
    $items = array();
    foreach ($raw as $name) {
        if ($name === '.' || $name === '..') continue;
        if ($name[0] === '.' && $name !== '.user.ini' && $name !== '.htaccess') continue;   // 隐藏系统文件
        $p = $dir . '/' . $name;
        $isDir = is_dir($p);
        $items[] = array(
            'name' => $name,
            'dir' => $isDir,
            'size' => $isDir ? ($name === 'uploads' || strpos(fm_rel($dir), 'uploads') === 0 ? fm_dir_size($p) : 0) : filesize($p),
            'mtime' => filemtime($p),
            'writable' => is_writable($p),
        );
    }
    usort($items, function ($a, $b) {
        if ($a['dir'] !== $b['dir']) return $a['dir'] ? -1 : 1;
        return strcasecmp($a['name'], $b['name']);
    });
    $out = array('ok' => true, 'path' => fm_rel($dir), 'root' => basename(str_replace('\\', '/', ZNAV_FM_ROOT)), 'rootFull' => str_replace('\\', '/', ZNAV_FM_ROOT), 'items' => $items, 'writable' => is_writable($dir));
    if ($dir !== str_replace('\\', '/', ZNAV_FM_ROOT)) {
        $out['dirSize'] = fm_dir_size($dir);
    }
    znav_json($out);
}

case 'fm_read': {
    znav_require_admin();
    $p = fm_path(isset($input['path']) ? $input['path'] : '');
    if ($p === null || !is_file($p)) znav_json(array('error' => '文件不存在'), 400);
    $size = filesize($p);
    // 不再限制大小：<=2MB 全文可编辑；更大的文件 / 二进制文件 → 只读预览前 512KB（保存按钮前端会禁用，避免破坏文件）
    $max  = 512 * 1024;
    $content = (string)file_get_contents($p, false, null, 0, $max);
    $truncated = $size > $max;
    $binary = strpos($content, "\0") !== false;
    znav_json(array(
        'ok' => true,
        'content' => $content,
        'name' => basename($p),
        'size' => $size,
        'truncated' => $truncated,
        'binary' => $binary,
        'readonly' => $binary || $truncated,
    ));
}

case 'fm_save': {
    znav_require_admin();
    $p = fm_path(isset($input['path']) ? $input['path'] : '');
    if ($p === null || !is_file($p)) znav_json(array('error' => '文件不存在'), 400);
    if (!is_writable($p)) znav_json(array('error' => '文件不可写（权限不足）'), 400);
    znav_json(array('ok' => true, 'bytes' => file_put_contents($p, (string)(isset($input['content']) ? $input['content'] : ''))));
}

case 'fm_mkdir': {
    znav_require_admin();
    $p = fm_path(isset($input['path']) ? $input['path'] : '', false);
    if ($p === null) znav_json(array('error' => '非法路径'), 400);
    if (file_exists($p)) znav_json(array('error' => '同名文件或文件夹已存在'), 400);
    $ok = @mkdir($p, 0775, true);
    znav_json($ok || is_dir($p) ? array('ok' => true) : array('error' => '创建失败（权限不足）'), $ok || is_dir($p) ? 200 : 500);
}

case 'fm_touch': {
    znav_require_admin();
    $p = fm_path(isset($input['path']) ? $input['path'] : '', false);
    if ($p === null) znav_json(array('error' => '非法路径'), 400);
    if (file_exists($p)) znav_json(array('error' => '同名文件已存在'), 400);
    znav_json(@file_put_contents($p, '') !== false ? array('ok' => true) : array('error' => '创建失败（权限不足）'), 200);
}

case 'fm_delete': {
    znav_require_admin();
    $paths = isset($input['paths']) && is_array($input['paths']) ? $input['paths'] : array();
    if (!$paths) znav_json(array('error' => '未选择任何项目'), 400);
    $n = 0; $errs = array();
    foreach ($paths as $rel) {
        $p = fm_path($rel);
        if ($p === null || $p === str_replace('\\', '/', ZNAV_FM_ROOT)) { $errs[] = basename((string)$rel); continue; }
        if (fm_rrmdir($p)) $n++; else $errs[] = basename((string)$rel);
    }
    znav_json($errs ? array('error' => '部分删除失败：' . implode('、', $errs)) : array('ok' => true, 'deleted' => $n));
}

case 'fm_copy': {
    znav_require_admin();
    $paths = isset($input['paths']) && is_array($input['paths']) ? $input['paths'] : array();
    $to = fm_path(isset($input['to']) ? $input['to'] : '', false);
    if (!$paths || $to === null || !is_dir($to)) znav_json(array('error' => '参数错误'), 400);
    $n = 0; $errs = array();
    foreach ($paths as $rel) {
        $p = fm_path($rel);
        if ($p === null) { $errs[] = basename((string)$rel); continue; }
        $dst = $to . '/' . basename($p);
        if (file_exists($dst)) $dst = $to . '/' . preg_replace('/(\.[^.]+)?$/', '_副本$1', basename($p));
        if (fm_rcopy($p, $dst)) $n++; else $errs[] = basename((string)$rel);
    }
    znav_json($errs ? array('error' => '部分复制失败：' . implode('、', $errs)) : array('ok' => true, 'copied' => $n));
}

case 'fm_move': {
    znav_require_admin();
    $paths = isset($input['paths']) && is_array($input['paths']) ? $input['paths'] : array();
    $to = fm_path(isset($input['to']) ? $input['to'] : '', false);
    if (!$paths || $to === null || !is_dir($to)) znav_json(array('error' => '参数错误'), 400);
    $n = 0; $errs = array();
    foreach ($paths as $rel) {
        $p = fm_path($rel);
        if ($p === null || $p === str_replace('\\', '/', ZNAV_FM_ROOT)) { $errs[] = basename((string)$rel); continue; }
        $dst = $to . '/' . basename($p);
        if (file_exists($dst)) { $errs[] = basename((string)$rel) . '（同名已存在）'; continue; }
        if (@rename($p, $dst)) $n++; else $errs[] = basename((string)$rel);
    }
    znav_json($errs ? array('error' => '部分移动失败：' . implode('、', $errs)) : array('ok' => true, 'moved' => $n));
}

case 'fm_rename': {
    znav_require_admin();
    $p = fm_path(isset($input['path']) ? $input['path'] : '');
    $parent = $p ? dirname($p) : null;
    $new = trim((string)(isset($input['name']) ? $input['name'] : ''));
    if ($p === null || $parent === null || $new === '' || preg_match('#[\\\\/]#', $new)) znav_json(array('error' => '参数错误'), 400);
    $dst = $parent . '/' . $new;
    if (file_exists($dst)) znav_json(array('error' => '同名文件已存在'), 400);
    znav_json(@rename($p, $dst) ? array('ok' => true) : array('error' => '重命名失败'), 200);
}

/** 查询服务器上传窗口（前端据此决定单片大小，做到「不限大小」） */
case 'upload_limits': {
    znav_require_admin();
    znav_json(array(
        'ok'         => true,
        'chunk'      => znav_upload_window(),
        'uploadMax'  => ini_get('upload_max_filesize'),
        'postMax'    => ini_get('post_max_size'),
        'zipSupport' => class_exists('ZipArchive'),
    ));
}

case 'fm_upload': {
    znav_require_admin();
    $toRaw = isset($_GET['to']) ? $_GET['to'] : (isset($input['to']) ? $input['to'] : '');
    $to = fm_path($toRaw, false);
    if ($to === null || !is_dir($to)) znav_json(array('error' => '目标目录不存在'), 400);
    if (empty($_FILES['files'])) znav_json(array('error' => '没有收到文件'), 400);
    $names = (array)$_FILES['files']['name'];
    $tmps = (array)$_FILES['files']['tmp_name'];
    $errs = (array)$_FILES['files']['error'];
    $sizes = (array)$_FILES['files']['size'];
    $ok = 0; $fail = array();
    $unzip = !empty($input['unzip']);
    foreach ($names as $i => $nm) {
        $nm = basename((string)$nm);
        if ($nm === '' || $errs[$i] !== UPLOAD_ERR_OK) { $fail[] = $nm ?: '未知文件'; continue; }
        if ($sizes[$i] > 50 * 1024 * 1024) { $fail[] = $nm . '（超 50MB）'; continue; }
        $dst = $to . '/' . $nm;
        if (!@move_uploaded_file($tmps[$i], $dst)) { $fail[] = $nm; continue; }
        $ok++;
        if ($unzip && preg_match('/\.zip$/i', $nm) && class_exists('ZipArchive')) {
            $zip = new ZipArchive();
            if ($zip->open($dst) === true) {
                $zip->extractTo($to);
                $zip->close();
                @unlink($dst);
            }
        }
    }
    znav_json($fail ? array('error' => '部分上传失败：' . implode('、', $fail)) : array('ok' => true, 'uploaded' => $ok));
}

/** 解压服务器上已有的 zip（文件管理右键 → 解压到此文件夹；可选解压后删除 zip） */
case 'fm_unzip': {
    znav_require_admin();
    @set_time_limit(600);
    if (!class_exists('ZipArchive')) znav_json(array('error' => '服务器 PHP 缺少 ZipArchive（php-zip）扩展，无法解压'), 500);
    $rel = (string)(isset($input['path']) ? $input['path'] : '');
    $zp = fm_path($rel, true);
    if ($zp === null || !is_file($zp)) znav_json(array('error' => 'zip 文件不存在'), 404);
    if (!preg_match('/\.zip$/i', $zp)) znav_json(array('error' => '只能解压 .zip 文件'), 400);
    $toRel = (string)(isset($input['to']) ? $input['to'] : dirname(str_replace('\\', '/', $rel)));
    $to = fm_path($toRel, false);
    if ($to === null) znav_json(array('error' => '目标路径不合法'), 400);
    // 目标目录不存在时自动创建（而不是报错中断）
    if (!is_dir($to) && !@mkdir($to, 0775, true) && !is_dir($to)) znav_json(array('error' => '目标目录创建失败：' . $toRel), 500);
    $zip = new ZipArchive();
    if ($zip->open($zp) !== true) znav_json(array('error' => 'zip 打开失败，文件可能已损坏'), 400);
    if (!$zip->extractTo($to)) {
        $zip->close();
        znav_json(array('error' => '解压失败：目标目录可能不可写，或 zip 内条目名非法'), 500);
    }
    $count = intval($zip->numFiles);
    $zip->close();
    $deleted = false;
    if (!empty($input['delete'])) $deleted = @unlink($zp);
    znav_json(array('ok' => true, 'files' => $count, 'zipDeleted' => $deleted));
}

/** 分片上传：前端把文件切成 2MB 一片顺序上传，服务端追加写临时文件。
 *  这样暂停 = 停止发送分片（已传分片保留），继续 = 从下一片接着传，取消 = 删除临时文件。 */
case 'fm_upload_chunk': {
    znav_require_admin();
    $uploadId = preg_replace('/[^a-zA-Z0-9_-]/', '', (string)(isset($_POST['uploadId']) ? $_POST['uploadId'] : ''));
    if ($uploadId === '') znav_json(array('error' => '缺少上传标识 uploadId'), 400);
    $to = fm_path(isset($_POST['to']) ? $_POST['to'] : '', false);
    if ($to === null || !is_dir($to)) znav_json(array('error' => '目标目录不存在'), 400);
    $name = basename((string)(isset($_POST['name']) ? $_POST['name'] : ''));
    if ($name === '' || $name === '.' || $name === '..') znav_json(array('error' => '文件名不合法'), 400);
    $index = max(0, intval(isset($_POST['index']) ? $_POST['index'] : 0));
    $total = max(1, intval(isset($_POST['total']) ? $_POST['total'] : 1));
    // dest：可选的「最终落盘路径」（相对站点根，含文件名）。给了就按这个名字写入并覆盖，
    // 不做重名改名 —— 媒体包导入这类场景需要固定文件名。
    $dstFixed = null;
    if (isset($_POST['dest']) && trim((string)$_POST['dest']) !== '') {
        $dstFixed = fm_path((string)$_POST['dest'], false);
        if ($dstFixed === null) znav_json(array('error' => '目标路径不合法'), 400);
        $parent = dirname($dstFixed);
        if (!is_dir($parent) && !@mkdir($parent, 0775, true) && !is_dir($parent)) {
            znav_json(array('error' => '目标目录不可创建：' . $parent), 500);
        }
        $tmpDir = $parent . '/.znav_tmp';
    } else {
        $tmpDir = $to . '/.znav_tmp';
    }
    if (!is_dir($tmpDir) && !@mkdir($tmpDir, 0775, true) && !is_dir($tmpDir)) {
        znav_json(array('error' => '临时目录创建失败（目录不可写）'), 500);
    }
    $part = $tmpDir . '/' . $uploadId . '.part';
    if ($index === 0) { @unlink($part); }
    if (empty($_FILES['chunk'])) znav_json(array('error' => '没有收到分片数据'), 400);
    if ($_FILES['chunk']['error'] !== UPLOAD_ERR_OK) {
        $codes = array(1 => '超过 php.ini upload_max_filesize', 3 => '只上传了一部分', 4 => '没有文件', 6 => '缺少临时目录', 7 => '写入磁盘失败');
        $ce = intval($_FILES['chunk']['error']);
        znav_json(array('error' => '分片上传失败：' . (isset($codes[$ce]) ? $codes[$ce] : ('错误码 ' . $ce))), 400);
    }
    $in = @fopen($_FILES['chunk']['tmp_name'], 'rb');
    $out = @fopen($part, 'ab');
    if (!$in || !$out) { if ($in) fclose($in); if ($out) fclose($out); znav_json(array('error' => '临时文件写入失败'), 500); }
    stream_copy_to_stream($in, $out);
    fclose($in); fclose($out);
    clearstatcache(true, $part);
    $size = @filesize($part);
    $size = $size === false ? 0 : $size;
    if ($index >= $total - 1) {
        if ($dstFixed !== null) {
            // 固定文件名：直接覆盖
            if (!@rename($part, $dstFixed)) {
                if (!@copy($part, $dstFixed)) znav_json(array('error' => '保存文件失败（目标目录不可写）'), 500);
                @unlink($part);
            }
            @clearstatcache(true, $dstFixed);
            $size = (int)@filesize($dstFixed);
            znav_clean_tmp_dir($tmpDir, $uploadId);
            $rel = fm_rel($dstFixed);
            znav_json(array('ok' => true, 'done' => true, 'name' => basename($dstFixed), 'path' => $rel, 'size' => $size, 'overwritten' => true));
        }
        // 最后一片：落到目标文件名（重名自动加 (1)(2)…）
        $dst = $to . '/' . $name;
        if (is_file($dst)) {
            $dot = strrpos($name, '.');
            $base = $dot === false ? $name : substr($name, 0, $dot);
            $ext  = $dot === false ? '' : substr($name, $dot);
            for ($k = 1; $k < 500; $k++) {
                $try = $to . '/' . $base . '(' . $k . ')' . $ext;
                if (!is_file($try)) { $dst = $try; break; }
            }
        }
        $okMove = @rename($part, $dst);
        if (!$okMove) { $okMove = @copy($part, $dst); @unlink($part); }
        if (!$okMove) znav_json(array('error' => '保存文件失败（目标目录不可写）'), 500);
        @unlink($tmpDir . '/' . $uploadId . '.json');
        // 目录空了就顺手清掉临时目录
        $left = @scandir($tmpDir);
        if ($left && count($left) <= 2) @rmdir($tmpDir);
        znav_json(array('ok' => true, 'done' => true, 'name' => basename($dst), 'size' => $size));
    }
    znav_json(array('ok' => true, 'done' => false, 'received' => $size));
}

/** 取消分片上传：删除临时分片 */
case 'fm_upload_abort': {
    znav_require_admin();
    $uploadId = preg_replace('/[^a-zA-Z0-9_-]/', '', (string)(isset($input['uploadId']) ? $input['uploadId'] : ''));
    $to = fm_path(isset($input['to']) ? $input['to'] : '', false);
    if ($uploadId !== '' && $to !== null) {
        @unlink($to . '/.znav_tmp/' . $uploadId . '.part');
        @unlink($to . '/.znav_tmp/' . $uploadId . '.json');
    }
    znav_json(array('ok' => true));
}

case 'fm_download': {
    znav_require_admin();
    $p = fm_path(isset($_GET['path']) ? $_GET['path'] : (isset($input['path']) ? $input['path'] : ''));
    if ($p === null || !is_file($p)) znav_json(array('error' => '文件不存在'), 400);
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="' . rawurlencode(basename($p)) . '"');
    header('Content-Length: ' . filesize($p));
    header('X-Content-Type-Options: nosniff');
    readfile($p);
    exit;
}
default:
    znav_json(array('error' => '未知操作'), 400);
}
} catch (Throwable $e) {
    // 任何未捕获异常/致命错误都返回 JSON（带文件与行号，便于定位），绝不输出空白 500
    znav_json(array(
        'ok' => false,
        'error' => '服务器内部错误：' . $e->getMessage() . '（' . basename($e->getFile()) . ' 第 ' . $e->getLine() . ' 行）',
    ), 500);
}