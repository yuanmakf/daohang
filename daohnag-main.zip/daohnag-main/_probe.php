<!DOCTYPE html><html><head><meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="/assets/style.css"></head><body>
<div class="topbar"><div class="topbar-inner"><div class="topbar-actions" id="topbarActions">
<button id="quickBtn" class="quick-btn"><span class="qb-ico">⚙️</span><span class="qb-txt">快捷功能</span></button>
</div></div></div>
<button id="menuBtn" class="menu-fab"><span>☰</span><em>分类导航</em></button>
<button id="chatFab" class="chat-fab">💬</button>
<button id="backTop" class="back-top" style="display:block">↑</button>
<pre id="out">PENDING</pre>
<script>
const g = (sel, props) => { const el = document.querySelector(sel); if (!el) return sel + ': MISSING'; const cs = getComputedStyle(el); return sel + ': ' + props.map(p => p + '=' + cs[p]).join(' '); };
document.getElementById('out').textContent = [
  g('#menuBtn', ['position','top','left','width','height','zIndex','display','fontSize']),
  g('#chatFab', ['position','width','height','right','bottom','fontSize']),
  g('#backTop', ['width','height']),
  g('#quickBtn', ['display','height']),
  g('.brand', ['position'])
].join('\n');
</script></body></html>
