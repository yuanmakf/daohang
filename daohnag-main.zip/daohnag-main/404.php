<?php
/**
 * NavVerse 404 页面 —— 走错路了，送你回家
 * Apache：由 .htaccess 的 ErrorDocument 自动生效；
 * Nginx：在站点配置里加  error_page 404 /404.php;  （宝塔：网站设置 → 配置文件）
 * http_status_code(404) 保证搜索引擎正确识别，不会被当成正常页收录。
 */
http_response_code(404);
$home = '/';
$back = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : '';
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex">
<title>404 · 页面走丢了</title>
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  html, body { height: 100%; }
  body {
    min-height: 100vh; display: flex; align-items: center; justify-content: center;
    font-family: "PingFang SC", "Microsoft YaHei", -apple-system, sans-serif;
    background: linear-gradient(135deg, #eef1fb 0%, #e3ecfa 50%, #eef1fb 100%);
    color: #2b3a55; padding: 24px; overflow: hidden;
  }
  @media (prefers-color-scheme: dark) {
    body { background: linear-gradient(135deg, #151a2e 0%, #1a2140 50%, #151a2e 100%); color: #dfe6ff; }
    .card { background: rgba(30, 38, 68, .75) !important; box-shadow: 0 20px 60px rgba(0,0,0,.45) !important; }
    .code { color: rgba(223,230,255,.14) !important; }
    .tip { color: #93a0c4 !important; }
  }
  .card {
    text-align: center; max-width: 460px; width: 100%;
    background: rgba(255,255,255,.72); backdrop-filter: blur(14px);
    border-radius: 24px; padding: 52px 36px 44px;
    box-shadow: 0 20px 60px rgba(43,58,85,.16);
    animation: up .5s ease both;
  }
  @keyframes up { from { opacity: 0; transform: translateY(26px); } to { opacity: 1; transform: none; } }
  .code { font-size: 96px; font-weight: 800; line-height: 1; letter-spacing: 4px;
          color: rgba(43,58,85,.10); user-select: none; }
  .emoji { font-size: 44px; margin-top: -58px; display: block;
           animation: swing 2.6s ease-in-out infinite; transform-origin: 50% 90%; }
  @keyframes swing { 0%,100% { transform: rotate(-8deg); } 50% { transform: rotate(8deg); } }
  h1 { font-size: 22px; margin: 18px 0 10px; font-weight: 700; }
  .tip { font-size: 14px; color: #6b7a99; line-height: 1.8; margin-bottom: 28px; }
  .btns { display: flex; gap: 12px; justify-content: center; flex-wrap: wrap; }
  .btn {
    display: inline-flex; align-items: center; gap: 8px; text-decoration: none;
    padding: 12px 26px; border-radius: 999px; font-size: 15px; font-weight: 600;
    transition: transform .15s ease, box-shadow .15s ease; cursor: pointer; border: none;
  }
  .btn:hover { transform: translateY(-2px); }
  .btn-home { background: linear-gradient(135deg, #5b7cfa, #7a5cf0); color: #fff;
              box-shadow: 0 8px 22px rgba(91,124,250,.4); }
  .btn-back { background: transparent; color: inherit; border: 1.5px solid rgba(107,122,153,.4); }
  .compass { display: inline-block; margin-right: 6px; }
</style>
</head>
<body>
  <div class="card">
    <div class="code">404</div>
    <span class="emoji">🧭</span>
    <h1>走错路了，找不到这个页面</h1>
    <p class="tip">别慌 —— 页面可能已被移动或删除。<br>带上你的指南针，我们送你回家。</p>
    <div class="btns">
      <a class="btn btn-home" href="<?php echo htmlspecialchars($home, ENT_QUOTES); ?>"><span class="compass">🏠</span>回到首页</a>
      <?php if ($back && strpos($back, 'http') === 0): ?>
      <a class="btn btn-back" href="<?php echo htmlspecialchars($back, ENT_QUOTES); ?>">← 返回上一页</a>
      <?php endif; ?>
    </div>
  </div>
</body>
</html>
