<?php
/**
 * 趣导 NavVerse - 文章详情页（/article.php?id=N）
 * 与首页完全一致：顶部导航 + 左侧分类导航 + 同套配色/背景 + 居中卡片
 */
require_once __DIR__ . '/lib/db.php';
// 禁止浏览器/WebView 缓存页面 HTML（手机 WebView 曾因缓存旧 HTML+旧 CSS 出现样式错乱）
header("Cache-Control: no-cache, no-store, must-revalidate");
header("Pragma: no-cache");
header("Expires: 0");

require_once __DIR__ . '/lib/seo.php';
if (!znav_is_installed()) { header('Location: install.php'); exit; }
$siteName = znav_setting('siteName', '趣导 NavVerse');
// 右下角「在线交流」悬浮按钮：后台 → 系统设置 → 右上角快捷面板 里可隐藏
$chatOn = znav_setting('dockChat', '1') !== '0';
$siteLogo = znav_setting('siteLogo', '');
$siteNameVisible = znav_setting('siteNameVisible', '1') !== '0';
$logoSize = max(20, min(96, intval(znav_setting('logoSize', '40'))));
$cardLogoW = max(24, min(96, intval(znav_setting('cardLogoW', '42'))));
$cardLogoH = max(24, min(96, intval(znav_setting('cardLogoH', '42'))));
$cardMinW  = max(150, min(400, intval(znav_setting('cardMinW', '220'))));
$cardMinH  = max(0, min(160, intval(znav_setting('cardMinH', '0'))));
// Logo 尺寸：宽高独立生效（默认不保持比例，拉伸铺满设定的宽高）
$logoStyle = znav_brand_logo_style();
// 站点名称自定义样式（大小 / 颜色 / 字体）：颜色主题化，自动跟随白天/黑夜切换
list($nameStyle, $brandColorCss) = znav_site_name_style();

$bgPreset = znav_setting('bgPreset', 'aurora');
$bgImage = znav_setting('bgImage', '');
$footerText = znav_setting('footerText', '');
$qrQQ = znav_setting('qrQQ', '');
$qrWeixin = znav_setting('qrWeixin', '');
$qrReward = znav_setting('qrReward', '');
$pageWidth = znav_setting('pageWidth', 'wide');
if (!in_array($pageWidth, array('full', 'wide', 'normal', 'custom'), true)) $pageWidth = 'wide';
$thumbW = max(40, min(480, intval(znav_setting('thumbW', '132'))));
$thumbH = max(30, min(480, intval(znav_setting('thumbH', '92'))));

$navTree = znav_nav_tree();

$id = intval(isset($_GET['id']) ? $_GET['id'] : 0);
$art = null;
if ($id > 0) {
    $st = znav_db()->prepare('SELECT * FROM articles WHERE id=? AND enabled=1');
    $st->execute(array($id));
    $art = $st->fetch();
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<?php
// ===== SEO：文章页独立标题 / 摘要 / Article 结构化数据 =====
$seoTitle = $art ? $art['title'] . ' - ' . $siteName : '文章 - ' . $siteName;
$seoDesc = $art ? znav_seo_excerpt($art['summary'] !== '' ? $art['summary'] : $art['content'], 150) : znav_seo_default_desc();
$seoUrl = znav_seo_site_url() . '/article.php?id=' . $id;
echo znav_seo_head(array(
    'title' => $seoTitle, 'description' => $seoDesc, 'url' => $seoUrl, 'type' => 'article',
    'image' => $art && !empty($art['image']) ? $art['image'] : '',
    'noindex' => !$art,
)) . "\n";
if ($art) {
    echo znav_seo_jsonld(array(
        'article' => array(
            'title' => $art['title'], 'description' => $seoDesc, 'url' => $seoUrl,
            'author' => !empty($art['author']) ? $art['author'] : $siteName,
            'published' => !empty($art['created_at']) ? $art['created_at'] : '',
            'modified' => !empty($art['created_at']) ? $art['created_at'] : '',
            'image' => !empty($art['image']) ? $art['image'] : '',
        ),
        'breadcrumbs' => array(
            array('name' => '首页', 'url' => znav_seo_site_url() . '/'),
            array('name' => $art['title'], 'url' => $seoUrl),
        ),
    )) . "\n";
}
?>
<title><?php echo znav_e($seoTitle); ?></title>
  <?php echo znav_favicon_html(); ?>
<link rel="stylesheet" href="/assets/style.css?v=<?php echo filemtime(__DIR__ . '/assets/style.css'); ?>">
<style>:root{--logo-size:<?php echo $logoSize; ?>px;--thumb-w:<?php echo $thumbW; ?>px;--thumb-h:<?php echo $thumbH; ?>px}--card-logo-w:<?php echo $cardLogoW; ?>px;--card-logo-h:<?php echo $cardLogoH; ?>px;--card-min-w:<?php echo $cardMinW; ?>px;--card-min-h:<?php echo $cardMinH ? $cardMinH.'px' : '0'; ?>;</style>
  <?php if (!empty($brandColorCss)): ?><style><?php echo $brandColorCss; ?></style><?php endif; ?>
</head>
<body data-bg="<?php echo znav_e($bgPreset); ?>" data-bgimg="<?php echo znav_e($bgImage); ?>" data-width="<?php echo znav_e($pageWidth); ?>" data-keep-title="1">
<?php if ($bgImage): ?><div class="custom-bg-layer"></div><?php endif; ?>

<div class="body-flex" id="bodyFlex">
<?php require __DIR__ . '/inc.topbar.php'; ?>

<div class="body-main">
<button id="menuBtn" class="menu-fab" title="分类"><span>☰</span><em data-i18n="cats">分类导航</em></button>

<main class="wrap" id="mainContent">
  <?php if (!$art): ?>
  <section class="pv-card" style="margin-top:0">
    <div class="page-view">
      <h2 class="page-title">文章不存在或已下架</h2>
      <p class="page-back"><a href="/">← 返回首页</a></p>
    </div>
  </section>
  <?php else: ?>
  <article class="art-detail">
    <header class="ar-head">
      <h1 class="ar-title"><?php echo znav_e($art['title']); ?></h1>
      <div class="ar-meta">
        <span class="ar-badge">文章</span>
        <?php if (!empty($art['author'])): ?><span>✍️ <?php echo znav_e($art['author']); ?></span><?php endif; ?>
        <span>📅 发布时间：<?php echo znav_e(substr((string)$art['created_at'], 0, 16)); ?></span>
      </div>
    </header>
    <?php if (!empty($art['image'])): ?><img class="ar-cover" src="<?php echo znav_e($art['image']); ?>" alt=""><?php endif; ?>
    <div class="ar-body page-content-rich<?php echo preg_match('/<[a-z][\s\S]*>/i', (string)$art['content']) ? ' page-content-rich-html' : ''; ?>">
      <?php echo preg_match('/<[a-z][\s\S]*>/i', (string)$art['content']) ? $art['content'] : '<p>' . nl2br(znav_e($art['content'])) . '</p>'; ?>
    </div>
    <p class="page-back" style="margin-top:28px"><a href="/">← 返回首页</a></p>
  </article>
  <?php endif; ?>
</main>

<footer class="footer">
  <?php if ($qrQQ || $qrWeixin || $qrReward): ?>
  <div class="footer-qrs">
    <?php if ($qrQQ): ?><div class="qr-item"><img src="<?php echo znav_e($qrQQ); ?>" alt="QQ群"><span data-i18n="joinQQ">扫码加 QQ 群</span></div><?php endif; ?>
    <?php if ($qrWeixin): ?><div class="qr-item"><img src="<?php echo znav_e($qrWeixin); ?>" alt="微信群"><span data-i18n="joinWx">扫码加微信群</span></div><?php endif; ?>
    <?php if ($qrReward): ?><div class="qr-item"><img src="<?php echo znav_e($qrReward); ?>" alt="打赏"><span data-i18n="reward">扫码打赏</span></div><?php endif; ?>
  </div>
  <?php endif; ?>
  <div class="friend-links" id="friendLinks"></div>
  <div class="footer-pages">
    <?php foreach ($navTree as $np): ?>
    <a href="/?page=<?php echo znav_e($np['slug']); ?>"><?php echo znav_e($np['title']); ?></a>
    <?php endforeach; ?>
  </div>
  <p class="foot-line">© <?php echo date('Y'); ?> <?php echo znav_e($siteName); ?> · Powered by NavVerse<?php echo $footerText !== '' ? ' · ' . znav_e($footerText) : ''; ?></p>
</footer>
</div><!-- /body-main -->
</div><!-- /body-flex -->

<!-- 会员登录 / 注册弹窗 -->
<div id="userModal" class="zmodal" style="display:none">
  <div class="zmodal-mask"></div>
  <div class="zmodal-card user-modal">
    <button class="zmodal-x" id="userModalClose">✕</button>
    <div class="um-tabs"><b id="umTabLogin" class="on">登录</b><b id="umTabReg">注册</b></div>
    <div id="umLogin">
      <input id="ulName" class="zinput" maxlength="20" placeholder="用户名">
      <input id="ulPass" class="zinput" type="password" maxlength="64" placeholder="密码">
      <p class="um-tip" id="ulTip"></p>
      <button id="ulOk" class="zbtn zbtn-ok um-btn">登 录</button>
    </div>
    <div id="umReg" style="display:none">
      <input id="urName" class="zinput" maxlength="20" placeholder="用户名（2-20 位）">
      <input id="urPass" class="zinput" type="password" maxlength="64" placeholder="密码（至少 6 位）">
      <div class="um-type">
        <label><input type="radio" name="urType" value="member" checked><span>会员 <i>可发帖 + 添加网址</i></span></label>
        <label><input type="radio" name="urType" value="temp"><span>临时账号 <i>7 天有效，仅可发帖</i></span></label>
      </div>
      <p class="um-tip" id="urTip"></p>
      <button id="urOk" class="zbtn zbtn-ok um-btn">注 册</button>
    </div>
  </div>
</div>

<!-- 帖子详情弹窗 -->
<div id="postView" class="zmodal" style="display:none">
  <div class="zmodal-mask"></div>
  <div class="zmodal-card user-modal">
    <button class="zmodal-x" id="postViewClose">✕</button>
    <h3 class="um-title" id="pvTitle"></h3>
    <p class="pv-meta" id="pvMeta"></p>
    <div class="pv-body" id="pvBody"></div>
  </div>
</div>

<!-- 右下角悬浮聊天窗 -->
<div id="chatBox" class="chat-box" style="display:none">
  <div class="chat-head">
    <span class="chat-dot"></span><b>在线交流</b>
    <span class="chat-head-btns">
      <button id="chatRenameBtn" title="换个昵称">✏️</button>
      <button id="chatMinBtn" title="收起">－</button>
      <button id="chatCloseBtn" title="关闭">✕</button>
    </span>
  </div>
  <div class="chat-gate" id="chatGate">
    <p>👋 取一个昵称，加入聊天</p>
    <div class="chat-gate-row">
      <input id="chatNameInput" maxlength="20" placeholder="你的昵称">
      <button id="chatNameOk" class="chat-send">进入</button>
    </div>
  </div>
  <div class="chat-msgs" id="chatMsgs"></div>
  <div class="chat-emoji-pop" id="chatEmojiPop" style="display:none"></div>
  <div class="chat-input-row">
    <button id="chatEmojiBtn" title="表情">😊</button>
    <label class="chat-img-label" for="chatImgInput" title="发送图片（≤100KB）">🖼️</label>
    <input type="file" id="chatImgInput" accept="image/*" hidden>
    <input id="chatTextInput" maxlength="500" placeholder="说点什么…">
    <button id="chatSendBtn" class="chat-send">发送</button>
  </div>
</div>
<?php if ($chatOn): ?><button id="chatFab" class="chat-fab" title="在线交流">💬</button><?php endif; ?>

<button id="backTop" class="back-top" title="回到顶部">↑</button>
<script src="/assets/app.js?v=<?php echo filemtime(__DIR__ . '/assets/app.js'); ?>"></script>
</body>
</html>
