<?php
/**
 * 前台共用头部：顶部导航栏 + 悬浮面板 + 左侧分类导航
 * 首页 / 文章页 / 聚合页 三处共用同一份，避免各页面结构不同导致功能（如聚合页入口）在某页丢失。
 *
 * 依赖变量（缺失时自动从设置读取补算）：
 *   $siteName $siteLogo $siteNameVisible $logoStyle $nameStyle $navTree
 *   可选：$curPage（当前页面 slug，用于导航高亮）
 *   可选：$hubEnabled $hubBtnPos $hubBtnHtml $hubShowNav $hubShowSide
 */
if (!isset($curPage)) $curPage = null;

if (!isset($hubEnabled) || !isset($hubBtnPos) || !isset($hubBtnHtml)) {
    $hubEnabled = znav_setting('hubEnabled', '1') !== '0';
    $hubName = trim(znav_setting('hubName', '聚合页'));
    if ($hubName === '') $hubName = '聚合页';
    $hubBtnText = trim(znav_setting('hubBtnText', ''));
    if ($hubBtnText === '') $hubBtnText = $hubName;
    $hubBtnPos = znav_setting('hubBtnPos', 'nav');
    if ($hubBtnPos === 'both') $hubBtnPos = 'nav';
    if (!in_array($hubBtnPos, array('nav', 'main', 'side', 'right', 'hero', 'footer', 'none'), true)
        && !preg_match('/^right:(\d{1,2})$/', $hubBtnPos)) $hubBtnPos = 'nav';
    if (preg_match('/^right:(\d{1,2})$/', (string)$hubBtnPos, $__m)) $hubBtnPos = 'right';
    $hubBtnHtml = $hubEnabled && $hubBtnPos !== 'none'
        ? '<a class="hub-entry-btn" href="/hub.php" title="' . znav_e($hubName) . '"><span>🧩</span>' . znav_e($hubBtnText) . '<i>→</i></a>'
        : '';
}
if (!isset($hubShowNav)) $hubShowNav = $hubEnabled && $hubBtnPos === 'nav';
if (!isset($hubShowSide)) $hubShowSide = $hubEnabled && $hubBtnPos === 'side';

// 快捷面板：每一项都可在「后台 → 系统设置 → 快捷面板」单独显示 / 隐藏
$dockShow = array();
foreach (array('pageWidth', 'cursor', 'bg', 'skin', 'theme', 'admin', 'lang', 'user', 'chat', 'music', 'mode') as $__dk) {
    $dockShow[$__dk] = znav_setting('dock' . ucfirst($__dk), '1') !== '0';
}
// 背景音乐歌单（后台「系统设置 → 背景音乐」维护）
$musicList = array();
$__ml = json_decode((string)znav_setting('musicList', '[]'), true);
if (is_array($__ml)) {
    foreach ($__ml as $__m) {
        if (!is_array($__m)) continue;
        $__u = trim((string)(isset($__m['url']) ? $__m['url'] : ''));
        if ($__u === '') continue;
        $__n = trim((string)(isset($__m['name']) ? $__m['name'] : ''));
        $musicList[] = array('name' => $__n !== '' ? $__n : '未命名', 'url' => $__u);
        if (count($musicList) >= 8) break;
    }
}
$dockAny = in_array(true, $dockShow, true);   // 全部隐藏时连齿轮按钮一起不输出，避免空白面板
?>
<!-- 顶部玻璃导航 -->
<header class="topbar" id="topbar">
    <div class="topbar-inner">
      <a class="brand" href="/">
        <?php if ($siteLogo): ?><img class="brand-logo" src="<?php echo znav_e(preg_match('#^/?uploads/#i', $siteLogo) && function_exists('znav_logos_ver') && znav_logos_ver() ? $siteLogo . (strpos($siteLogo, '?') !== false ? '&' : '?') . 'v=' . znav_logos_ver() : $siteLogo); ?>" alt="logo" style="<?php echo znav_e(trim($logoStyle, ';')); ?>"><?php else: ?><span class="brand-mark">⚡</span><?php endif; ?>
        <?php if ($siteNameVisible): ?><span class="brand-name js-site-name"<?php echo $nameStyle ? ' style="' . znav_e($nameStyle) . '"' : ''; ?>><?php echo znav_e($siteName); ?></span><?php endif; ?>
      </a>
      <nav class="top-nav" id="topNav">
        <div class="tn-item">
          <a href="/" class="tn-link<?php echo $curPage ? '' : ' active'; ?>" data-i18n="home">首页</a>
        </div>
        <?php if ($hubEnabled && $hubBtnPos !== 'none'): ?>
        <!-- 聚合页入口按钮槽位：管理员可把按钮拖到 左侧栏 / 右侧栏 / 搜索框下 / 页脚 -->
        <div class="tn-item hub-slot" id="hubSlotNav"><?php if ($hubShowNav) echo $hubBtnHtml; ?></div>
        <?php endif; ?>
        <?php foreach ($navTree as $np): ?>
        <div class="tn-item<?php echo !empty($np['children']) ? ' has-sub' : ''; ?>">
          <a href="/?page=<?php echo znav_e($np['slug']); ?>" class="tn-link<?php echo $curPage && $curPage['slug'] === $np['slug'] ? ' active' : ''; ?>"><?php echo znav_e($np['title']); ?></a>
          <?php if (!empty($np['children'])): ?>
          <div class="tn-sub">
            <?php foreach ($np['children'] as $sub): ?>
            <a href="/?page=<?php echo znav_e($sub['slug']); ?>"><?php echo znav_e($sub['title']); ?></a>
            <?php endforeach; ?>
          </div>
          <?php endif; ?>
        </div>
        <?php endforeach; ?>
      </nav>
      <div class="topbar-actions" id="topbarActions">
        <?php if ($dockAny): ?>
        <!-- 右上角：页面宽度 / 鼠标 / 背景 / 皮肤 / 后台（主题、语言、账号只保留在左上侧栏） -->
        <button id="quickBtn" class="quick-btn" type="button" title="快捷功能：页面宽度、鼠标、背景、皮肤、后台" aria-expanded="false">
          <span class="qb-ico">⚙️</span>
        </button>
        <div id="quickDock" class="quick-dock" style="display:none">
          <?php if ($dockShow['pageWidth']): ?>
          <div class="qd-sec">
            <div class="tools-label">页面宽度</div>
            <!-- 版心宽度切换：宽屏 / 全屏 / 窄屏 / 自定义 -->
            <div class="width-switch" id="widthSwitch" title="页面宽度">
              <button type="button" data-w="wide" data-i18n-title="wWide">宽屏</button>
              <button type="button" data-w="full" data-i18n-title="wFull">全屏</button>
              <button type="button" data-w="normal" data-i18n-title="wNarrow">窄屏</button>
              <button type="button" data-w="custom" data-i18n-title="wCustom">自定义</button>
              <div id="cwPick" class="cw-pick" style="display:none">
                <input id="customWInput" type="number" min="600" max="4000" step="20" placeholder="600 ~ 4000">
                <span class="tip">px</span>
                <button id="customWOk" class="mini-btn" type="button" style="background:linear-gradient(135deg,var(--accent),var(--accent2));color:#fff;border:none;padding:6px 12px">应用</button>
              </div>
            </div>
          </div>
          <?php endif; ?>
          <?php if ($dockShow['cursor'] || $dockShow['bg'] || $dockShow['skin'] || $dockShow['admin'] || $dockShow['mode']): ?>
          <div class="qd-sec">
            <div class="tools-label">外观</div>
            <div class="qd-grid">
              <?php if ($dockShow['cursor']): ?><button id="cursorToggle" class="qd-item" type="button" title="鼠标样式"><span>🖱️</span><em>鼠标</em></button><?php endif; ?>
              <?php if ($dockShow['bg']): ?><button id="bgToggle" class="qd-item" type="button" title="背景"><span>🖼️</span><em>背景</em></button><?php endif; ?>
              <?php if ($dockShow['skin']): ?><button id="skinToggle" class="qd-item" type="button" title="皮肤"><span>🎨</span><em>皮肤</em></button><?php endif; ?>
              <?php if ($dockShow['mode']): ?><button id="modeToggle" class="qd-item" type="button" title="切换显示模式：图文（带图标）/ 全文字"><span id="modeToggleIco">🖼️</span><em id="modeToggleTxt">图文</em></button><?php endif; ?>
              <?php if ($dockShow['admin']): ?><a id="adminLinkDock" class="qd-item" href="/admin/" title="后台管理"><span>🔧</span><em>后台</em></a><?php endif; ?>
            </div>
          </div>
          <?php endif; ?>
        </div>
        <?php endif; ?>
      </div>
    </div>
  </header>

  <!-- 背景选择弹层 -->
  <div id="bgPanel" class="bg-panel" style="display:none">
    <div class="bg-panel-head"><span data-i18n="bgPick">选择背景</span><button id="bgClose" class="mini-btn">✕</button></div>
    <div id="bgList" class="bg-list"></div>
    <div class="bg-dim-row" title="拖动或输入数值调节背景明暗（只作用于背景，不影响内容）">
      <span class="bg-dim-ico">🌙</span>
      <input id="bgDim" type="range" min="0" max="100" step="1" value="50">
      <input id="bgDimNum" class="bg-dim-num" type="number" min="0" max="100" step="1" value="50" title="输入 0~100 的数值：50 = 原样，越小越暗，越大越亮">
      <span class="bg-dim-ico">☀️</span>
    </div>
  </div>

  <!-- 鼠标样式弹层（默认 = 经典手型） -->
  <div id="cursorPanel" class="bg-panel cursor-panel" style="display:none">
    <div class="bg-panel-head"><span>鼠标样式</span><button id="cursorClose" class="mini-btn">✕</button></div>
    <div id="cursorList" class="cursor-list"></div>
  </div>

  <?php if ($dockShow['music']): ?>
  <!-- 音乐播放器弹层（歌单在后台「系统设置 → 背景音乐」维护） -->
  <div id="musicPanel" class="bg-panel music-panel" style="display:none">
    <div class="bg-panel-head"><span>🎵 背景音乐</span><button id="musicClose" class="mini-btn">✕</button></div>
    <?php if (empty($musicList)): ?>
      <div class="music-empty">还没有添加音乐<br><small>管理员可在「后台 → 系统设置 → 背景音乐」添加</small></div>
    <?php else: ?>
      <ul class="music-list" id="musicList">
        <?php foreach ($musicList as $__i => $__m): ?>
        <li class="music-item" data-idx="<?php echo $__i; ?>" data-src="<?php echo znav_e($__m['url']); ?>">
          <span class="mi-no"><?php echo $__i + 1; ?></span>
          <span class="mi-name" title="<?php echo znav_e($__m['name']); ?>"><?php echo znav_e($__m['name']); ?></span>
          <span class="mi-eq"><i></i><i></i><i></i></span>
        </li>
        <?php endforeach; ?>
      </ul>
      <div class="music-ctrl">
        <button id="musicPrev" class="mc-btn" type="button" title="上一首">⏮</button>
        <button id="musicPlay" class="mc-btn mc-play" type="button" title="播放 / 暂停">▶</button>
        <button id="musicNext" class="mc-btn" type="button" title="下一首">⏭</button>
        <span class="mc-time" id="musicTime">00:00 / 00:00</span>
      </div>
      <div class="music-bar-row" title="播放进度">
        <input id="musicSeek" type="range" min="0" max="1000" value="0">
      </div>
      <div class="music-bar-row" title="音量">
        <span class="mc-vol-ico">🔈</span>
        <input id="musicVol" type="range" min="0" max="100" value="70">
      </div>
      <audio id="musicAudio" preload="none"></audio>
    <?php endif; ?>
  </div>
  <?php endif; ?>

  <div class="drawer-mask" id="drawerMask"></div>
  <aside class="sidebar" id="sidebar">
    <div class="side-head">
      <span class="side-tools" id="sideTools">
        <?php if ($dockShow['lang']): ?><button id="langToggle" class="st-ib st-lang" title="Language">中/EN</button><?php endif; ?>
        <?php if ($dockShow['user']): ?><button id="userBtn" class="st-ib" title="会员中心">👤</button><?php endif; ?>
        <button id="layoutResetBtn" class="st-ib admin-only-btn" title="还原默认布局（清除所有拖动位置）">↩️</button>
        <?php if ($dockShow['theme']): ?><button id="themeToggle" class="st-ib" title="切换白天/黑夜">🌙</button><?php endif; ?>
        <?php if ($dockShow['music']): ?><button id="musicToggle" class="st-ib" title="音乐播放器">🎵</button><?php endif; ?>
      </span>
      <span class="side-head-btns">
        <button id="sideMin" class="mini-btn" title="缩小（只留图标）">－</button>
        <button id="sideHide" class="mini-btn" title="关闭侧栏">✕</button>
      </span>
      <button id="sideClose" class="mini-btn">✕</button>
    </div>
    <div class="side-all">
      <a href="javascript:void(0)" class="side-all-btn active" id="sideAll">
        <span>🏠</span><span data-i18n="allSites">全部网址</span>
      </a>
      <div class="hub-slot-side hub-slot" id="hubSlotSide"><?php if ($hubShowSide) echo $hubBtnHtml; ?></div>
    </div>
    <nav class="menu"><div id="menuCats"></div></nav>
      <div id="sideMore" class="side-more" style="display:none">▼ 下面还有内容</div>
    </aside>
  <button id="sideLeftRestore" class="side-restore" title="显示分类导航">⟩</button>
