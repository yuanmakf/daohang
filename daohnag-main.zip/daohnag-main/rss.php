<?php
/**
 * 趣导 NavVerse - RSS 订阅源（/rss.php）
 * 输出最新文章，供搜索引擎、RSS 阅读器与内容聚合平台抓取
 */
require_once __DIR__ . '/lib/db.php';
require_once __DIR__ . '/lib/seo.php';
if (!znav_is_installed()) { http_response_code(404); exit; }

$siteName = znav_setting('siteName', '趣导 NavVerse');
$base = znav_seo_site_url();
$desc = znav_seo_default_desc();
$build = '';

try {
    $db = znav_db();
    $arts = $db->query("SELECT id,title,summary,content,created_at FROM articles WHERE enabled=1 ORDER BY id DESC LIMIT 50")->fetchAll();
    foreach ($arts as $a) {
        $link = $base . '/article.php?id=' . intval($a['id']);
        $d = znav_seo_excerpt($a['summary'] !== '' ? $a['summary'] : $a['content'], 300);
        $pub = $a['created_at'] ? date(DATE_RSS, strtotime($a['created_at'])) : date(DATE_RSS);
        $build .= "    <item>\n"
            . '      <title>' . znav_e($a['title']) . "</title>\n"
            . '      <link>' . znav_e($link) . "</link>\n"
            . '      <guid isPermaLink="true">' . znav_e($link) . "</guid>\n"
            . '      <pubDate>' . $pub . "</pubDate>\n"
            . '      <description>' . znav_e($d) . "</description>\n"
            . "    </item>\n";
    }
    // 没有文章时，退而输出最新收录的网址，保证源非空
    if (!$arts) {
        $sites = $db->query("SELECT id,name,url,descr FROM sites ORDER BY id DESC LIMIT 30")->fetchAll();
        foreach ($sites as $s) {
            $build .= "    <item>\n"
                . '      <title>' . znav_e($s['name']) . "</title>\n"
                . '      <link>' . znav_e($s['url']) . "</link>\n"
                . '      <guid isPermaLink="false">site-' . intval($s['id']) . '@' . znav_e($base) . "</guid>\n"
                . '      <pubDate>' . date(DATE_RSS) . "</pubDate>\n"
                . '      <description>' . znav_e(znav_seo_excerpt($s['descr'], 200)) . "</description>\n"
                . "    </item>\n";
        }
    }
} catch (Exception $e) { /* 忽略：表不存在时输出空源 */ }

header('Content-Type: application/rss+xml; charset=UTF-8');
echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n"
    . '<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom">' . "\n"
    . "  <channel>\n"
    . '    <title>' . znav_e($siteName) . "</title>\n"
    . '    <link>' . znav_e($base . '/') . "</link>\n"
    . '    <atom:link href="' . znav_e($base . '/rss.php') . '" rel="self" type="application/rss+xml" />' . "\n"
    . '    <description>' . znav_e($desc) . "</description>\n"
    . "    <language>zh-CN</language>\n"
    . '    <lastBuildDate>' . date(DATE_RSS) . "</lastBuildDate>\n"
    . $build
    . "  </channel>\n"
    . '</rss>';
