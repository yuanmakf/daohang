<?php
/**
 * 趣导 NavVerse - 前台（暗色 + 大搜索 + 分区 + 右侧栏 + 悬浮聊天）
 */
require_once __DIR__ . '/lib/db.php';
require_once __DIR__ . '/lib/seo.php';
// 禁止任何浏览器/WebView 缓存本页 HTML：曾出现手机 WebView 缓存旧 HTML+旧 CSS，
// 导致新页面配旧样式（页脚二维码变成无约束大图、弹层平铺）。HTML 永远拿最新的，
// CSS/JS 由 ?v=filemtime 自动更新版本。
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');
// 首次使用：还没有完成安装向导时，跳转到安装页面
if (!znav_is_installed()) { header('Location: install.php'); exit; }
$siteName = znav_setting('siteName', '趣导 NavVerse');
$siteLogo = znav_setting('siteLogo', '');
$siteNameVisible = znav_setting('siteNameVisible', '1') !== '0';
$logoSize = max(20, min(96, intval(znav_setting('logoSize', '40'))));
// 网址卡片版式：圆形图标尺寸 + 卡片最小宽/高（后台 → 系统设置 → 首页版式 可调）
$cardLogoW = max(24, min(96, intval(znav_setting('cardLogoW', '42'))));
$cardLogoH = max(24, min(96, intval(znav_setting('cardLogoH', '42'))));
$cardMinW  = max(150, min(400, intval(znav_setting('cardMinW', '220'))));
$cardMinH  = max(0, min(160, intval(znav_setting('cardMinH', '0'))));
$announcement = znav_setting('announcement', '');
$footerText = znav_setting('footerText', '');
// 右下角「在线交流」悬浮按钮：后台 → 系统设置 → 右上角快捷面板 里可隐藏
$chatOn = znav_setting('dockChat', '1') !== '0';
$qrQQ = znav_setting('qrQQ', '');
$qrWeixin = znav_setting('qrWeixin', '');
$qrReward = znav_setting('qrReward', '');
// 底部「联系我」组件：QQ（悬停显示号码、点击跳转加好友）+ 微信（悬停显示二维码）
$ct = znav_contact();
$ctQQ = $ct['qq']; $ctWxId = $ct['wxId']; $ctQQAvatar = $ct['qqAvatar']; $ctWxAvatar = $ct['wxAvatar'];
$ctWxImg = $ct['wxImg']; $ctWxTip = $ct['wxTip'];
$ctShow = $ct['on'] && ($ctQQ !== '' || $ctWxId !== '' || $ctWxImg !== '');
$bgPreset = znav_setting('bgPreset', 'aurora');
$bgImage = znav_setting('bgImage', '');

// 聚合页入口按钮位置：nav=顶部导航 / side=左侧分类栏 / right=右侧栏 / hero=搜索框下方 / footer=页脚 / none=不显示
// 兼容旧值 both → nav；管理员可在首页直接按住按钮拖到任意槽位（保存到 hubBtnPos）
$hubEnabled = znav_setting('hubEnabled', '1') !== '0';
$hubName = trim(znav_setting('hubName', '聚合页'));
if ($hubName === '') $hubName = '聚合页';
$hubBtnText = trim(znav_setting('hubBtnText', ''));
if ($hubBtnText === '') $hubBtnText = $hubName;   // 按钮文字留空时跟随「聚合页名称」
$hubBtnPos = znav_setting('hubBtnPos', 'nav');
if ($hubBtnPos === 'both') $hubBtnPos = 'nav';
// right:N = 右侧栏内自由落点（插到第 N 个模块前），由前端 JS 精确归位
if (!in_array($hubBtnPos, array('nav', 'main', 'side', 'right', 'hero', 'footer', 'none'), true) && !preg_match('/^right:(\d{1,2})$/', $hubBtnPos)) $hubBtnPos = 'nav';
$hubRightOrder = -1;
if (preg_match('/^right:(\d{1,2})$/', (string)$hubBtnPos, $m)) { $hubRightOrder = (int)$m[1]; $hubBtnPos = 'right'; }
$hubShowNav = $hubEnabled && $hubBtnPos === 'nav';
$hubShowMain = $hubEnabled && $hubBtnPos === 'main';
$hubShowSide = $hubEnabled && $hubBtnPos === 'side';
$hubShowRight = $hubEnabled && $hubBtnPos === 'right';
$hubShowHero = $hubEnabled && $hubBtnPos === 'hero';
$hubShowFooter = $hubEnabled && $hubBtnPos === 'footer';
$hubBtnHtml = $hubEnabled && $hubBtnPos !== 'none'
    ? '<a class="hub-entry-btn" href="/hub.php" title="' . znav_e($hubName) . '"><span>🧩</span>' . znav_e($hubBtnText) . '<i>→</i></a>'
    : '';

$navTree = znav_nav_tree();

// 外观（标语图 / 缩略图 / 页码宽度）
$heroImage = znav_setting('heroImage', '');
$heroImgW = max(0, min(1600, intval(znav_setting('heroImgW', '0'))));
$heroImgH = max(0, min(600, intval(znav_setting('heroImgH', '0'))));
$heroTextShow = znav_setting('heroTextShow', '1') !== '0';
$heroAlt = trim(znav_setting('announcement', '')) ?: $siteName;
$thumbW = max(40, min(480, intval(znav_setting('thumbW', '132'))));
$thumbH = max(30, min(480, intval(znav_setting('thumbH', '92'))));
$pageWidth = znav_setting('pageWidth', 'wide');
if (!in_array($pageWidth, array('full', 'wide', 'normal', 'custom'), true)) $pageWidth = 'wide';
// 左侧分类导航位置（拖动侧栏到右边时保存 right）
$sidebarPos = znav_setting('sidebarPos', 'left') === 'right' ? 'right' : 'left';
// Logo 尺寸：宽高独立生效（默认不保持比例，拉伸铺满设定的宽高）
$logoStyle = znav_brand_logo_style();
$heroStyle = ($heroImgW ? 'width:' . $heroImgW . 'px;' : '') . ($heroImgH ? 'height:' . $heroImgH . 'px;' : '');

// 站点名称自定义样式（大小 / 颜色 / 字体）：颜色主题化，自动跟随白天/黑夜切换
list($nameStyle, $brandColorCss) = znav_site_name_style();

$curPage = null;
$curPageImages = array();
if (!empty($_GET['page'])) {
    $st = znav_db()->prepare('SELECT slug,title,content,images FROM pages WHERE slug=? AND enabled=1');
    $st->execute(array(preg_replace('/[^a-z0-9\-]/i', '', (string)$_GET['page'])));
    $curPage = $st->fetch();
    if ($curPage && $curPage['images']) {
        foreach (explode("\n", $curPage['images']) as $im) { $im = trim($im); if ($im !== '') $curPageImages[] = $im; }
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<?php
// ===== SEO：每个页面独立的标题 / 描述 / 关键词 / canonical / 结构化数据 =====
$seoTitle = $curPage ? $curPage['title'] . ' · ' . $siteName : $siteName;
$seoDesc = $curPage ? znav_seo_excerpt($curPage['content'], 150) : znav_seo_default_desc();
$seoUrl = znav_seo_site_url() . ($curPage ? '/?page=' . rawurlencode($curPage['slug']) : '/');
echo '  ' . znav_seo_head(array('title' => $seoTitle, 'description' => $seoDesc, 'url' => $seoUrl)) . "\n";
// 首页额外输出「热门网址列表」结构化数据，帮助搜索引擎理解页面内容
$seoItems = array();
if (!$curPage) {
    foreach (znav_db()->query("SELECT name,url FROM sites ORDER BY clicks DESC, id LIMIT 30")->fetchAll() as $sr) {
        if (!empty($sr['url'])) $seoItems[] = array('name' => $sr['name'], 'url' => $sr['url']);
    }
}
echo '  ' . znav_seo_jsonld(array(
    'itemList' => $seoItems,
    'breadcrumbs' => $curPage
        ? array(array('name' => '首页', 'url' => znav_seo_site_url() . '/'), array('name' => $curPage['title'], 'url' => $seoUrl))
        : array(array('name' => $siteName, 'url' => $seoUrl)),
)) . "\n";
?>
  <title><?php echo znav_e($seoTitle); ?></title>
  <?php echo znav_favicon_html(); ?>
  <link rel="alternate" type="application/rss+xml" title="<?php echo znav_e($siteName); ?>" href="/rss.php">
  <link rel="stylesheet" href="/assets/style.css?v=<?php echo filemtime(__DIR__.'/assets/style.css'); ?>">
  <style>:root { --logo-size: <?php echo $logoSize; ?>px; --thumb-w: <?php echo $thumbW; ?>px; --thumb-h: <?php echo $thumbH; ?>px; --card-logo-w: <?php echo $cardLogoW; ?>px; --card-logo-h: <?php echo $cardLogoH; ?>px; --card-min-w: <?php echo $cardMinW; ?>px; --card-min-h: <?php echo $cardMinH ? $cardMinH . 'px' : '0'; ?>; }</style>
  <?php if ($brandColorCss !== ''): ?><style><?php echo $brandColorCss; ?></style><?php endif; ?>
</head>
<body data-bg="<?php echo znav_e($bgPreset); ?>" data-page="<?php echo $curPage ? znav_e($curPage['slug']) : ''; ?>" data-width="<?php echo znav_e($pageWidth); ?>" data-home-mode="<?php echo znav_e(znav_setting('homeMode', 'logo')); ?>" data-deflogo="<?php echo znav_e(trim((string)znav_setting('defaultLogo', ''))); ?>">
  <!-- 左侧常驻分类导航 + 内容并排（右侧栏时交换顺序） -->
  <div class="body-flex<?php echo $sidebarPos === 'right' ? ' sb-right' : ''; ?>" id="bodyFlex" data-sidebar-pos="<?php echo $sidebarPos; ?>">
  <?php require __DIR__ . '/inc.topbar.php'; ?>

  <div class="body-main">
  <!-- 移动端打开分类的悬浮按钮 -->
  <button id="menuBtn" class="menu-fab" title="分类"><span>☰</span><em data-i18n="cats">分类导航</em></button>

  <?php if ($curPage): ?>
  <!-- ============ 页面视图（每个模块独立卡片，宽度与顶部导航对齐） ============ -->
  <main class="wrap page-wrap" id="mainContent">
    <section class="page-view">
      <div class="pv-card pv-title-card">
        <h2 class="page-title"><?php echo znav_e($curPage['title']); ?></h2>
      </div>
      <div id="pageContents" class="page-contents"></div>
      <div class="pv-card">
        <?php if ($curPageImages): ?>
        <div class="page-images">
          <?php foreach ($curPageImages as $im): ?><img src="<?php echo znav_e($im); ?>" alt="" loading="lazy"><?php endforeach; ?>
        </div>
        <?php endif; ?>
        <div class="page-content page-content-rich"><?php echo preg_match('/<[a-z][\s\S]*>/i', (string)$curPage['content']) ? $curPage['content'] : nl2br(znav_e($curPage['content'])); ?></div>
      </div>
      <div id="pageArtsWrap" class="pv-card page-arts" style="display:none">
        <h3 class="pa-title">📝 本页文章</h3>
        <div class="content-grid" id="pageArts"></div>
      </div>
      <p class="page-back"><a href="/">← <span data-i18n="backHome">返回首页</span></a></p>
    </section>
  </main>
  <?php else: ?>
  <!-- ============ 首页 ============ -->
  <main class="wrap" id="mainContent">
    <!-- 顶部广告位 -->
    <div id="adTop" class="ad-slot ad-top"></div>

    <!-- 超大搜索区 -->
    <section class="hero">
      <?php if ($heroImage): ?>
      <img class="hero-slogan-img" src="<?php echo znav_e($heroImage); ?>" alt="<?php echo znav_e($heroAlt); ?>" style="<?php echo znav_e($heroStyle); ?>">
      <?php endif; ?>
      <?php if ($heroTextShow): ?>
      <h1 class="hero-title"><?php echo znav_e($announcement ?: '你的一万个网址，从此井井有条 ✨'); ?></h1>
      <?php endif; ?>
      <div class="hero-search">
        <span class="hs-ico">🔍</span>
        <input id="mainSearch" type="text" data-i18n-ph="searchSite" placeholder="搜索本站网址…（按 / 聚焦）">
        <button id="mainSearchBtn" class="hs-btn" data-i18n="searchBtn">搜 索</button>
      </div>
      <div class="hero-tags" id="heroTags"></div>
      <div class="hero-hub-entry hub-slot" id="hubSlotHero"><?php if ($hubShowHero) echo $hubBtnHtml; ?></div>
    </section>

    <!-- 聚合页入口按钮槽位：内容区顶部 C 位（通栏居中，最显眼） -->
    <div class="hub-slot-main hub-slot" id="hubSlotMain"><?php if ($hubShowMain) echo $hubBtnHtml; ?></div>

    <div class="home-cols">
      <!-- 主列 -->
      <div class="col-main">
        <div id="adInline" class="ad-slot ad-inline"></div>

        <!-- 分类子类目 chips 行（点击左侧父分类后在此展示，类旧模板） -->
        <section class="sec" id="catChipSec" style="display:none">
          <div class="sec-head" id="catChipHead"></div>
          <div class="sec-chiprow" id="catChipRow"></div>
          <div class="card-grid" id="catChipGrid"></div>
          <div id="catChipSentinel" style="height:1px"></div>
          <p class="empty-tip" id="catChipEmpty" style="display:none"></p>
        </section>

        <!-- 「常用网址」区块已删除：保留隐藏占位元素，避免前台分区拖动逻辑失效 -->
        <section class="sec" id="hotSec" style="display:none">
          <div class="sec-head" style="display:none">
            <span class="sec-icon">🔥</span>
            <h2 class="sec-title" data-i18n="hotSites">常用网址</h2>
            <span class="sec-count" id="hotCount"></span>
          </div>
          <div class="card-grid" id="hotGrid" style="display:none"></div>
        </section>

        <?php /* 服务端预渲染：蜘蛛不执行 JS 也能读到全部网址，前端 JS 随后用富交互版本覆盖 */ ?>
        <div id="sections"><?php if (!$curPage) echo znav_seo_static_sections(); ?></div>

        <section class="sec" id="searchSec" style="display:none">
          <div class="sec-head">
            <span class="sec-icon">🔍</span>
            <h2 class="sec-title" id="searchTitle" data-i18n="searchResult">搜索结果</h2>
            <span class="sec-count" id="searchCount"></span>
            <button id="searchClear" class="mini-btn" data-i18n="backHome">返回首页</button>
          </div>
          <div class="card-grid" id="searchGrid"></div>
          <div id="loadSentinel" style="height:1px"></div>
          <p class="empty-tip" id="searchEmpty" style="display:none"></p>
        </section>
        <div id="adBottom" class="ad-slot ad-bottom"></div>
      </div>

      <!-- 右侧栏：广告位 + 最新文章 + 社区帖子等模块（后台可增删 / 改名 / 隐藏 / 排序） -->
      <aside class="col-side" id="colSide">
        <div class="side-mod" data-side="ads" data-mod-name="广告位">
          <div class="side-ctrl">
            <button class="sc-btn" data-act="min" title="缩小（只留标题）">－</button>
            <button class="sc-btn sc-close" data-act="close" title="关闭此模块">✕</button>
          </div>
          <div id="adRight" class="ad-slot ad-right"></div>
        </div>

        <section class="side-mod sec" id="sideArtsSec" data-side="arts" data-mod-name="最新文章" style="display:none">
          <div class="side-ctrl">
            <button class="sc-btn" data-act="min" title="缩小（只留标题）">－</button>
            <button class="sc-btn sc-close" data-act="close" title="关闭此模块">✕</button>
          </div>
          <div class="sec-head">
            <span class="sec-icon">📰</span>
            <h2 class="sec-title" data-i18n="articles">最新文章</h2>
            <span class="sec-count" id="sideArtsCount"></span>
          </div>
          <div class="side-arts" id="sideArts"></div>
        </section>

        <!-- 社区帖子（会员可发帖 / 删自己的帖子） -->
        <section class="side-mod sec" id="sidePostsSec" data-side="posts" data-mod-name="社区帖子" style="display:none">
          <div class="side-ctrl">
            <button class="sc-btn" data-act="min" title="缩小（只留标题）">－</button>
            <button class="sc-btn sc-close" data-act="close" title="关闭此模块">✕</button>
          </div>
          <div class="sec-head">
            <span class="sec-icon">📣</span>
            <h2 class="sec-title">社区帖子</h2>
            <span class="sec-count" id="sidePostsCount"></span>
          </div>
          <div id="sidePosts" class="side-arts"></div>
          <button id="postNewBtn" class="sp-more" style="display:none">✍️ 我要发帖</button>
        </section>

        <!-- 聚合页入口按钮槽位（右侧栏）；data-hub-order = 插到第 N 个模块前（前端 JS 归位） -->
        <div class="hub-slot-right hub-slot" id="hubSlotRight"<?php echo $hubRightOrder >= 0 ? ' data-hub-order="' . $hubRightOrder . '"' : ''; ?>><?php if ($hubShowRight) echo $hubBtnHtml; ?></div>

        <!-- 全部关闭后的恢复入口（仅管理员可见） -->
        <div class="side-restore" id="sideRestore" style="display:none">
          <button id="sideRestoreBtn" title="恢复右栏模块">☰ 恢复右栏模块</button>
        </div>
      </aside>
    </div>
  </main>
  <?php endif; ?>

  <footer class="footer">
    <p class="foot-hub-line hub-slot" id="hubSlotFooter"><?php if ($hubShowFooter) echo $hubBtnHtml; ?></p>
    <?php if ($qrQQ || $qrWeixin || $qrReward): ?>
    <div class="footer-qrs">
      <?php if ($qrQQ): ?><div class="qr-item"><img src="<?php echo znav_e($qrQQ); ?>" alt="QQ群"><span data-i18n="joinQQ">扫码加 QQ 群</span></div><?php endif; ?>
      <?php if ($qrWeixin): ?><div class="qr-item"><img src="<?php echo znav_e($qrWeixin); ?>" alt="微信群"><span data-i18n="joinWx">扫码加微信群</span></div><?php endif; ?>
      <?php if ($qrReward): ?><div class="qr-item"><img src="<?php echo znav_e($qrReward); ?>" alt="打赏"><span data-i18n="reward">扫码打赏</span></div><?php endif; ?>
    </div>
    <?php endif; ?>
    <?php if ($ctShow): ?>
    <div class="footer-contact">
      <span class="ct-title">联系我</span>
      <?php if ($ctQQ !== ''): ?>
      <div class="ct-item">
        <a class="ct-ava ct-ava-qq" href="https://wpa.qq.com/msgrd?v=3&amp;uin=<?php echo rawurlencode($ctQQ); ?>&amp;site=qq&amp;menu=yes" target="_blank" rel="noopener" aria-label="添加 QQ 好友">
          <?php if ($ctQQAvatar !== ''): ?><img src="<?php echo znav_e($ctQQAvatar); ?>" alt="QQ 头像"><?php else: ?><img src="assets/qq_penguin.png" alt="QQ 企鹅图标" width="28" height="28" style="width:28px;height:28px;object-fit:contain"><?php endif; ?>
        </a>
        <div class="ct-pop">
          <div class="ct-pop-num" data-copy="<?php echo znav_e($ctQQ); ?>" title="点击复制">QQ：<?php echo znav_e($ctQQ); ?></div>
          <div class="ct-pop-tip">点击号码复制 · 点头像加 QQ</div>
        </div>
      </div>
      <?php endif; ?>
      <?php if ($ctWxImg !== ''): ?>
      <div class="ct-item">
        <span class="ct-ava ct-ava-wx" aria-label="微信二维码" tabindex="0">
          <?php if ($ctWxAvatar !== ''): ?>
            <img src="<?php echo znav_e($ctWxAvatar); ?>" alt="微信头像">
          <?php else: ?>
            <svg viewBox="0 0 24 24" width="26" height="26" fill="currentColor" aria-hidden="true"><path d="M9.1 3C5.2 3 2 5.6 2 8.8c0 1.9 1.1 3.6 2.8 4.7l-.7 2.2 2.5-1.2c.8.2 1.7.3 2.5.3h.5a5.6 5.6 0 0 1-.2-1.5c0-3.2 3.3-5.8 7.3-5.8h.6C16.8 5.1 13.3 3 9.1 3Zm-2.5 4.3a.9.9 0 1 1 0-1.9.9.9 0 0 1 0 1.9Zm5 0a.9.9 0 1 1 0-1.9.9.9 0 0 1 0 1.9Z"/><path d="M22 14.2c0-2.6-2.7-4.7-6-4.7s-6 2.1-6 4.7c0 2.6 2.7 4.7 6 4.7.7 0 1.4-.1 2-.2l2 .9-.5-1.6c1.5-.9 2.5-2.2 2.5-3.8Zm-8.2-1a.8.8 0 1 1 0-1.5.8.8 0 0 1 0 1.5Zm4.4 0a.8.8 0 1 1 0-1.5.8.8 0 0 1 0 1.5Z"/></svg>
          <?php endif; ?>
        </span>
        <div class="ct-pop ct-pop-wx">
          <img class="ct-qr" src="<?php echo znav_e($ctWxImg); ?>" alt="微信二维码" loading="lazy">
          <?php if ($ctWxId !== ''): ?><div class="ct-pop-num" data-copy="<?php echo znav_e($ctWxId); ?>" title="点击复制微信号">微信号：<?php echo znav_e($ctWxId); ?></div><?php endif; ?>
          <div class="ct-pop-tip"><?php echo znav_e($ctWxTip); ?></div>
        </div>
      </div>
      <?php endif; ?>
    </div>
    <?php endif; ?>
    <div class="friend-links" id="friendLinks"></div>
    <div class="footer-pages">
      <?php foreach ($navTree as $np): ?>
      <a href="/?page=<?php echo znav_e($np['slug']); ?>"><?php echo znav_e($np['title']); ?></a>
      <?php endforeach; ?>
    </div>
    <p class="foot-line">© <?php echo date('Y'); ?> <span class="js-foot-name"><?php echo znav_e($siteName); ?></span> · Powered by NavVerse<?php echo $footerText !== '' ? ' · ' . znav_e($footerText) : ''; ?> · <a href="javascript:void(0)" id="clearCacheBtn" style="color:inherit;opacity:.75">🧹 清理缓存</a></p>
  </footer>
  </div><!-- /body-main -->
  </div><!-- /body-flex -->

  <!-- 会员登录 / 注册弹窗 -->
  <div id="userModal" class="zmodal" style="display:none">
    <div class="zmodal-mask"></div>
    <div class="zmodal-card user-modal">
      <button class="zmodal-x" id="userModalClose">✕</button>
      <div class="um-tabs"><b id="umTabLogin" class="on">登录</b><b id="umTabReg">注册</b></div>
      <div id="umLogin">
        <input id="ulName" class="zinput" maxlength="20" placeholder="用户名">
        <input id="ulPass" class="zinput" type="password" maxlength="64" placeholder="密码">
        <p class="um-tip" id="ulTip"></p>
        <button id="ulOk" class="zbtn zbtn-ok um-btn">登 录</button>
      </div>
      <div id="umReg" style="display:none">
        <input id="urName" class="zinput" maxlength="20" placeholder="用户名（2-20 位）">
        <input id="urPass" class="zinput" type="password" maxlength="64" placeholder="密码（至少 6 位）">
        <div class="um-type">
          <label><input type="radio" name="urType" value="member" checked><span>会员 <i>可发帖 + 添加网址</i></span></label>
          <label><input type="radio" name="urType" value="temp"><span>临时账号 <i>7 天有效，仅可发帖</i></span></label>
        </div>
        <p class="um-tip" id="urTip"></p>
        <button id="urOk" class="zbtn zbtn-ok um-btn">注 册</button>
      </div>
    </div>
  </div>

  <!-- 发帖弹窗 -->
  <div id="postModal" class="zmodal" style="display:none">
    <div class="zmodal-mask"></div>
    <div class="zmodal-card user-modal">
      <button class="zmodal-x" id="postModalClose">✕</button>
      <h3 class="um-title">✍️ 发布帖子</h3>
      <input id="postTitle" class="zinput" maxlength="60" placeholder="标题（必填）">
      <textarea id="postContent" class="zinput post-area" rows="6" maxlength="2000" placeholder="正文（选填，最多 2000 字）"></textarea>
      <p class="um-tip" id="postTip"></p>
      <button id="postOk" class="zbtn zbtn-ok um-btn">发 布</button>
    </div>
  </div>

  <!-- 帖子详情弹窗 -->
  <div id="postView" class="zmodal" style="display:none">
    <div class="zmodal-mask"></div>
    <div class="zmodal-card user-modal">
      <button class="zmodal-x" id="postViewClose">✕</button>
      <h3 class="um-title" id="pvTitle"></h3>
      <p class="pv-meta" id="pvMeta"></p>
      <div class="pv-body" id="pvBody"></div>
    </div>
  </div>

  <!-- 右下角悬浮聊天窗 -->
  <div id="chatBox" class="chat-box" style="display:none">
    <div class="chat-head">
      <span class="chat-dot"></span><b>在线交流</b>
      <span class="chat-head-btns">
        <button id="chatRenameBtn" title="换个昵称">✏️</button>
        <button id="chatMinBtn" title="收起">－</button>
        <button id="chatCloseBtn" title="关闭">✕</button>
      </span>
    </div>
    <div class="chat-gate" id="chatGate">
      <p>👋 取一个昵称，加入聊天</p>
      <div class="chat-gate-row">
        <input id="chatNameInput" maxlength="20" placeholder="你的昵称">
        <button id="chatNameOk" class="chat-send">进入</button>
      </div>
    </div>
    <div class="chat-msgs" id="chatMsgs"></div>
    <div class="chat-emoji-pop" id="chatEmojiPop" style="display:none"></div>
    <div class="chat-input-row">
      <button id="chatEmojiBtn" title="表情">😊</button>
      <label class="chat-img-label" for="chatImgInput" title="发送图片（≤100KB）">🖼️</label>
      <input type="file" id="chatImgInput" accept="image/*" hidden>
      <input id="chatTextInput" maxlength="500" placeholder="说点什么…">
      <button id="chatSendBtn" class="chat-send">发送</button>
    </div>
  </div>
  <?php if ($chatOn): ?><button id="chatFab" class="chat-fab" title="在线交流">💬</button><?php endif; ?>

  <button id="backTop" class="back-top" title="回到顶部">↑</button>
  <button id="backBottom" class="back-top back-bottom" title="回到底部">↓</button>
  <script src="/assets/app.js?v=<?php echo filemtime(__DIR__.'/assets/app.js'); ?>"></script>
</body>
</html>
