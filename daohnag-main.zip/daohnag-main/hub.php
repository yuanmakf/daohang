<?php
/**
 * 趣导 NavVerse - 聚合主页（Link3 风格组件页 /hub.php）
 * 组件：轮播图 / 视频 / 推广卡（恰饭带货）/ 标准链接 / 贴文 / 二维码
 * 与首页完全一致：顶部导航 + 左侧分类 + 同套配色/背景；组件由后台「聚合页」管理
 */
require_once __DIR__ . '/lib/db.php';
// 禁止浏览器/WebView 缓存页面 HTML（手机 WebView 曾因缓存旧 HTML+旧 CSS 出现样式错乱）
header("Cache-Control: no-cache, no-store, must-revalidate");
header("Pragma: no-cache");
header("Expires: 0");

require_once __DIR__ . '/lib/seo.php';
require_once __DIR__ . '/lib/hub.php';
if (!znav_is_installed()) { header('Location: install.php'); exit; }

$siteName = znav_setting('siteName', '趣导 NavVerse');
$siteLogo = znav_setting('siteLogo', '');
$siteNameVisible = znav_setting('siteNameVisible', '1') !== '0';
$logoSize = max(20, min(96, intval(znav_setting('logoSize', '40'))));
$cardLogoW = max(24, min(96, intval(znav_setting('cardLogoW', '42'))));
$cardLogoH = max(24, min(96, intval(znav_setting('cardLogoH', '42'))));
$cardMinW  = max(150, min(400, intval(znav_setting('cardMinW', '220'))));
$cardMinH  = max(0, min(160, intval(znav_setting('cardMinH', '0'))));
// Logo 尺寸：宽高独立生效（默认不保持比例，拉伸铺满设定的宽高）
$logoStyle = znav_brand_logo_style();
// 站点名称自定义样式（大小 / 颜色 / 字体）：颜色主题化，自动跟随白天/黑夜切换
list($nameStyle, $brandColorCss) = znav_site_name_style();

$bgPreset = znav_setting('bgPreset', 'aurora');
$bgImage = znav_setting('bgImage', '');
$footerText = znav_setting('footerText', '');
$qrQQ = znav_setting('qrQQ', '');
$qrWeixin = znav_setting('qrWeixin', '');
$qrReward = znav_setting('qrReward', '');
$pageWidth = znav_setting('pageWidth', 'wide');
if (!in_array($pageWidth, array('full', 'wide', 'normal', 'custom'), true)) $pageWidth = 'wide';
$thumbW = max(40, min(480, intval(znav_setting('thumbW', '132'))));
$thumbH = max(30, min(480, intval(znav_setting('thumbH', '92'))));
$navTree = znav_nav_tree();

// 聚合页专属设置
$hubName  = trim(znav_setting('hubName', '聚合页'));
if ($hubName === '') $hubName = '聚合页';
$hubTitle  = trim(znav_setting('hubTitle', ''));
if ($hubTitle === '') $hubTitle = $hubName . '主页';
$hubIntro  = znav_setting('hubIntro', '');
$hubEnabled = znav_setting('hubEnabled', '1') !== '0';

// 模块 + 组件（模块化：每个模块一个带标题的卡片组，模块内组件数量不限）
$hubGroups = array();
$hubBlocksByGid = array();
$ungrouped = array();
try {
    $hubGroups = znav_db()->query('SELECT id,name,sort FROM hub_groups WHERE enabled=1 ORDER BY sort ASC, id ASC')->fetchAll();
    $all = znav_db()->query('SELECT id,gid,type,title,content FROM hub_blocks WHERE enabled=1 ORDER BY sort ASC, id ASC')->fetchAll();
    $knownGids = array();
    foreach ($hubGroups as $g) $knownGids[intval($g['id'])] = true;
    foreach ($all as $b) {
        $gid = intval(isset($b['gid']) ? $b['gid'] : 0);
        if ($gid && isset($knownGids[$gid])) {
            if (!isset($hubBlocksByGid[$gid])) $hubBlocksByGid[$gid] = array();
            $hubBlocksByGid[$gid][] = $b;
        } else {
            $ungrouped[] = $b;
        }
    }
} catch (Exception $e) {}

?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<?php
// ===== SEO：聚合页独立标题 / 描述 / 面包屑 =====
$seoTitle = $hubTitle . ' - ' . $siteName;
$seoDesc = trim((string)znav_setting('hubSeoDesc', ''));
if ($seoDesc === '') $seoDesc = $hubTitle . ' - ' . $siteName . ' 的聚合主页，汇集精选链接、视频与推广内容。';
$seoUrl = znav_seo_site_url() . '/hub.php';
echo znav_seo_head(array('title' => $seoTitle, 'description' => $seoDesc, 'url' => $seoUrl)) . "\n";
echo znav_seo_jsonld(array(
    'breadcrumbs' => array(
        array('name' => '首页', 'url' => znav_seo_site_url() . '/'),
        array('name' => $hubTitle, 'url' => $seoUrl),
    ),
)) . "\n";
?>
<title><?php echo znav_e($seoTitle); ?></title>
  <?php echo znav_favicon_html(); ?>
<link rel="stylesheet" href="/assets/style.css?v=<?php echo filemtime(__DIR__ . '/assets/style.css'); ?>">
<style>:root{--logo-size:<?php echo $logoSize; ?>px;--thumb-w:<?php echo $thumbW; ?>px;--thumb-h:<?php echo $thumbH; ?>px}--card-logo-w:<?php echo $cardLogoW; ?>px;--card-logo-h:<?php echo $cardLogoH; ?>px;--card-min-w:<?php echo $cardMinW; ?>px;--card-min-h:<?php echo $cardMinH ? $cardMinH.'px' : '0'; ?>;</style>
  <?php if (!empty($brandColorCss)): ?><style><?php echo $brandColorCss; ?></style><?php endif; ?>
</head>
<body data-bg="<?php echo znav_e($bgPreset); ?>" data-bgimg="<?php echo znav_e($bgImage); ?>" data-width="<?php echo znav_e($pageWidth); ?>" data-keep-title="1">
<?php if ($bgImage): ?><div class="custom-bg-layer"></div><?php endif; ?>
<div class="body-flex" id="bodyFlex">
<?php require __DIR__ . '/inc.topbar.php'; ?>

<div class="body-main">
<button id="menuBtn" class="menu-fab" title="分类"><span>☰</span><em data-i18n="cats">分类导航</em></button>

<main class="hub-wrap">
  <header class="hub-hero">
    <h1 class="hub-h1"><?php echo znav_e($hubTitle); ?></h1>
    <?php if ($hubIntro !== ''): ?><p class="hub-intro"><?php echo znav_e($hubIntro); ?></p><?php endif; ?>
  </header>

  <div class="hub-flow" id="hubFlow">
<?php
if (!$hubEnabled) {
    echo '<p class="hub-empty">聚合页暂未开放，请稍后再来。</p>';
} else {
    $rendered = 0;
    // 先渲染各模块（模块标题 + 模块内组件），再渲染未归组组件
    foreach ($hubGroups as $g) {
        $gid = intval($g['id']);
        $bl = isset($hubBlocksByGid[$gid]) ? $hubBlocksByGid[$gid] : array();
        $html = znav_hub_render_group($g, $bl);
        if ($html !== '') { echo $html, "\n"; $rendered++; }
    }
    foreach ($ungrouped as $b) {
        $html = znav_hub_render_solo($b);
        if ($html !== '') { echo $html, "\n"; $rendered++; }
    }
    if (!$rendered) echo '<p class="hub-empty">这里还是空的 —— 到后台「' . znav_e($hubName) . '」添加模块和轮播、视频、链接、贴文、二维码等组件吧。</p>';
}
?>
  </div>
</main>

  <footer class="footer hub-footer">
    <p class="foot-line">© <?php echo date('Y'); ?> <span class="js-foot-name"><?php echo znav_e($siteName); ?></span><?php echo $footerText !== '' ? ' · ' . znav_e($footerText) : ''; ?></p>
  </footer>
</div>
</div>

<button id="backTop" class="back-top" title="回到顶部">↑</button>
<script src="/assets/app.js?v=<?php echo filemtime(__DIR__ . '/assets/app.js'); ?>"></script>
<script>
/* ===== 聚合页交互：轮播 / 复制账号 ===== */
(function () {
  // 轮播
  document.querySelectorAll('.hub-carousel').forEach(function (car) {
    var slides = car.querySelectorAll('.hub-slide');
    if (slides.length < 1) return;
    var dots = car.querySelectorAll('.hub-dots i');
    var cur = 0, timer = null;
    var interval = Math.max(2000, Math.min(12000, parseInt(car.dataset.interval || '4000', 10)));
    function go(i) {
      cur = (i + slides.length) % slides.length;
      slides.forEach(function (s, k) { s.classList.toggle('on', k === cur); });
      dots.forEach(function (d, k) { d.classList.toggle('on', k === cur); });
    }
    function play() { stop(); if (slides.length > 1) timer = setInterval(function () { go(cur + 1); }, interval); }
    function stop() { if (timer) { clearInterval(timer); timer = null; } }
    dots.forEach(function (d) { d.addEventListener('click', function () { go(parseInt(d.dataset.i, 10)); play(); }); });
    var prev = car.querySelector('.hub-prev'), next = car.querySelector('.hub-next');
    if (prev) prev.addEventListener('click', function () { go(cur - 1); play(); });
    if (next) next.addEventListener('click', function () { go(cur + 1); play(); });
    car.addEventListener('mouseenter', stop);
    car.addEventListener('mouseleave', play);
    // 触屏滑动
    var sx = 0;
    car.addEventListener('touchstart', function (e) { sx = e.touches[0].clientX; stop(); }, { passive: true });
    car.addEventListener('touchend', function (e) {
      var dx = e.changedTouches[0].clientX - sx;
      if (Math.abs(dx) > 40) go(cur + (dx < 0 ? 1 : -1));
      play();
    }, { passive: true });
    play();
  });
  // 复制账号
  document.querySelectorAll('.hub-copy').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var el = document.getElementById(btn.dataset.target);
      if (!el) return;
      var txt = el.textContent || '';
      var done = function () {
        var old = btn.textContent;
        btn.textContent = '✓ 已复制';
        setTimeout(function () { btn.textContent = old; }, 1600);
      };
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(txt).then(done).catch(function () { fallback(); });
      } else fallback();
      function fallback() {
        var ta = document.createElement('textarea');
        ta.value = txt; ta.style.position = 'fixed'; ta.style.opacity = '0';
        document.body.appendChild(ta); ta.select();
        try { document.execCommand('copy'); done(); } catch (e) {}
        document.body.removeChild(ta);
      }
    });
  });
})();
</script>
</body>
</html>
