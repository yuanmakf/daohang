<?php
/**
 * 趣导 NavVerse · 部署自检脚本
 * 用法：把本文件上传到站点根目录，浏览器打开 http://你的域名/check.php
 * 全部 ✓ 仍打不开时，把页面输出或浏览器里的完整报错文字截图发来。
 * ⚠️ 排查完成后请删除本文件，避免暴露服务器路径信息。
 */
error_reporting(E_ALL);
@ini_set('display_errors', '1');
header('Content-Type: text/plain; charset=utf-8');

echo "======== NavVerse 部署自检 ========\n\n";

// 1. PHP 版本
$ok = version_compare(PHP_VERSION, '7.4', '>=');
echo "[1] PHP 版本: " . PHP_VERSION . ($ok ? "  ✓（需 7.4+）" : "  ✗ 低于 7.4，请在宝塔切换 PHP 版本") . "\n";

// 2. 必需扩展
echo "[2] 数据库驱动（二者有其一即可）:\n";
$hasSqlite = extension_loaded('pdo_sqlite');
$hasMysql  = extension_loaded('pdo_mysql');
echo "    pdo_sqlite（SQLite 版用）: " . ($hasSqlite ? "✓ 已启用" : "✗ 未启用") . "\n";
echo "    pdo_mysql（MySQL 版用）  : " . ($hasMysql ? "✓ 已启用" : "✗ 未启用") . "\n";
echo "    结论: " . ($hasSqlite ? "可用 SQLite 版" : "") . ($hasSqlite && $hasMysql ? " / " : "") . ($hasMysql ? "可用 MySQL 版" : "")
   . ((!$hasSqlite && !$hasMysql) ? "  ✗ 两个驱动都没有，本程序无法运行" : "") . "\n";
foreach (array('mbstring' => '多字节字符串（推荐）', 'json' => 'JSON（必需）', 'session' => '会话（必需）') as $ext => $desc) {
    echo "    {$ext}（{$desc}）: " . (extension_loaded($ext) ? "✓ 已启用" : "✗ 未启用") . "\n";
}

// 3. 目录权限
$root = __DIR__;
echo "[3] 目录权限:\n";
echo "    站点根目录 {$root}: " . (is_writable($root) ? "✓ 可写" : "✗ 不可写（uploads 上传、data 回退建库都会失败；宝塔→文件→权限→所有者 www）") . "\n";
echo "    上级目录 " . dirname($root) . ": " . (is_writable(dirname($root)) ? "✓ 可写（数据库将建在站点外的 _znavdata 目录）" : "✗ 不可写（将回退到 data/nav.db，仍可用但安全性略低）") . "\n";
foreach (array('data', 'uploads') as $d) {
    $p = $root . '/' . $d;
    echo "    {$d}/: " . (is_dir($p) ? (is_writable($p) ? "✓ 可写" : "✗ 存在但不可写") : "✗ 不存在") . "\n";
}

// 4. 关键文件
echo "[4] 关键文件:\n";
foreach (array('index.php', 'api.php', 'article.php', 'install.php', 'lib/db.php', 'admin/index.php',
               'assets/app.js', 'assets/admin.js', 'assets/style.css', 'assets/admin.css') as $f) {
    echo "    {$f}: " . (is_file($root . '/' . $f) ? "✓" : "✗ 缺失（上传不完整，请重新上传）") . "\n";
}

// 5. 真实初始化数据库（会直接暴露真实报错）
echo "[5] 数据库连接与初始化:\n";
try {
    require __DIR__ . '/lib/db.php';
    echo "    当前数据库类型: " . (ZNAV_DB_DRIVER === 'mysql'
        ? ('MySQL · ' . ZNAV_DB_NAME . '@' . ZNAV_DB_HOST . (ZNAV_DB_PREFIX ? ' · 前缀 ' . ZNAV_DB_PREFIX : ''))
        : ('SQLite · ' . ZNAV_DB)) . "\n";
    $pdo = znav_db();
    echo "    ✓ 连接并建表成功\n";
    echo "    文章表条数: " . intval($pdo->query('SELECT COUNT(*) FROM articles')->fetchColumn()) . "\n";

    // 6. 安装状态（判断为什么「没走安装向导」或「一直要安装」）
    echo "\n[6] 安装状态:\n";
    echo "    config.php: " . (is_file($root . '/config.php') ? "✓ 存在（数据库类型由它决定）" : "不存在 → 当前按 SQLite 处理") . "\n";
    $vals = array();
    try {
        $st = $pdo->prepare('SELECT `key`,`value` FROM settings WHERE `key` IN (?,?,?)');
        $st->execute(array('installedAt', 'adminPassword', 'installedVersion'));
        foreach ($st->fetchAll() as $r) { $vals[$r['key']] = trim((string)$r['value']); }
    } catch (Throwable $e) {
        echo "    ✗ 读取 settings 失败: " . $e->getMessage() . "\n";
    }
    $pwd = isset($vals['adminPassword']) ? $vals['adminPassword'] : '';
    echo "    installedAt（安装标记）: " . (empty($vals['installedAt']) ? "（无）" : $vals['installedAt']) . "\n";
    if ($pwd === '') {
        echo "    adminPassword（管理员密码）: （无）\n";
    } else {
        $info = password_get_info($pwd);
        echo "    adminPassword（管理员密码）: 已设置 · 长度 " . strlen($pwd)
           . " · " . ($info['algo'] ? "bcrypt 哈希 ✓" : "⚠️ 明文存储，属异常，请重装或改密") . "\n";
    }
    foreach (array('sites' => '网址', 'categories' => '分类', 'pages' => '页面') as $t => $label) {
        try { echo "    {$label}表条数: " . intval($pdo->query("SELECT COUNT(*) FROM $t")->fetchColumn()) . "\n"; }
        catch (Throwable $e) { echo "    {$label}表: 不存在\n"; }
    }
    $inst = znav_is_installed();
    echo "    znav_is_installed(): " . ($inst ? "true" : "false") . "\n";
    echo "    结论: " . ($inst
        ? "已安装 → 前台/后台直接使用；想重走向导请删掉 settings 表里的 installedAt 一行"
        : "未安装 → 打开 install.php 应显示向导，前台会自动跳转过去") . "\n";
} catch (Throwable $e) {
    echo "    ✗ 失败 —— " . get_class($e) . ": " . $e->getMessage() . "\n";
    echo "    （最常见原因：pdo_sqlite / pdo_mysql 未启用、目录不可写、MySQL 库名或账号密码不对）\n";
}

echo "\n======== 自检结束 ========\n";
echo "全部 ✓ 仍报错时，请把浏览器看到的完整错误文字/截图发来。\n排查完成后请删除本文件。\n";
