<?php
/**
 * 趣导 NavVerse · 安装向导（首次使用，像 WordPress 一样一步一步配置）
 * 用法：上传源码后浏览器打开 http://你的域名/install.php
 * 支持 SQLite（无需配置）与 MySQL（填写主机 / 库名 / 账号 / 密码 / 表前缀）。
 * 安装完成后会自动锁定，再次打开只显示「已安装」；建议完成后删除本文件。
 */
/**
 * 安装前置：目录权限自检与自动修复。
 * 免费主机 / 部分面板解压出来的子目录常常是 000 或 700，导致服务器读不到 lib/、assets/ 而报 500，
 * 以前要靠手工运行 znav_fix2.php 才能修。现在安装向导一打开就自动把权限修好，无需额外工具。
 * 只修复站点目录内的已知目录，不碰其他东西；修不动的会记录下来在页面里提示。
 */
if (!function_exists('znav_inst_autochmod')) {
    function znav_inst_autochmod($root)
    {
        $fixed = 0; $fail = array();
        $dirs  = array('lib', 'assets', 'admin', 'uploads', 'uploads/logos', 'uploads/music', 'data');
        // 1) 先修目录本身（不需要打开目录就能 chmod，修好后才可能遍历进去）
        foreach ($dirs as $d) {
            $p = $root . '/' . $d;
            if (!@is_dir($p)) { @mkdir($p, 0755, true); $fixed++; continue; }
            $cur = octdec(substr(sprintf('%o', @fileperms($p)), -4));
            if ($cur !== 0755) { if (@chmod($p, 0755)) $fixed++; else $fail[] = $d; }
        }
        // 2) 再递归修内部文件（目录 755 / 文件 644），打不开的目录直接跳过
        foreach ($dirs as $d) {
            $p = $root . '/' . $d;
            if (!@is_dir($p)) { continue; }
            $h = @opendir($p);
            if (!$h) { continue; }
            closedir($h);
            try {
                $it = new RecursiveIteratorIterator(
                    new RecursiveDirectoryIterator($p, FilesystemIterator::SKIP_DOTS),
                    RecursiveIteratorIterator::CHILD_FIRST
                );
                foreach ($it as $item) {
                    $want = $item->isDir() ? 0755 : 0644;
                    $cur  = octdec(substr(sprintf('%o', @fileperms($item->getPathname())), -4));
                    if ($cur !== $want) {
                        if (@chmod($item->getPathname(), $want)) { $fixed++; }
                        else { $fail[] = $d . '/' . $item->getFilename(); }
                    }
                }
            } catch (UnexpectedValueException $e) { /* 不可读目录跳过 */ }
        }
        return array('fixed' => $fixed, 'fail' => $fail);
    }
}
$znavChmodReport = znav_inst_autochmod(__DIR__);

require_once __DIR__ . '/lib/db.php';
session_start();

$root      = __DIR__;
$dbAuto    = (defined('ZNAV_DB') && ZNAV_DB !== '') ? ZNAV_DB : ($root . '/data/nav.db');
$dbInner   = $root . '/data/nav.db';
$isMysql   = (ZNAV_DB_DRIVER === 'mysql');
$step      = isset($_REQUEST['step']) ? (string)$_REQUEST['step'] : '';
$errs      = array();
$done      = false;
$saved     = array();

/** 写入一条配置 */
function inst_set($pdo, $k, $v)
{
    $pdo->prepare('INSERT OR REPLACE INTO settings(key,value) VALUES(?,?)')->execute(array($k, $v));
}

// ---------- 老站点升级：库里已有真实数据 + 已设管理员密码，只是缺安装标记 → 补标记，不强制重装 ----------
// 注意：不能只看「有没有 siteName」——自动建库时种子数据就会写入 siteName，
// 那样全新部署会被误判成已安装，从而跳过设置管理员密码这一步（后台等于敞开）。
$installed = znav_is_installed();
if (!$installed) {
    try {
        // MySQL 与 SQLite 走同一套判定（原先只处理 SQLite，MySQL 老库会被强制重装）
        $p = null;
        if ($isMysql) {
            $p = znav_connect_mysql();
        } elseif (is_file($dbAuto)) {
            $p = new PDO('sqlite:' . $dbAuto);
            $p->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        }
        if ($p) {
            $p->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        }
        $hasPwd = false; $hasData = false; $hasVer = false;
        if ($p) {
            $st = @$p->query("SELECT value FROM settings WHERE key='adminPassword'");
            $r = $st ? $st->fetch() : null;
            $hasPwd = $r && trim((string)$r['value']) !== '';
        }
        if ($p) {
            $st = @$p->query("SELECT value FROM settings WHERE key='installedVersion'");
            $r2 = $st ? $st->fetch() : null;
            $hasVer = $r2 && trim((string)$r2['value']) !== '';
        }
        if ($hasPwd) {
            foreach (array('sites', 'categories') as $t) {
                $c = @$p->query("SELECT COUNT(*) c FROM $t");
                if ($c && intval($c->fetch()['c']) > 0) { $hasData = true; break; }
            }
        }
        if ($hasPwd && ($hasData || $hasVer)) {
            $p->prepare('INSERT OR REPLACE INTO settings(key,value) VALUES(?,?)')
              ->execute(array('installedAt', date('Y-m-d H:i:s')));
            $installed = true;
        }
    } catch (Exception $e) { /* 忽略：视为未安装 */ }
}

// ---------- 已完成安装：锁定 ----------
if ($installed && $step === 'finish') {
    @unlink(__FILE__);
    header('Location: admin/index.php');
    exit;
}
if ($installed && $_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Location: install.php');
    exit;
}

// ---------- 阶段二：真正写入数据 ----------
if (!$installed && $step === 'run') {
    $cfg = isset($_SESSION['znav_install']) ? $_SESSION['znav_install'] : null;
    if (!is_array($cfg)) { header('Location: install.php'); exit; }
    try {
        $pdo = znav_db();                 // 此时 config.php 已写入，驱动正确
        inst_set($pdo, 'siteName', $cfg['siteName']);
        inst_set($pdo, 'announcement', $cfg['announcement']);
        inst_set($pdo, 'adminUser', $cfg['adminUser']);
        inst_set($pdo, 'adminPassword', password_hash($cfg['adminPassword'], PASSWORD_DEFAULT));
        inst_set($pdo, 'adminEmail', $cfg['adminEmail']);
        inst_set($pdo, 'pageSize', (string)$cfg['pageSize']);
        inst_set($pdo, 'siteNameVisible', '1');

        if (!empty($cfg['demo'])) {
            // 示例分类 + 示例网址（仅在完全没有分类时写入）
            $n = intval($pdo->query('SELECT COUNT(*) FROM categories')->fetchColumn());
            if ($n === 0) {
                $demoCats = array(
                    array('常用工具', '🛠️', array(
                        array('百度', 'https://www.baidu.com'),
                        array('Google', 'https://www.google.com'),
                    )),
                    array('视频影视', '🎬', array(
                        array('哔哩哔哩', 'https://www.bilibili.com'),
                        array('YouTube', 'https://www.youtube.com'),
                    )),
                    array('设计素材', '🎨', array(
                        array('Dribbble', 'https://dribbble.com'),
                        array('站酷', 'https://www.zcool.com.cn'),
                    )),
                );
                $stC = $pdo->prepare('INSERT INTO categories(name,icon,parent_id,sort) VALUES(?,?,NULL,?)');
                $stS = $pdo->prepare('INSERT INTO sites(category_id,name,url,logo,descr,sort) VALUES(?,?,?,?,?,?)');
                foreach ($demoCats as $i => $c) {
                    $stC->execute(array($c[0], $c[1], $i + 1));
                    $cid = intval($pdo->lastInsertId());
                    foreach ($c[2] as $j => $s) {
                        $stS->execute(array($cid, $s[0], $s[1], '', '', $j + 1));
                    }
                }
            }
        } else {
            // 不装示例：清掉初始化自带的示例文章，并标记已处理，避免之后又冒出来
            // 安全：仅限全新站点清理；库里已有网址时说明是老站补装/升级，绝不动已有文章
            $existing = intval($pdo->query('SELECT COUNT(*) FROM sites')->fetchColumn());
            if ($existing === 0) $pdo->exec('DELETE FROM articles');
            inst_set($pdo, 'articlesSeeded', '1');
        }

        inst_set($pdo, 'installedAt', date('Y-m-d H:i:s'));
        inst_set($pdo, 'installedVersion', '1.0');

        // 保障上传目录与数据库目录不可被直接下载（SQLite 版需要）
        if (!is_dir($root . '/uploads')) @mkdir($root . '/uploads', 0777, true);
        foreach (array($root . '/data', dirname($dbAuto)) as $d) {
            if (is_dir($d) && !is_file($d . '/.htaccess')) {
                @file_put_contents($d . '/.htaccess', "Deny from all\n<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n");
            }
        }
        unset($_SESSION['znav_install']);
        $done = true; $installed = true; $saved = $cfg;
    } catch (Exception $e) {
        $errs[] = '安装失败：' . $e->getMessage();
        $step = '';
    }
}

// ---------- 阶段一：校验表单 + 写配置 ----------
if (!$installed && !$done && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $siteName  = trim(isset($_POST['siteName']) ? $_POST['siteName'] : '');
    $slogan    = trim(isset($_POST['announcement']) ? $_POST['announcement'] : '');
    $adminUser = trim(isset($_POST['adminUser']) ? $_POST['adminUser'] : '');
    $pwd       = (string)(isset($_POST['adminPassword']) ? $_POST['adminPassword'] : '');
    $pwd2      = (string)(isset($_POST['adminPassword2']) ? $_POST['adminPassword2'] : '');
    $email     = trim(isset($_POST['adminEmail']) ? $_POST['adminEmail'] : '');
    $pageSize  = intval(isset($_POST['pageSize']) ? $_POST['pageSize'] : 48);
    $dbType    = (isset($_POST['dbType']) && $_POST['dbType'] === 'mysql') ? 'mysql' : 'sqlite';
    $dbMode    = (isset($_POST['dbMode']) && $_POST['dbMode'] === 'inner') ? 'inner' : 'auto';
    $demo      = !empty($_POST['demo']);
    $mHost     = trim(isset($_POST['dbHost']) ? $_POST['dbHost'] : 'localhost');
    $mName     = trim(isset($_POST['dbName']) ? $_POST['dbName'] : '');
    $mUser     = trim(isset($_POST['dbUser']) ? $_POST['dbUser'] : '');
    $mPass     = (string)(isset($_POST['dbPass']) ? $_POST['dbPass'] : '');
    $mPrefix   = trim(isset($_POST['dbPrefix']) ? $_POST['dbPrefix'] : '');

    if ($siteName === '') $errs[] = '请填写站点名称';
    if ($adminUser === '') $errs[] = '请填写管理员账号';
    if (strlen($pwd) < 6) $errs[] = '管理密码至少 6 位';
    if ($pwd !== '' && in_array(strtolower($pwd), array('admin123', '123456', '12345678', '123456789', '111111', '000000', 'abc123', 'a123456', 'password', 'admin', 'root', 'qwerty', 'iloveyou'), true)) {
        $errs[] = '该密码过于简单，请换一个（不能是 admin123 / 123456 这类常见弱密码）';
    }
    if ($pwd !== $pwd2) $errs[] = '两次输入的密码不一致';
    if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) $errs[] = '邮箱格式不正确';
    if ($pageSize < 6) $pageSize = 48;

    if ($dbType === 'mysql') {
        if ($mName === '' || $mUser === '') $errs[] = '请填写 MySQL 数据库名与用户名';
        if ($mPrefix !== '' && !preg_match('/^[A-Za-z0-9_]*$/', $mPrefix)) $errs[] = '表前缀只能包含字母、数字和下划线';
        if (!$errs) {
            try {
                $t = new PDO('mysql:host=' . $mHost . ';dbname=' . $mName . ';charset=utf8mb4', $mUser, $mPass,
                    array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_TIMEOUT => 8));
                $t->query('SELECT 1');
            } catch (Exception $e) {
                $errs[] = 'MySQL 连接失败：' . $e->getMessage() . '（请确认数据库名 / 用户名 / 密码 / 主机是否正确）';
            }
        }
    }

    if (!$errs) {
        $cfgFile = $root . '/config.php';
        if ($dbType === 'mysql') {
            $php = "<?php\n// 由安装向导生成 · 数据库连接配置\ndefine('ZNAV_DB_DRIVER', 'mysql');\n"
                 . "define('ZNAV_DB_HOST', " . var_export($mHost, true) . ");\n"
                 . "define('ZNAV_DB_NAME', " . var_export($mName, true) . ");\n"
                 . "define('ZNAV_DB_USER', " . var_export($mUser, true) . ");\n"
                 . "define('ZNAV_DB_PASS', " . var_export($mPass, true) . ");\n"
                 . "define('ZNAV_DB_PREFIX', " . var_export($mPrefix, true) . ");\n"
                 . "define('ZNAV_DB_CHARSET', 'utf8mb4');\n";
            if (@file_put_contents($cfgFile, $php) === false) {
                $errs[] = '无法写入 config.php（站点根目录不可写，请改为可写后再试）';
            }
        } elseif ($dbMode === 'inner') {
            $php = "<?php\n// 由安装向导生成 · 数据库放在站点内 data 目录\ndefine('ZNAV_DB_DRIVER', 'sqlite');\n"
                 . "define('ZNAV_DB', __DIR__ . '/data/nav.db');\n";
            if (@file_put_contents($cfgFile, $php) === false) {
                $errs[] = '无法写入 config.php（站点根目录不可写，请改为可写后再试）';
            }
        } else {
            if (is_file($cfgFile)) @unlink($cfgFile);   // 自动模式：清掉旧配置
        }
    }

    if (!$errs) {
        $_SESSION['znav_install'] = array(
            'siteName' => $siteName, 'announcement' => $slogan, 'adminUser' => $adminUser,
            'adminPassword' => $pwd, 'adminEmail' => $email, 'pageSize' => $pageSize,
            'demo' => $demo, 'dbType' => $dbType, 'dbMode' => $dbMode,
            'dbHost' => $mHost, 'dbName' => $mName, 'dbPrefix' => $mPrefix
        );
        header('Location: install.php?step=run');
        exit;
    }
}

// ---------- 环境检测 ----------
$checks = array();
$phpOk  = version_compare(PHP_VERSION, '7.0', '>=');
$checks[] = array('PHP 版本', PHP_VERSION, $phpOk, '需要 PHP 7.0 以上（推荐 7.4 / 8.x）');
$hasSqlite = extension_loaded('pdo_sqlite');
$hasMysql  = extension_loaded('pdo_mysql');
$checks[] = array('数据库驱动', ($hasSqlite ? 'pdo_sqlite ✓ ' : '') . ($hasMysql ? 'pdo_mysql ✓' : ''), $hasSqlite || $hasMysql,
    '两者都没有将无法安装：pdo_sqlite 用于 SQLite 版，pdo_mysql 用于 MySQL 版');
foreach (array('json' => '必需', 'session' => '必需', 'mbstring' => '推荐', 'gd' => '可选') as $ext => $lv) {
    $on = extension_loaded($ext);
    $checks[] = array('扩展 ' . $ext, $on ? '已启用' : '未启用', $on || $lv !== '必需', $lv === '必需' ? '必需：请在主机面板开启该扩展' : '（' . $lv . '，不影响安装）');
}
$checks[] = array('站点根目录', $root, is_writable($root), '不可写将无法上传图片、写入 config.php；请把目录权限改为可写');
$checks[] = array('目录 data/', is_dir($root . '/data') ? '存在' : '将自动创建', is_dir($root . '/data') ? is_writable($root . '/data') : is_writable($root), 'SQLite 版需要；MySQL 版不依赖');
$blocking = false;
foreach ($checks as $c) { if (!$c[2]) $blocking = true; }
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo $installed ? '已安装' : '安装向导'; ?> · 趣导 NavVerse</title>
<link rel="icon" type="image/svg+xml" href="/assets/favicon.svg">
<style>
  *{box-sizing:border-box}
  body{margin:0;min-height:100vh;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI","PingFang SC","Microsoft YaHei",sans-serif;
    background:radial-gradient(1200px 600px at 20% -10%,#1e3a8a 0%,transparent 60%),radial-gradient(900px 500px at 100% 0%,#7c3aed 0%,transparent 55%),#0b1020;color:#e6ebf5;padding:28px 16px}
  .wrap{max-width:740px;margin:0 auto}
  .brand{text-align:center;margin-bottom:22px}
  .brand .logo{font-size:44px}
  .brand h1{margin:8px 0 4px;font-size:26px;letter-spacing:.5px}
  .brand p{margin:0;color:#93a3bd;font-size:14px}
  .card{background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.12);border-radius:16px;padding:22px 22px 20px;backdrop-filter:blur(8px);margin-bottom:16px}
  .card h2{margin:0 0 14px;font-size:18px}
  .row{display:flex;justify-content:space-between;gap:12px;padding:9px 0;border-bottom:1px dashed rgba(255,255,255,.1);font-size:14px}
  .row:last-child{border-bottom:0}
  .row .k{color:#cbd5e1}
  .row .v{color:#93a3bd;max-width:56%;word-break:break-all;text-align:right}
  .ok{color:#4ade80!important}.bad{color:#f87171!important}
  label{display:block;margin:14px 0 6px;font-size:13px;color:#cbd5e1}
  input[type=text],input[type=password],input[type=email],input[type=number],select{
    width:100%;padding:11px 12px;border-radius:10px;border:1px solid rgba(255,255,255,.16);
    background:rgba(0,0,0,.28);color:#e6ebf5;font-size:14px;outline:none}
  input:focus,select:focus{border-color:#6366f1}
  .grid2{display:grid;grid-template-columns:1fr 1fr;gap:12px}
  .hint{font-size:12px;color:#8296b3;margin-top:5px;line-height:1.6}
  .chk{display:flex;align-items:flex-start;gap:9px;margin-top:16px;font-size:14px;color:#cbd5e1}
  .chk input{width:16px;height:16px;margin-top:2px}
  .btn{display:inline-block;padding:12px 20px;border:0;border-radius:10px;font-size:15px;cursor:pointer;text-decoration:none;
    background:linear-gradient(135deg,#6366f1,#8b5cf6);color:#fff;font-weight:600}
  .btn.ghost{background:rgba(255,255,255,.1);border:1px solid rgba(255,255,255,.18);font-weight:500}
  .btn.block{display:block;width:100%;text-align:center;margin-top:20px}
  .errs{background:rgba(248,113,113,.14);border:1px solid rgba(248,113,113,.4);border-radius:10px;padding:12px 14px;margin-bottom:14px;font-size:13.5px;color:#fecaca}
  .errs div{margin:3px 0}
  .succ{text-align:center;padding:8px 0}
  .succ .tick{font-size:52px}
  .succ h2{margin:10px 0 6px}
  .succ p{color:#93a3bd;font-size:14px;margin:6px 0}
  .kv{display:flex;justify-content:space-between;font-size:14px;padding:7px 0;border-bottom:1px dashed rgba(255,255,255,.1)}
  .actions{display:flex;gap:12px;margin-top:18px;flex-wrap:wrap}
  .actions .btn{flex:1;text-align:center}
  .warn{margin-top:14px;background:rgba(250,204,21,.12);border:1px solid rgba(250,204,21,.35);color:#fde68a;border-radius:10px;padding:10px 13px;font-size:13px}
  .tip{background:rgba(99,102,241,.12);border:1px solid rgba(99,102,241,.35);color:#c7d2fe;border-radius:10px;padding:10px 13px;font-size:13px;margin-top:10px;line-height:1.7}
  .foot{text-align:center;color:#64748b;font-size:12.5px;margin-top:18px}
  #mysqlBox{display:none;margin-top:12px;border:1px dashed rgba(255,255,255,.2);border-radius:12px;padding:14px}
  @media(max-width:560px){.grid2{grid-template-columns:1fr}}
</style>
</head>
<body>
<div class="wrap">
  <div class="brand">
    <div class="logo">⚡</div>
    <h1>趣导 NavVerse</h1>
    <p><?php echo $installed ? '站点已完成安装' : '安装向导 · 三步上线你的网址导航站（支持 SQLite / MySQL）'; ?></p>
  </div>

  <?php if (!empty($znavChmodReport['fixed']) || !empty($znavChmodReport['fail'])): ?>
  <div class="tip">
    🔧 权限自检：已自动修正 <?php echo intval($znavChmodReport['fixed']); ?> 项目录/文件权限（免费主机解压常导致 500，此处已自动修复，无需额外操作）
    <?php if (!empty($znavChmodReport['fail'])): ?>
      <div style="color:#fecaca;margin-top:6px">
        以下项目自动修改失败，请在主机文件管理器里手动把<b>目录设为 755、文件设为 644</b>：<br>
        <?php echo htmlspecialchars(implode('、', array_slice($znavChmodReport['fail'], 0, 8)), ENT_QUOTES, 'UTF-8'); ?>
      </div>
    <?php endif; ?>
  </div>
  <?php endif; ?>

<?php if ($installed && !$done): ?>
  <div class="card succ">
    <div class="tick">🔒</div>
    <h2>本站已完成安装</h2>
    <p>为防止重复安装，向导已锁定。如需重新安装，请清空数据库（或删除 config.php 与数据库文件）后再次访问本页面。</p>
    <div class="actions">
      <a class="btn" href="admin/index.php">进入后台管理</a>
      <a class="btn ghost" href="index.php">查看前台首页</a>
    </div>
    <form method="post" action="install.php?step=finish" onsubmit="return confirm('删除安装文件 install.php？（删除后无法再回到本页）');">
      <button class="btn ghost block" type="submit">🗑 删除安装文件并进入后台</button>
    </form>
  </div>

<?php elseif ($done): ?>
  <div class="card succ">
    <div class="tick">🎉</div>
    <h2>安装完成！</h2>
    <p>你的导航站已经可以使用了，下面是刚才的配置。</p>
    <div style="text-align:left;margin-top:16px">
      <div class="kv"><span>站点名称</span><b><?php echo htmlspecialchars($saved['siteName'], ENT_QUOTES, 'UTF-8'); ?></b></div>
      <div class="kv"><span>管理员账号</span><b><?php echo htmlspecialchars($saved['adminUser'], ENT_QUOTES, 'UTF-8'); ?></b></div>
      <div class="kv"><span>数据库</span><b style="word-break:break-all"><?php
        echo $saved['dbType'] === 'mysql'
          ? ('MySQL · ' . htmlspecialchars($saved['dbName'], ENT_QUOTES, 'UTF-8') . '@' . htmlspecialchars($saved['dbHost'], ENT_QUOTES, 'UTF-8') . ($saved['dbPrefix'] ? ' · 前缀 ' . htmlspecialchars($saved['dbPrefix'], ENT_QUOTES, 'UTF-8') : ''))
          : ('SQLite · ' . htmlspecialchars($saved['dbMode'] === 'inner' ? $dbInner : $dbAuto, ENT_QUOTES, 'UTF-8'));
      ?></b></div>
      <div class="kv"><span>安装时间</span><b><?php echo date('Y-m-d H:i:s'); ?></b></div>
    </div>
    <div class="actions">
      <a class="btn" href="admin/index.php">进入后台管理</a>
      <a class="btn ghost" href="index.php">查看前台首页</a>
    </div>
    <form method="post" action="install.php?step=finish" onsubmit="return confirm('删除安装文件 install.php？建议删除以避免他人访问本页。');">
      <button class="btn ghost block" type="submit">🗑 删除安装文件并进入后台</button>
    </form>
    <div class="warn">安全提示：建议点击上方按钮删除 <b>install.php</b>（也可在文件管理器里手动删除）。删除后不影响使用，后台「系统设置」里可以随时修改以上配置。</div>
  </div>

<?php else: ?>
  <?php if ($errs): ?>
    <div class="errs"><?php foreach ($errs as $e) { echo '<div>⚠ ' . htmlspecialchars($e, ENT_QUOTES, 'UTF-8') . '</div>'; } ?></div>
  <?php endif; ?>

  <div class="card">
    <h2>① 环境检测</h2>
    <?php foreach ($checks as $c): ?>
      <div class="row">
        <span class="k"><?php echo htmlspecialchars($c[0], ENT_QUOTES, 'UTF-8'); ?></span>
        <span class="v <?php echo $c[2] ? 'ok' : 'bad'; ?>">
          <?php echo htmlspecialchars((string)$c[1], ENT_QUOTES, 'UTF-8'); ?> <?php echo $c[2] ? '✓' : '✗'; ?>
          <?php if (!$c[2]): ?><br><span style="color:#8296b3"><?php echo htmlspecialchars($c[3], ENT_QUOTES, 'UTF-8'); ?></span><?php endif; ?>
        </span>
      </div>
    <?php endforeach; ?>
    <?php if (!$hasMysql): ?>
      <div class="warn">未检测到 <b>pdo_mysql</b>：这台主机只能使用 <b>SQLite</b> 版（下面数据库类型请选择 SQLite）。</div>
    <?php elseif (!$hasSqlite): ?>
      <div class="tip">未检测到 pdo_sqlite，但 <b>pdo_mysql</b> 可用 —— 下面数据库类型请选择 <b>MySQL</b>，并填写主机给你的数据库名 / 用户名 / 密码 / 表前缀。</div>
    <?php endif; ?>
    <?php if ($blocking): ?>
      <div class="warn">存在未通过的必需项（红色 ✗）。请先在主机面板解决后再安装。</div>
    <?php endif; ?>
  </div>

  <form method="post" action="install.php" id="installForm">
    <div class="card">
      <h2>② 站点与管理员</h2>
      <label>站点名称 *</label>
      <input type="text" name="siteName" value="<?php echo htmlspecialchars(isset($_POST['siteName']) ? $_POST['siteName'] : '趣导 NavVerse', ENT_QUOTES, 'UTF-8'); ?>" placeholder="显示在首页顶部与浏览器标签">
      <label>站点标语 / 公告</label>
      <input type="text" name="announcement" value="<?php echo htmlspecialchars(isset($_POST['announcement']) ? $_POST['announcement'] : '你的一万个网址，从此井井有条 ✨', ENT_QUOTES, 'UTF-8'); ?>" placeholder="首页搜索框下方的那句话">

      <div class="grid2">
        <div>
          <label>管理员账号 *</label>
          <input type="text" name="adminUser" value="<?php echo htmlspecialchars(isset($_POST['adminUser']) ? $_POST['adminUser'] : 'admin', ENT_QUOTES, 'UTF-8'); ?>" autocomplete="username">
        </div>
        <div>
          <label>管理员邮箱（选填）</label>
          <input type="email" name="adminEmail" value="<?php echo htmlspecialchars(isset($_POST['adminEmail']) ? $_POST['adminEmail'] : '', ENT_QUOTES, 'UTF-8'); ?>" placeholder="仅作记录，用于找回提示">
        </div>
      </div>
      <div class="grid2">
        <div>
          <label>管理密码 *（至少 6 位，勿用 admin123 / 123456 等弱密码）</label>
          <input type="password" name="adminPassword" autocomplete="new-password" minlength="6" placeholder="登录后台用，请牢记">
        </div>
        <div>
          <label>确认密码 *</label>
          <input type="password" name="adminPassword2" autocomplete="new-password" placeholder="再输入一次">
        </div>
      </div>
    </div>

    <div class="card">
      <h2>③ 数据库与展示设置</h2>
      <label>数据库类型</label>
      <select name="dbType" id="dbType" onchange="toggleDb()">
        <option value="sqlite" <?php echo (!$hasSqlite && $hasMysql) ? '' : 'selected'; ?>>SQLite（推荐，零配置，自动生成数据库文件）</option>
        <option value="mysql" <?php echo (!$hasSqlite && $hasMysql) ? 'selected' : ''; ?>>MySQL（虚拟主机 / 主机面板提供数据库时选这个）</option>
      </select>

      <div id="mysqlBox">
        <div class="grid2">
          <div>
            <label>数据库主机</label>
            <input type="text" name="dbHost" value="<?php echo htmlspecialchars(isset($_POST['dbHost']) ? $_POST['dbHost'] : 'localhost', ENT_QUOTES, 'UTF-8'); ?>" placeholder="localhost">
          </div>
          <div>
            <label>数据库名 *</label>
            <input type="text" name="dbName" value="<?php echo htmlspecialchars(isset($_POST['dbName']) ? $_POST['dbName'] : '', ENT_QUOTES, 'UTF-8'); ?>" placeholder="如：u123456_nav">
          </div>
        </div>
        <div class="grid2">
          <div>
            <label>数据库用户名 *</label>
            <input type="text" name="dbUser" value="<?php echo htmlspecialchars(isset($_POST['dbUser']) ? $_POST['dbUser'] : '', ENT_QUOTES, 'UTF-8'); ?>" autocomplete="off">
          </div>
          <div>
            <label>数据库密码</label>
            <input type="password" name="dbPass" autocomplete="off">
          </div>
        </div>
        <label>数据表前缀</label>
        <input type="text" name="dbPrefix" value="<?php echo htmlspecialchars(isset($_POST['dbPrefix']) ? $_POST['dbPrefix'] : 'znav_', ENT_QUOTES, 'UTF-8'); ?>" placeholder="znav_（留空则不加前缀）">
        <div class="hint">以上信息与主机面板「MySQL 数据库」里显示的完全一致即可；安装程序会自动建表，无需手动导入 SQL。数据库必须已存在（面板里先创建）。</div>
      </div>

      <div id="sqliteBox">
        <label>SQLite 数据库存放位置</label>
        <select name="dbMode">
          <option value="auto" selected>自动（推荐：优先放在站点根目录之外，公网无法直接下载）</option>
          <option value="inner">放在站点内 data/nav.db（主机不允许写上级目录时选这个）</option>
        </select>
        <div class="hint">当前自动模式将使用：<?php echo htmlspecialchars($dbAuto, ENT_QUOTES, 'UTF-8'); ?></div>
      </div>

      <label style="margin-top:16px">每页显示网址数量</label>
      <input type="number" name="pageSize" min="6" max="200" value="<?php echo htmlspecialchars(isset($_POST['pageSize']) ? $_POST['pageSize'] : '48', ENT_QUOTES, 'UTF-8'); ?>">
      <label class="chk">
        <input type="checkbox" name="demo" value="1" checked>
        <span>安装示例数据（3 个示例分类 + 6 个常用网址 + 3 篇示例文章），方便先看效果，之后可随时删除</span>
      </label>
      <button class="btn block" type="submit">开始安装</button>
    </div>
  </form>
<?php endif; ?>

  <p class="foot">趣导 NavVerse · PHP + SQLite / MySQL 网址导航 · 安装后可在「系统设置」中修改以上全部配置</p>
</div>
<script>
function toggleDb(){
  var t = document.getElementById('dbType');
  var isMysql = t && t.value === 'mysql';
  var mb = document.getElementById('mysqlBox'), sb = document.getElementById('sqliteBox');
  if (mb) mb.style.display = isMysql ? 'block' : 'none';
  if (sb) sb.style.display = isMysql ? 'none' : 'block';
}
toggleDb();
</script>
</body>
</html>
